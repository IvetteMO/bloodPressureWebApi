import {
  BrowserRouter,
  Routes,
  Route
} from "react-router-dom";

import MainLayout from "./layouts/MainLayout";

import DashboardPage from 
"./features/dashboard/pages/DashboardPage";
import PatientsPage
from "./features/patients/pages/PatientsPage";
import BPAnalysisPage
from "./features/clinical/bp-analysis/pages/BPAnalysisPage";
import BPLoadPage 
from "./features/clinical/bp-load/pages/BPLoadPage";
import HeartRatePage 
from "./features/clinical/heart-rate/pages/HeartRatePage";
import NocturnalProfilePage 
from "./features/clinical/nocturnal/pages/NocturnalProfilePage";
import FullDiagnosisPage from 
"./features/clinical/fullDiagnosis/pages/FullDiagnosisPage";
import HypertensionPage from 
"./features/clinical/hypertension/pages/HypertensionRiskPage";
import CardiovascularPage from 
"./features/clinical/cardiovascular/pages/CardiovascularRiskPage";

function App() {

  return (

    <BrowserRouter>

      <Routes>

        <Route element={<MainLayout />}>

          <Route
            path="/"
            element={<DashboardPage />}
          />

          <Route
            path="/patients"
            element={<PatientsPage />}
          />

          <Route
            path="/bp-analysis"
            element={<BPAnalysisPage />}
          />
 
          <Route
            path="/bp-load"
            element={<BPLoadPage />}
          />

          <Route
            path="/heart-rate"
            element={<HeartRatePage />}
          />

          <Route
            path="/nocturnal-profile"
            element={<NocturnalProfilePage />}
          />

          <Route
            path="/full-diagnosis"
            element={<FullDiagnosisPage />}
          />

          <Route
            path="/hypertension"
            element={<HypertensionPage />}
          />

          <Route
            path="/cardiovascular-event"
            element={<CardiovascularPage />}
          />

        </Route>

      </Routes>

    </BrowserRouter>

  );
}

export default App;