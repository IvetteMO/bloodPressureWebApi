import AlertList from "@/ui/components/DataDisplay/AlertList";

import { useDashboardAlerts } from "../../../../features/dashboard/hooks/useDashboardAlerts";

export default function DashboardAlerts() {
  const { data, isLoading } = useDashboardAlerts();

  if (isLoading) {
    return (
      <AlertList
        title="Clinical Alerts"
        alerts={[
          {
            title: "Loading...",
            subtitle: "Retrieving clinical alerts.",
            variant: "critical",
          },
        ]}
      />
    );
  }

  const variants = ["critical", "warning", "accent", "info"];

  const alerts = (data ?? []).map((item, index) => ({
    title: item.title,

    subtitle: item.message,

    variant: variants[index % variants.length],
  }));

  return <AlertList title="Clinical Alerts" alerts={alerts} />;
}
