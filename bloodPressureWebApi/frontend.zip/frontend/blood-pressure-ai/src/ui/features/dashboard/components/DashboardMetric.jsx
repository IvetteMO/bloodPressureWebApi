import DashboardMetricCard from "@/ui/components/DataDisplay/MetricCard/DashboardMetricCard";

import { useDashboardOverview } from "../../../../features/dashboard/hooks/useDashboardOverview";

export default function DashboardMetrics() {
  const { data, isLoading } = useDashboardOverview();

  const sparkline = [
    { v: 12 },
    { v: 22 },
    { v: 18 },
    { v: 35 },
    { v: 26 },
    { v: 42 },
    { v: 28 },
    { v: 38 },
    { v: 24 },
    { v: 40 },
  ];

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 gap-6 md:grid-cols-2 xl:grid-cols-4">
        {[1, 2, 3, 4].map((item) => (
          <DashboardMetricCard
            key={item}
            theme="intelligence"
            title="Loading..."
            value="--"
            subtitle="Loading metric..."
            sparkline={sparkline}
          />
        ))}
      </div>
    );
  }

  const metrics = [
    {
      theme: "intelligence",

      title: "High Risk",

      value: data?.highRiskPatients ?? 0,

      subtitle: "AI Profiles",
    },

    {
      theme: "cardiovascular",

      title: "Cardiovascular",

      value: `${data?.cvdRisk ?? 0}%`,

      subtitle: "10-Year Risk",
    },

    {
      theme: "nondipper",

      title: "Non-Dippers",

      value: `${data?.nonDipperRate ?? 0}%`,

      subtitle: "Circadian Alteration",
    },

    {
      theme: "inference",

      title: "AI Inferences",

      value: data?.totalInferences ?? 0,

      subtitle: "Hybrid Evaluations",
    },
  ];

  return (
    <div className="grid grid-cols-1 gap-6 md:grid-cols-2 xl:grid-cols-4">
      {metrics.map((metric) => (
        <DashboardMetricCard
          key={metric.title}
          {...metric}
          sparkline={sparkline}
        />
      ))}
    </div>
  );
}
