import { Sparkles, CirclePlus, Clock3, Activity } from "lucide-react";

import InsightList from "@/ui/components/DataDisplay/InsightList/InsightList";

import { useDashboardInsights } from "../../../../features/dashboard/hooks/useDashboardInsights";

export default function DashboardInsightsPanel() {
  const { data, isLoading } = useDashboardInsights(1);

  console.log("INSIGHTS");
  console.log("loading:", isLoading);
  console.log("data:", data);

  if (isLoading) {
    return (
      <InsightList
        title="AI INSIGHTS"
        items={["Loading AI insights..."]}
        icons={[Sparkles]}
      />
    );
  }

  return (
    <InsightList
      title="AI INSIGHTS"
      items={data ?? []}
      icons={[Sparkles, CirclePlus, Clock3, Activity]}
    />
  );
}
