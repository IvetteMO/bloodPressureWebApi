/**
 * ============================================================
 * Clinical UI Kit
 * Framer Motion Presets
 * ============================================================
 */

export const motionPresets = {
  fadeUp: {
    initial: {
      opacity: 0,
      y: 24,
    },

    animate: {
      opacity: 1,
      y: 0,
    },

    transition: {
      duration: 0.45,
      ease: "easeOut",
    },
  },

  fade: {
    initial: {
      opacity: 0,
    },

    animate: {
      opacity: 1,
    },

    transition: {
      duration: 0.35,
    },
  },

  scale: {
    initial: {
      opacity: 0,
      scale: 0.96,
    },

    animate: {
      opacity: 1,
      scale: 1,
    },

    transition: {
      duration: 0.35,
    },
  },

  modal: {
    initial: {
      opacity: 0,
      scale: 0.96,
    },

    animate: {
      opacity: 1,
      scale: 1,
    },

    exit: {
      opacity: 0,
      scale: 0.98,
    },

    transition: {
      duration: 0.25,
    },
  },
};

export default motionPresets;
