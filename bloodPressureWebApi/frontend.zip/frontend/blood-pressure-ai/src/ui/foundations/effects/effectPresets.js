/**
 * ============================================================
 * Clinical UI Kit
 * Effect Presets Registry
 * ============================================================
 *
 * Composiciones reutilizables de efectos visuales.
 *
 * Cada preset contiene únicamente las claves del registry
 * effects.js.
 *
 * Los componentes solamente solicitan un preset y el renderer
 * se encarga de aplicar cada efecto.
 *
 * Ejemplo:
 *
 * effectPresets.hero
 *
 * =>
 *
 * [
 *   "heroReflection",
 *   "heroWhiteGlow",
 *   "heroVioletGlow",
 *   "heroFuchsiaGlow"
 * ]
 *
 * ============================================================
 */

const effectPresets = {
  /* ==========================================================
   * Generic
   * ========================================================== */

  card: ["topReflection", "whiteGlow", "violetGlow", "cyanGlow"],

  /* ==========================================================
   * Hero
   * ========================================================== */

  hero: [
    "heroReflection",
    "heroWhiteGlow",
    "heroVioletGlow",
    "heroFuchsiaGlow",
  ],

  heroCompact: ["heroReflection", "heroWhiteGlow"],

  heroInfo: ["heroInfoGlow", "heroInfoBorder"],

  /* ==========================================================
   * Page
   * ========================================================== */

  page: ["pageTopGlow", "pageBottomGlow"],

  patientHero: ["patientWhiteGlow", "patientVioletGlow"],

  /* ==========================================================
   * Empty State
   * ========================================================== */

  empty: ["emptyReflection", "emptyVioletGlow", "emptyCyanGlow"],

  /* ==========================================================
   * Diagnosis
   * ========================================================== */

  diagnosisSuccess: ["diagnosisSuccessGlow"],

  diagnosisInfo: ["diagnosisInfoGlow"],

  diagnosisWarning: ["diagnosisWarningGlow"],

  diagnosisCritical: ["diagnosisCriticalGlow"],

  diagnosisOrange: ["diagnosisInterpretationOrangeGlow"],

  diagnosisCyan: ["diagnosisInterpretationCyanGlow"],

  diagnosisBlue: ["diagnosisInterpretationBlueGlow"],

  /* ==========================================================
   * Navigation
   * ========================================================== */

  navigation: [
    "navigationReflection",
    "navigationWhiteGlow",
    "navigationVioletGlow",
    "navigationLogoGlow",
  ],

  navigationDivider: ["sectionDividerGlow"],

  /* ==========================================================
   * Modal
   * ========================================================== */

  modal: ["modalReflection", "modalWhiteGlow", "modalVioletGlow"],
};

export default effectPresets;
