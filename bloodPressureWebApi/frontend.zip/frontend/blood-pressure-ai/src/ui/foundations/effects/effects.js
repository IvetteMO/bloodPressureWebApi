/**
 * ============================================================
 * Clinical UI Kit
 * Visual Effects
 * ============================================================
 */

export const effects = {
  /* ==========================================================
   * Generic Cards
   * ========================================================== */

  topReflection: `
absolute
inset-0
pointer-events-none

bg-[image:var(--ui-reflection-soft)]
`,

  whiteGlow: `
absolute
pointer-events-none

-top-18
-left-18

w-[280px]
h-[280px]

rounded-full

bg-[var(--ui-glow-white)]

blur-[125px]
`,

  violetGlow: `
absolute
pointer-events-none

-right-12
-bottom-12

w-[240px]
h-[240px]

rounded-full

bg-[var(--ui-glow-violet)]

blur-[130px]
`,

  cyanGlow: `
absolute
pointer-events-none

right-0
bottom-0

w-[220px]
h-[220px]

rounded-full

bg-[var(--ui-glow-cyan-soft)]

blur-[120px]
`,

  /* ==========================================================
   * Hero
   * ========================================================== */

  heroReflection: `
absolute
inset-0
pointer-events-none

bg-[image:var(--ui-reflection-medium)]
`,

  heroWhiteGlow: `
absolute
pointer-events-none

-top-10
-left-10

w-[180px]
h-[180px]

rounded-full

bg-[var(--ui-glow-white)]

blur-[75px]
`,

  heroVioletGlow: `
absolute
pointer-events-none

-top-16
-left-16

w-[220px]
h-[220px]

rounded-full

bg-[var(--ui-glow-violet-strong)]

blur-[90px]
`,

  heroFuchsiaGlow: `
absolute
pointer-events-none

top-[10%]
right-[-40px]

w-[180px]
h-[180px]

rounded-full

bg-[var(--ui-glow-fuchsia)]

blur-[100px]
`,

  /* ==========================================================
   * Page
   * ========================================================== */

  pageTopGlow: `
absolute
pointer-events-none

top-16
left-[18%]

w-[520px]
h-[520px]

rounded-full

bg-[var(--ui-glow-violet-subtle)]

blur-[230px]
`,

  pageBottomGlow: `
absolute
pointer-events-none

right-[-10%]
bottom-[-10%]

w-[480px]
h-[480px]

rounded-full

bg-[var(--ui-glow-fuchsia-soft)]

blur-[190px]
`,

  patientWhiteGlow: `
absolute
pointer-events-none

-top-6
-left-6

w-[90px]
h-[90px]

rounded-full

bg-[var(--ui-glow-white-soft)]

blur-[50px]
`,

  patientVioletGlow: `
absolute
pointer-events-none

-right-6
-bottom-6

w-[140px]
h-[140px]

rounded-full

bg-[var(--ui-glow-violet-subtle)]

blur-[90px]
`,

  /* ==========================================================
   * Empty
   * ========================================================== */

  emptyReflection: `
pointer-events-none

absolute
inset-0

bg-[image:var(--ui-reflection-empty)]
`,

  emptyVioletGlow: `
pointer-events-none

absolute

-bottom-32
-left-32

h-[500px]
w-[500px]

rounded-full

bg-[var(--ui-glow-empty-fuchsia)]

blur-[140px]
`,

  emptyCyanGlow: `
pointer-events-none

absolute

-top-32
-right-32

h-[450px]
w-[450px]

rounded-full

bg-[var(--ui-glow-empty-cyan)]

blur-[140px]
`,

  /* ==========================================================
   * Hero Info
   * ========================================================== */

  heroInfoGlow: `
pointer-events-none

absolute
inset-0

bg-[image:var(--ui-reflection-info)]
`,

  heroInfoBorder: `
pointer-events-none

absolute

inset-0

rounded-[34px]

ring-1

ring-[var(--ui-ring-soft)]
`,

  /* ==========================================================
   * Diagnosis
   * ========================================================== */

  diagnosisSuccessGlow: `
absolute
inset-0
z-10

bg-[image:var(--ui-diagnosis-success)]

mix-blend-overlay
`,

  diagnosisInfoGlow: `
absolute
inset-0

bg-[image:var(--ui-diagnosis-info)]
`,

  diagnosisWarningGlow: `
absolute
inset-0

bg-[image:var(--ui-diagnosis-warning)]
`,

  diagnosisCriticalGlow: `
absolute
inset-0

bg-[image:var(--ui-diagnosis-critical)]
`,

  /* ==========================================================
   * Diagnosis Interpretation
   * ========================================================== */

  diagnosisInterpretationOrangeGlow: `
absolute
inset-0

bg-[image:var(--ui-diagnosis-orange)]
`,

  diagnosisInterpretationCyanGlow: `
absolute
inset-0

bg-[image:var(--ui-diagnosis-cyan)]
`,

  diagnosisInterpretationBlueGlow: `
absolute
inset-0

bg-[image:var(--ui-diagnosis-blue)]
`,

  /* ==========================================================
   * Navigation
   * ========================================================== */

  navigationReflection: `
absolute
inset-0

pointer-events-none

bg-[image:var(--ui-reflection-navigation)]
`,

  navigationWhiteGlow: `
absolute

pointer-events-none

-top-16
-left-16

w-[240px]
h-[240px]

rounded-full

bg-[var(--ui-glow-navigation-white)]

blur-[110px]
`,

  navigationVioletGlow: `
absolute

pointer-events-none

-right-10
-bottom-10

w-[220px]
h-[220px]

rounded-full

bg-[var(--ui-glow-navigation-violet)]

blur-[120px]
`,

  /* Glow grande detrás del logo */

  navigationLogoGlow: `
absolute

pointer-events-none

-top-24
-left-24

w-[360px]
h-[360px]

rounded-full

bg-[var(--ui-glow-navigation-logo)]

blur-[170px]
`,

  sectionDividerGlow: `
absolute
inset-0

pointer-events-none

bg-[image:var(--ui-divider-glow)]
`,

  /* ==========================================================
   * Modal
   * ========================================================== */

  modalReflection: `
absolute
inset-0

pointer-events-none

bg-[image:var(--ui-reflection-modal)]
`,

  modalWhiteGlow: `
absolute

pointer-events-none

-top-8
-left-8

w-[180px]
h-[180px]

rounded-full

bg-[var(--ui-glow-modal-white)]

blur-[80px]
`,

  modalVioletGlow: `
absolute

pointer-events-none

-right-8
-bottom-8

w-[220px]
h-[220px]

rounded-full

bg-[var(--ui-glow-modal-violet)]

blur-[120px]
`,
};

export default effects;
