/**
 * ============================================================
 * Clinical UI Kit
 * Motion Presets
 * ============================================================
 */

export const interactions = {
  hover: `
    transition-all
    duration-300
    hover:scale-[1.02]
  `,

  interactive: `
    transition-all
    duration-300
  `,

  floating: `
    translate-y-[10px]
    animate-[fadeInUp_0.5s_ease-out_forwards]
  `,

  surface: `
    transition-all
    duration-300

    hover:scale-[1.01]

    hover:shadow-[var(--ui-interaction-hover-shadow)]
  `,
};

export default interactions;
