/**
 * ============================================================
 * Clinical UI Kit
 * Elevation Tokens
 * ============================================================
 */

export const elevation = {
  flat: {
    shadow: "",

    border: "",

    overlay: "",

    glow: "",
  },

  card: {
    shadow: "shadow-[var(--ui-elevation-card-shadow)]",

    border: "border border-[var(--ui-elevation-border)]",

    overlay:
      "bg-[radial-gradient(circle_at_top_left,var(--ui-overlay-white-soft),transparent_40%)]",

    glow: "bg-[var(--ui-elevation-glow)]",
  },

  panel: {
    shadow: "shadow-[var(--ui-elevation-panel-shadow)]",

    border: "border border-[var(--ui-elevation-border)]",

    overlay:
      "bg-[radial-gradient(circle_at_top_left,var(--ui-overlay-white-soft),transparent_35%)]",

    glow: "bg-[var(--ui-elevation-glow-panel)]",
  },

  hero: {
    shadow: "shadow-[var(--ui-elevation-hero-shadow)]",

    border: "border border-[var(--ui-elevation-border-hero)]",

    overlay:
      "bg-[linear-gradient(180deg,var(--ui-overlay-white-subtle),transparent_40%)]",

    glow: "bg-[var(--ui-elevation-glow-hero)]",
  },

  modal: {
    shadow: "shadow-[var(--ui-elevation-modal-shadow)]",

    border: "border border-[var(--ui-elevation-border)]",

    overlay:
      "bg-[linear-gradient(180deg,var(--ui-overlay-white-modal),transparent_40%)]",

    glow: "bg-[var(--ui-elevation-glow-hero)]",
  },
};

export default elevation;
