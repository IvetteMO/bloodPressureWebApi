import { useCallback, useEffect, useMemo, useState } from "react";

import { DEFAULT_THEME, THEME_NAMES, themes } from "../colors";

import ThemeContext from "./ThemeContext";

import { getStoredTheme, storeTheme } from "./themeStorage";

function isValidTheme(theme) {
  return Boolean(themes[theme]);
}

function resolveInitialTheme() {
  const storedTheme = getStoredTheme();

  if (storedTheme && isValidTheme(storedTheme)) {
    return storedTheme;
  }

  return DEFAULT_THEME;
}

function ThemeProvider({ children }) {
  const [theme, setThemeState] = useState(resolveInitialTheme);

  const setTheme = useCallback((nextTheme) => {
    if (!isValidTheme(nextTheme)) {
      console.warn(`[Clinical UI Kit] Unknown theme "${nextTheme}".`);

      return;
    }

    setThemeState(nextTheme);
  }, []);

  const toggleTheme = useCallback(() => {
    setThemeState((currentTheme) =>
      currentTheme === THEME_NAMES.DARK ? THEME_NAMES.LIGHT : THEME_NAMES.DARK,
    );
  }, []);

  useEffect(() => {
    const root = document.documentElement;

    root.dataset.theme = theme;

    root.classList.toggle("dark", theme === THEME_NAMES.DARK);

    root.style.colorScheme = theme === THEME_NAMES.DARK ? "dark" : "light";

    storeTheme(theme);
  }, [theme]);

  const value = useMemo(
    () => ({
      theme,

      isDark: theme === THEME_NAMES.DARK,

      isLight: theme === THEME_NAMES.LIGHT,

      setTheme,

      toggleTheme,
    }),
    [theme, setTheme, toggleTheme],
  );

  return (
    <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>
  );
}

export default ThemeProvider;
