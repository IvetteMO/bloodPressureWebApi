/**
 * ============================================================
 * Clinical UI Kit
 * Theme Storage
 * ============================================================
 */

export const THEME_STORAGE_KEY = "clinical-ui-theme";

export function getStoredTheme() {
  if (typeof window === "undefined") {
    return null;
  }

  try {
    return window.localStorage.getItem(THEME_STORAGE_KEY);
  } catch {
    return null;
  }
}

export function storeTheme(theme) {
  if (typeof window === "undefined") {
    return;
  }

  try {
    window.localStorage.setItem(THEME_STORAGE_KEY, theme);
  } catch {
    // La aplicación puede seguir funcionando aunque
    // localStorage no esté disponible.
  }
}
