/**
 * ============================================================
 * Clinical UI Kit
 * Spacing Tokens
 * ============================================================
 */

export const spacing = {
  page: `
px-8
pt-8
pb-10

lg:px-10
lg:pt-10

2xl:px-12
`,

  hero: `
    px-8
    pt-7
    pb-6
    

    lg:px-10
    lg:pt-6
    lg:pb-8
  `,

  heroCompact: `
    px-8
    pt-5
    pb-5

    lg:px-9
    lg:pt-6
    lg:pb-6
  `,

  card: `
    p-6

    lg:p-7
  `,

  compact: `
    p-4
    lg:p-5
  `,

  modal: `
    p-7

    lg:p-8
  `,

  panel: `
  px-8

  pt-7

  pb-6
  `,

  tooltip: `
  p-4
  lg:p-5
`,

  tooltipCompact: `
  px-4
  py-3

  lg:px-6
  lg:py-5
`,

  /**
   * ============================================================
   * Insight List
   * ============================================================
   */

  insight: `
py-4
`,

  insightIcon: `
h-11
w-11
`,

  /**
   * ============================================================
   * Metric Card
   * ============================================================
   */

  metric: `
px-6

pt-5

pb-4
`,

  metricContent: `
ml-5

pt-3
`,

  diagnosis: `
px-10
py-10
`,

  nameStudyMargin: `
mt-4
`,

  patientHero: `
mb-8

px-8

py-7
`,

  patientRecord: `
px-8

py-6
`,

  dropzoneSm: `
h-44
`,

  dropzoneMd: `
h-56
`,

  dropzoneLg: `
h-72
`,
};

export default spacing;
