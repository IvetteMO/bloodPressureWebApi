/**
 * ============================================================
 * Clinical UI Kit
 * Typography Tokens
 * ============================================================
 */

export const typography = {
  heroTitle: `
font-black
text-5xl
md:text-6xl
xl:text-7xl
tracking-[-0.04em]
text-[var(--ui-text-heading)]
leading-none
`,

  heroTitleCompact: `
  font-black
text-4xl
md:text-5xl
xl:text-6xl
tracking-[-0.04em]
text-[var(--ui-text-heading)]
leading-none
`,

  heroSubtitle: `
max-w-[620px]
text-lg
text-[var(--ui-text-body)]
leading-9

`,
  pageTitle: `
    text-3xl
    md:text-4xl
    xl:text-5xl
text-[var(--ui-text-heading)]
    font-black
    tracking-tight
  `,

  sectionTitle: `
  text-xl
  xl:text-2xl
  font-bold
  text-[var(--ui-text-heading)]
`,

  cardTitle: `
    text-2xl
    xl:text-3xl
text-[var(--ui-text-heading)]
    font-black
  `,

  body: `
    text-base
text-[var(--ui-text-body)]
    leading-relaxed
  `,

  caption: `
    text-sm
text-[var(--ui-text-label)]
  `,

  eyebrow: `
uppercase
tracking-[0.34em]
font-semibold
text-[13px]
text-[var(--ui-text-label)]
`,

  eyebrowheroCompact: `
uppercase
tracking-[0.34em]
font-semibold
text-[11px]
text-[var(--ui-text-eyebrow)]
`,

  tooltipTitle: `
text-base
lg:text-lg
font-semibold
text-[var(--ui-text-heading)]
`,

  tooltipLabel: `
text-sm
lg:text-lg
font-medium
text-[var(--ui-text-body)]
`,
  /**
   * ============================================================
   * Insight List
   * ============================================================
   */

  insightTitle: `
uppercase
tracking-[0.32em]
font-semibold
text-[13px]
text-[var(--ui-text-label)]
`,

  insightText: `
text-[16px]
leading-7
font-medium
text-[var(--ui-text-body)]
`,

  /**
   * ============================================================
   * Metric Card
   * ============================================================
   */

  metricLabel: `
text-[14px]
font-medium
text-[var(--ui-text-supporting)]
`,

  metricValue: `
mt-3
text-[48px]
leading-none
tracking-[-0.05em]
font-black
`,

  metricSubtitle: `
mt-4
text-[13px]
font-medium
text-[var(--ui-text-supporting)]
`,

  nameStudy: `
text-xl
font-bold
text-[var(--ui-text-heading)]
`,

  chartTitle: `
text-[2rem]
leading-none
font-bold
text-[var(--ui-text-heading)]
`,

  display: `
text-5xl
xl:text-6xl
leading-none
tracking-tight
font-black
text-[var(--ui-text-heading)]
`,

  bodyLarge: `
text-lg
leading-relaxed
text-[var(--ui-text-body)]
`,

  featureTitle: `
text-2xl
tracking-[-0.02em]
text-[var(--ui-text-body)]
`,

  featureValue: `
text-4xl
leading-none
tracking-[-0.04em]
font-black
break-words 

`,

  labelCard: `
uppercase
tracking-[0.3em]
text-sm
text-[var(--ui-text-label)]
`,

  bodyXXLarge: `
 text-2xl
  leading-relaxed
  text-[var(--ui-text-body)]
  `,

  bodyXLarge: `
 text-xl
leading-relaxed
text-[var(--ui-text-body)]
  `,

  InterpretationCard: `
md:text-4xl
text-3xl
font-black
text-[var(--ui-text-heading)]
`,

  headerminiText: `
text-xs
tracking-[0.35em]
uppercase
text-[var(--ui-text-label)]
`,

  headerTitle: `
mt-1
text-2xl
font-black
text-[var(--ui-text-heading)]
`,

  headerLabels: `
text-sm
text-[var(--ui-text-caption)]
`,

  navigationTitle: `
bg-gradient-to-r
from-violet-200
via-fuchsia-300
to-violet-400

bg-clip-text

text-transparent

text-4xl

font-black

tracking-tight
`,

  navigationSubtitle: `
mt-3
text-sm
tracking-wide
text-[var(--ui-text-caption)]
`,

  navigationItem: `
text-[15px]
font-medium
`,

  navigationUser: `
text-sm
font-medium
text-[var(--ui-text-heading)]
`,

  patientHeroLabel: `
uppercase
tracking-[0.30em]
text-xs
text-[var(--ui-text-eyebrow)]
`,

  patientHeroName: `
mt-3
text-[42px]
font-black
tracking-tight
text-[var(--ui-text-heading)]
`,

  patientHeroSubtitle: `
mt-4
text-[var(--ui-text-body)]
`,

  patientRecordLabel: `
uppercase
tracking-[0.25em]
text-xs
text-[var(--ui-text-caption)]
`,

  patientRecordValue: `
mt-2
text-4xl
font-black
text-[var(--ui-accent-cyan)]
`,

  /*
   * ============================================================
   * Entity / Record
   * ============================================================
   */

  entityTitle: `
    text-2xl
    font-semibold
    text-[var(--ui-text-heading)]
  `,

  entityMeta: `
    mt-1
    text-sm
    text-[var(--ui-text-caption)]
  `,

  alertTitle: `
text-[15px]
font-semibold
text-[var(--ui-text-heading)]
`,

  alertSubtitle: `
text-[13px]
mt-1
text-[var(--ui-text-supporting)]
`,

  chartLegend: `
text-xs
font-medium
text-[var(--ui-text-supporting)]
`,
};

export default typography;
