/**
 * ============================================================
 * Clinical UI Kit
 * Radius Tokens
 * ============================================================
 */

export const radius = {
  input: "rounded-2xl",

  button: "rounded-2xl",

  chip: "rounded-[20px]",

  card: "rounded-[28px]",

  surface: "rounded-[32px]",

  panel: "rounded-[36px]",

  modal: "rounded-[38px]",

  hero: "rounded-[40px]",

  full: "rounded-full",
};

export default radius;
