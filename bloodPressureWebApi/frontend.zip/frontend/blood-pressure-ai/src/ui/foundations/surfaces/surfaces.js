export const surfaces = {
  /* ==========================================================
   * Glass
   * ========================================================== */

  glass: `
    rounded-[28px]

    border
    border-[var(--ui-surface-accent-border)]

    bg-[var(--ui-surface-glass-bg)]

    backdrop-blur-xl

    shadow-[var(--ui-shadow-glass)]
  `,

  glassCompact: `
    rounded-[22px]

    border
    border-[var(--ui-surface-accent-border)]

    bg-[var(--ui-surface-glass-compact-bg)]

    backdrop-blur-xl

    shadow-[var(--ui-shadow-glass-compact)]
  `,

  /* ==========================================================
   * Floating
   * ========================================================== */

  floating: `
    rounded-[30px]

    border
    border-[var(--ui-surface-border)]

    bg-[var(--ui-surface-floating-bg)]

    backdrop-blur-xl

    shadow-[var(--ui-shadow-floating)]
  `,

  overlay: `
    rounded-[32px]

    border
    border-[var(--ui-surface-border-soft)]

    bg-[var(--ui-surface-overlay-bg)]

    backdrop-blur-2xl

    shadow-[var(--ui-shadow-overlay)]
  `,

  /* ==========================================================
   * Tooltip
   * ========================================================== */

  tooltip: `
    rounded-[26px]

    border
    border-[var(--ui-surface-accent-border)]

    bg-[var(--ui-surface-tooltip-bg)]

    backdrop-blur-xl

    shadow-[var(--ui-shadow-glass)]
  `,

  /* ==========================================================
   * Insight Icon
   * ========================================================== */

  insightIcon: `
    rounded-full

    border
    border-[var(--ui-surface-accent-border)]

    bg-[var(--ui-surface-insight-icon-bg)]

    transition-all
    duration-300

    group-hover:border-[var(--ui-surface-accent-border-hover)]
    group-hover:bg-[var(--ui-surface-insight-icon-hover-bg)]
  `,

  /* ==========================================================
   * Navigation
   * ========================================================== */

  navigation: `
    rounded-none

    border-r
    border-[var(--ui-surface-border-subtle)]

    bg-[var(--ui-surface-navigation-bg)]

    backdrop-blur-3xl
  `,

  navigationUser: `
    rounded-[28px]

    border
    border-[var(--ui-surface-border-subtle)]

    bg-gradient-to-br
    from-[var(--ui-surface-navigation-user-from)]
    to-[var(--ui-surface-navigation-user-to)]
  `,

  /* ==========================================================
   * Divider
   * ========================================================== */

  divider: `
    border-[var(--ui-surface-border-subtle)]
  `,
};

export default surfaces;
