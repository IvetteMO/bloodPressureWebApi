/**
 * ============================================================
 * Clinical UI Kit
 * Semantic Color Tokens
 * ============================================================
 *
 * Contrato cromático del UI Kit.
 *
 * Los componentes no deben depender de dark/light.
 * Deben consumir estos conceptos semánticos mediante
 * CSS variables.
 * ============================================================
 */

export const semanticTokens = {
  background: {
    primary: "--ui-background-primary",
    secondary: "--ui-background-secondary",
    tertiary: "--ui-background-tertiary",
  },

  surface: {
    base: "--ui-surface-base",
    raised: "--ui-surface-raised",
    elevated: "--ui-surface-elevated",
    floating: "--ui-surface-floating",
    glass: "--ui-surface-glass",
    modal: "--ui-surface-modal",
    hero: "--ui-surface-hero",
  },

  text: {
    primary: "--ui-text-primary",
    secondary: "--ui-text-secondary",
    muted: "--ui-text-muted",
    subtle: "--ui-text-subtle",
    disabled: "--ui-text-disabled",
    inverse: "--ui-text-inverse",
  },

  accent: {
    primary: "--ui-accent-primary",
    secondary: "--ui-accent-secondary",
    tertiary: "--ui-accent-tertiary",
    cyan: "--ui-accent-cyan",
    soft: "--ui-accent-soft",
  },

  border: {
    subtle: "--ui-border-subtle",
    default: "--ui-border-default",
    strong: "--ui-border-strong",
    accent: "--ui-border-accent",
  },

  status: {
    success: "--ui-status-success",
    warning: "--ui-status-warning",
    danger: "--ui-status-danger",
    info: "--ui-status-info",
  },

  glow: {
    violet: "--ui-glow-violet",
    cyan: "--ui-glow-cyan",
    pink: "--ui-glow-pink",
    white: "--ui-glow-white",
  },

  overlay: {
    light: "--ui-overlay-light",
    medium: "--ui-overlay-medium",
    heavy: "--ui-overlay-heavy",
  },

  interactive: {
    hover: "--ui-interactive-hover",
    active: "--ui-interactive-active",
    focus: "--ui-interactive-focus",
    disabled: "--ui-interactive-disabled",
  },
};

export default semanticTokens;
