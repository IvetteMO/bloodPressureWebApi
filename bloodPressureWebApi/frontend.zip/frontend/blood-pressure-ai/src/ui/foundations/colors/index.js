import dark from "./dark";
import light from "./light";

export { semanticTokens } from "./semanticTokens";

export const themes = {
  dark,
  light,
};

export const DEFAULT_THEME = "dark";

export const THEME_NAMES = Object.freeze({
  DARK: "dark",
  LIGHT: "light",
});

export function getThemePalette(theme = DEFAULT_THEME) {
  return themes[theme] ?? themes[DEFAULT_THEME];
}

/**
 * @deprecated
 * Compatibilidad temporal.
 *
 * Eliminar cuando todo el UI Kit consuma tokens semánticos.
 */
export const colors = themes.dark;

export { dark, light };

export default themes;
