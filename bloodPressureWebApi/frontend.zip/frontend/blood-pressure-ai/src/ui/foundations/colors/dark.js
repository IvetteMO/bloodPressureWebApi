/**
 * ============================================================
 * Clinical UI Kit
 * Dark Theme
 * ============================================================
 *
 * Paleta cromática del tema oscuro.
 *
 * Este archivo define VALORES.
 * Los componentes NO deben importarlo directamente.
 * ============================================================
 */

export const dark = {
  background: {
    primary: "#05030A",
    secondary: "#0B0613",
    tertiary: "#140B22",
  },

  surface: {
    base: "#12091F",
    raised: "#1A1030",
    elevated: "#241544",
    floating: "#2E1B57",
    glass: "#201433",
    modal: "#190E2D",
    hero: "#2B1950",
  },

  text: {
    primary: "#F8F5FF",
    secondary: "#C9BEDB",
    muted: "#9A8FB0",
    subtle: "#726985",
    disabled: "#5A5268",
    inverse: "#07070A",
  },

  accent: {
    primary: "#A855F7",
    secondary: "#D8B4FE",
    tertiary: "#F0ABFC",
    cyan: "#67E8F9",
    soft: "#F5E1FF",
  },

  border: {
    subtle: "rgba(255,255,255,0.05)",
    default: "rgba(255,255,255,0.08)",
    strong: "rgba(168,85,247,0.18)",
    accent: "rgba(216,180,254,0.24)",
  },

  status: {
    success: "#2E8B72",
    warning: "#D69E2E",
    danger: "#C44569",
    info: "#38BDF8",
  },

  glow: {
    violet: "rgba(168,85,247,0.18)",
    cyan: "rgba(103,232,249,0.14)",
    pink: "rgba(240,171,252,0.16)",
    white: "rgba(255,255,255,0.08)",
  },

  overlay: {
    light: "rgba(255,255,255,0.03)",
    medium: "rgba(255,255,255,0.06)",
    heavy: "rgba(0,0,0,0.45)",
  },

  interactive: {
    hover: "#B26AF9",
    active: "#9333EA",
    focus: "#C084FC",
    disabled: "#4C445B",
  },
};

export default dark;
