export const labelVariants = {
  label: `
uppercase

tracking-[0.28em]

text-xs

font-medium

text-[var(--ui-text-label)]
`,

  required: `
ml-1

text-[var(--ui-danger)]
`,

  helper: `
text-sm

text-[var(--ui-text-supporting)]
`,

  error: `
text-sm

font-medium

text-[var(--ui-danger)]
`,
};

export default labelVariants;
