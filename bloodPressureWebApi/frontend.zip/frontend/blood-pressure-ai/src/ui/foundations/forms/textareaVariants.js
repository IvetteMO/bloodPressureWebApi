import { cn } from "@/ui/utils/cn";

import inputVariants from "./inputVariants";

export default function textareaVariants(props = {}) {
  return cn(
    inputVariants(props),

    `
min-h-[140px]

resize-y
`,
  );
}
