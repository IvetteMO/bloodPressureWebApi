import { cn } from "@/ui/utils/cn";

import forms from "./forms";

const sizes = {
  sm: "px-4 py-3 text-sm",

  md: "px-5 py-4 text-sm",

  lg: "px-6 py-5 text-base",
};

export default function inputVariants({
  size = "md",

  disabled = false,

  invalid = false,
}) {
  return cn(
    forms.control,

    sizes[size],

    disabled && forms.disabled,

    invalid && forms.invalid,
  );
}
