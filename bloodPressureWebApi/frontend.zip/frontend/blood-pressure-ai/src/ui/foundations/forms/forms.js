export const forms = {
  control: `
    w-full

    rounded-[22px]

    border
    border-[var(--ui-form-border)]

    bg-[var(--ui-form-bg)]

    px-5
    py-4

    text-sm
    text-[var(--ui-form-text)]

    placeholder:text-[var(--ui-form-placeholder)]

    outline-none

    transition-all
    duration-300

    hover:border-[var(--ui-form-border-hover)]

    focus:border-[var(--ui-form-focus-border)]
    focus:bg-[var(--ui-form-focus-bg)]

    focus:shadow-[var(--ui-form-focus-shadow)]
  `,

  disabled: `
    opacity-50
    cursor-not-allowed
  `,

  invalid: `
    border-[var(--ui-form-error-border)]

    focus:border-[var(--ui-form-error-focus-border)]

    focus:shadow-[var(--ui-form-error-shadow)]
  `,

  field: `
    flex
    flex-col
    gap-2
  `,

  helper: `
    text-sm
    text-[var(--ui-form-helper)]
  `,

  error: `
    text-sm
    font-medium
    text-[var(--ui-form-error)]
  `,

  search: `
  w-full

  rounded-[22px]

  border
  border-[var(--ui-search-border)]

  bg-[var(--ui-search-bg)]

  px-5
  py-4
  pl-12

  text-sm
  text-[var(--ui-search-text)]

  placeholder:text-[var(--ui-search-placeholder)]

  outline-none
  backdrop-blur-xl

  transition-all
  duration-300

  focus:border-[var(--ui-search-focus-border)]
  focus:bg-[var(--ui-search-focus-bg)]

  focus:shadow-[var(--ui-form-focus-shadow)]
`,
};

export default forms;
