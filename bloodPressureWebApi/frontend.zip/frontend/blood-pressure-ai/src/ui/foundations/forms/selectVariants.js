import inputVariants from "./inputVariants";

export default function selectVariants(props = {}) {
  return inputVariants(props);
}
