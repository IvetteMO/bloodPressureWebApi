export const checkboxVariants = {
  root: `
group

flex
items-start
gap-4

rounded-[24px]

border
border-white/10

bg-white/[0.03]

p-5

transition-all
duration-300

hover:border-violet-400/20
hover:bg-white/[0.05]
`,

  checked: `
border-cyan-400/35

bg-cyan-500/[0.05]
`,

  icon: `
mt-1

text-cyan-300
`,

  title: `
font-semibold

text-white
`,

  description: `
mt-1

text-sm

text-white/55
`,
};

export default checkboxVariants;
