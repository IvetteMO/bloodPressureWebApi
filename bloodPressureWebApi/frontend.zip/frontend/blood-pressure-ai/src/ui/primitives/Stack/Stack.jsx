import { cn } from "../../utils/cn";
import { gaps } from "./stackVariants";

export default function Stack({
  children,

  layout = "flex",

  direction = "column",

  gap = "md",

  wrap = false,

  template,

  className = "",
}) {
  const isGrid = layout === "grid";

  return (
    <div
      className={cn(
        isGrid ? "grid" : "flex",

        !isGrid && (direction === "row" ? "flex-row" : "flex-col"),

        gaps[gap],

        wrap && !isGrid && "flex-wrap",

        className,
      )}
      style={
        isGrid && template
          ? {
              gridTemplateColumns: template.replace(/_/g, " "),
            }
          : undefined
      }
    >
      {children}
    </div>
  );
}
