import { cn } from "../../utils/cn";

import Background from "../Background";
import Decoration from "../Decoration";

import surfaceVariants from "./surfaceVariants";

export default function Surface({
  variant = "card",

  background,

  effects = [],

  children,

  className = "",

  interactive = false,

  ...props
}) {
  const current = surfaceVariants[variant] ?? surfaceVariants.card;

  return (
    <div
      {...props}
      className={cn(
        "relative overflow-hidden",

        current.radius,

        current.elevation.shadow,

        current.elevation.border,

        interactive &&
          "transition-all duration-300 hover:-translate-y-[3px] hover:scale-[1.008] hover:border-fuchsia-400/35 hover:shadow-[0_12px_45px_rgba(168,85,247,.18)]",

        className,
      )}
    >
      <Background variant={current.background} background={background} />

      {[...current.effects, ...effects].map((effect) => (
        <Decoration key={effect} effect={effect} />
      ))}

      <div className="z-10 relative">{children}</div>
    </div>
  );
}
