import { radius } from "../../foundations/radius";
import { elevation } from "../../foundations/elevation";

export const surfaceVariants = {
  card: {
    radius: radius.surface,
    background: "card",
    elevation: elevation.card,

    effects: ["topReflection", "whiteGlow", "violetGlow"],
  },

  panel: {
    radius: "rounded-[34px]",
    background: "panel",
    elevation: elevation.panel,

    effects: ["topReflection", "whiteGlow", "violetGlow", "cyanGlow"],
  },

  hero: {
    radius: radius.hero,
    background: "hero",
    elevation: elevation.hero,

    effects: [
      "heroReflection",
      "heroWhiteGlow",
      "heroVioletGlow",
      "heroFuchsiaGlow",
    ],
  },

  modal: {
    radius: radius.modal,
    background: "modal",
    elevation: elevation.modal,

    effects: ["topReflection", "whiteGlow", "violetGlow"],
  },

  listItem: {
    radius: radius.surface,

    background: "listItem",

    elevation: elevation.card,

    effects: ["topReflection", "whiteGlow", "violetGlow"],
  },

  metric: {
    radius: radius.surface,

    background: "card",

    elevation: elevation.card,

    effects: ["topReflection", "whiteGlow", "violetGlow"],
  },

  patientRow: {
    radius: radius.card,

    background: "patientRow",

    elevation: elevation.card,

    effects: ["topReflection", "patientWhiteGlow", "patientVioletGlow"],
  },

  empty: {
    radius: "rounded-[40px]",

    background: "empty",

    elevation: elevation.hero,

    effects: ["emptyReflection", "emptyVioletGlow", "emptyCyanGlow"],
  },

  heroInfo: {
    radius: "rounded-[34px]",

    background: "heroInfo",

    elevation: elevation.card,

    effects: ["topReflection", "heroInfoGlow", "heroInfoBorder"],
  },

  heroAside: {
    radius: radius.surface,

    background: "heroAside",

    elevation: elevation.card,

    effects: ["topReflection", "whiteGlow", "violetGlow"],
  },

  heroAsideExcel: {
    radius: radius.surface,

    background: "heroAside",

    elevation: elevation.card,

    effects: ["topReflection", "whiteGlow", "violetGlow"],
  },

  diagnosis: {
    radius: radius.hero,

    background: "diagnosis",

    elevation: elevation.hero,

    effects: ["topReflection"],
  },

  patientHero: {
    radius: radius.hero,

    background: "patientHero",

    elevation: elevation.hero,

    effects: ["topReflection", "whiteGlow", "violetGlow", "cyanGlow"],
  },

  patientRecord: {
    radius: radius.card,

    background: "patientRecord",

    elevation: elevation.card,

    effects: ["topReflection", "whiteGlow"],
  },

  dropzone: {
    radius: radius.surface,

    background: "panel",

    elevation: elevation.panel,

    effects: ["topReflection", "whiteGlow", "cyanGlow"],
  },
};

export default surfaceVariants;
