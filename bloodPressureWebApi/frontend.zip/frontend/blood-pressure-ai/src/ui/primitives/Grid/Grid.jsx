import { cn } from "../../utils/cn";
import { gridVariants, columnVariants, gapVariants } from "./gridVariants";

export default function Grid({
  variant,
  cols,

  gap,
  gapX,
  gapY,

  children,
  className = "",
}) {
  return (
    <div
      className={cn(
        "grid",

        cols && columnVariants[cols],

        gap && gapVariants[gap],

        gapX && gapVariants[gapX],

        gapY && gapVariants[gapY],

        !cols && variant && gridVariants[variant],

        className,
      )}
    >
      {children}
    </div>
  );
}
