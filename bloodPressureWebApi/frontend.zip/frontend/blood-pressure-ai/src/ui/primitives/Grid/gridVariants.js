export const columnVariants = {
  1: `
    grid-cols-1
  `,

  2: `
    grid-cols-1
    md:grid-cols-2
  `,

  3: `
    grid-cols-1
    lg:grid-cols-3
  `,

  4: `
    grid-cols-1
    md:grid-cols-2
    xl:grid-cols-4
  `,
};

export const gridVariants = {
  dashboard: `
    gap-8
    grid-cols-1
    xl:grid-cols-12
  `,

  metrics: `
    gap-6
    grid-cols-1
    md:grid-cols-2
    xl:grid-cols-4
  `,

  cards: `
    gap-8
    grid-cols-1
    lg:grid-cols-2
  `,
};

export const gapVariants = {
  sm: "gap-4",
  md: "gap-6",
  lg: "gap-8",
  xl: "gap-10",
  "2xl": "gap-12",

  "x-sm": "gap-x-4",
  "x-md": "gap-x-6",
  "x-lg": "gap-x-8",
  "x-xl": "gap-x-10",
  "x-2xl": "gap-x-12",

  "y-sm": "gap-y-4",
  "y-md": "gap-y-6",
  "y-lg": "gap-y-8",
  "y-xl": "gap-y-10",
  "y-2xl": "gap-y-12",
};
