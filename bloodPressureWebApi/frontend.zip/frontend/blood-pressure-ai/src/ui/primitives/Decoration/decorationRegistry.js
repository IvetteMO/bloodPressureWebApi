/**
 * ============================================================
 * Clinical UI Kit
 * ------------------------------------------------------------
 * Glow Registry
 * ============================================================
 *
 * Registro centralizado de todos los efectos visuales.
 *
 * Cada efecto representa una capa decorativa reutilizable.
 *
 * Surface únicamente solicita los nombres de los efectos.
 *
 * Glow sabe cómo dibujarlos.
 * ============================================================
 */

import { effects } from "../../foundations/effects";

export const decorationRegistry = {
  topReflection: {
    className: effects.topReflection,
  },

  whiteGlow: {
    className: effects.whiteGlow,
  },

  violetGlow: {
    className: effects.violetGlow,
  },

  cyanGlow: {
    className: effects.cyanGlow,
  },

  heroReflection: {
    className: effects.heroReflection,
  },

  heroWhiteGlow: {
    className: effects.heroWhiteGlow,
  },

  heroVioletGlow: {
    className: effects.heroVioletGlow,
  },

  heroFuchsiaGlow: {
    className: effects.heroFuchsiaGlow,
  },

  pageTopGlow: {
    className: effects.pageTopGlow,
  },

  pageBottomGlow: {
    className: effects.pageBottomGlow,
  },

  emptyReflection: {
    className: effects.emptyReflection,
  },

  emptyVioletGlow: {
    className: effects.emptyVioletGlow,
  },

  emptyCyanGlow: {
    className: effects.emptyCyanGlow,
  },
  heroInfoGlow: {
    className: effects.heroInfoGlow,
  },

  heroInfoBorder: {
    className: effects.heroInfoBorder,
  },

  diagnosisSuccessGlow: {
    className: effects.diagnosisSuccessGlow,
  },

  diagnosisInfoGlow: {
    className: effects.diagnosisInfoGlow,
  },

  diagnosisWarningGlow: {
    className: effects.diagnosisWarningGlow,
  },

  diagnosisCriticalGlow: {
    className: effects.diagnosisCriticalGlow,
  },

  diagnosisInterpretationOrangeGlow: {
    className: effects.diagnosisInterpretationOrangeGlow,
  },

  diagnosisInterpretationCyanGlow: {
    className: effects.diagnosisInterpretationCyanGlow,
  },

  diagnosisInterpretationBlueGlow: {
    className: effects.diagnosisInterpretationBlueGlow,
  },

  navigationReflection: {
    className: effects.navigationReflection,
  },

  navigationWhiteGlow: {
    className: effects.navigationWhiteGlow,
  },

  navigationVioletGlow: {
    className: effects.navigationVioletGlow,
  },

  navigationLogoGlow: {
    className: effects.navigationLogoGlow,
  },
};

export default decorationRegistry;
