import clsx from "clsx";

import decorationRegistry from "./decorationRegistry";

export default function Decoration({ effect, className = "" }) {
  const current = decorationRegistry[effect];

  if (!current) return null;

  return (
    <div aria-hidden="true" className={clsx(current.className, className)} />
  );
}
