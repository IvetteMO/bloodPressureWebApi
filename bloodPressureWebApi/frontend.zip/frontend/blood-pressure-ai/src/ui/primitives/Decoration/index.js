export { default } from "./Decoration";
