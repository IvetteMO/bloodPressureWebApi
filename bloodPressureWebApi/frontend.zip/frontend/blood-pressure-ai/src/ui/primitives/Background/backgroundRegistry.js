/**
 * ============================================================
 * Clinical UI Kit
 * ------------------------------------------------------------
 * Background Registry
 * ============================================================
 *
 * Todas las superficies utilizan un background registrado.
 *
 * Surface solamente conoce el nombre.
 *
 * Background sabe dibujarlo.
 * ============================================================
 */

export const backgroundRegistry = {
  /*
   * ============================================================
   * Base Cards
   * ============================================================
   */

  card: `
    bg-gradient-to-br

  from-[var(--ui-bg-card-from)]
  via-[var(--ui-bg-card-via)]
  to-[var(--ui-bg-card-to)]
  `,

  /*
   * ============================================================
   * Panels
   * ============================================================
   */

  panel: `
  bg-gradient-to-br

  from-[var(--ui-bg-panel-from)]
  via-[var(--ui-bg-panel-via)]
  to-[var(--ui-bg-panel-to)]
  `,

  /*
   * ============================================================
   * Hero
   * ============================================================
   */

  hero: `
    bg-gradient-to-br

  from-[var(--ui-bg-hero-from)]
  via-[var(--ui-bg-hero-via)]
  to-[var(--ui-bg-hero-to)]
  `,

  heroCompact: `
bg-gradient-to-br

  from-[var(--ui-bg-hero-compact-from)]
  via-[var(--ui-bg-hero-compact-via)]
  to-[var(--ui-bg-hero-compact-to)]
`,

  /*
   * ============================================================
   * Modal
   * ============================================================
   */

  modal: `
    bg-gradient-to-br

  from-[var(--ui-bg-modal-from)]
  via-[var(--ui-bg-modal-via)]
  to-[var(--ui-bg-modal-to)]
  `,

  /*
   * ============================================================
   * Glass
   * ============================================================
   */

  glass: `
  bg-[var(--ui-bg-glass)]
  backdrop-blur-2xl
`,

  /*
   * ============================================================
   * Transparent
   * ============================================================
   */

  transparent: `
    bg-transparent
  `,

  listItem: `
bg-gradient-to-br

  from-[var(--ui-bg-list-item-from)]
  via-[var(--ui-bg-list-item-via)]
  to-[var(--ui-bg-list-item-to)]
`,

  /*
   * ============================================================
   * Metric Cards
   * ============================================================
   */

  metricIntelligence: `
  bg-gradient-to-br

  from-[var(--ui-bg-metric-intelligence-from)]
  via-[var(--ui-bg-metric-intelligence-via)]
  to-[var(--ui-bg-metric-intelligence-to)]
`,

  metricCardiovascular: `
  bg-gradient-to-br

  from-[var(--ui-bg-metric-cardiovascular-from)]
  via-[var(--ui-bg-metric-cardiovascular-via)]
  to-[var(--ui-bg-metric-cardiovascular-to)]
`,

  metricNondipper: `
  bg-gradient-to-br

  from-[var(--ui-bg-metric-nondipper-from)]
  via-[var(--ui-bg-metric-nondipper-via)]
  to-[var(--ui-bg-metric-nondipper-to)]
`,

  metricInference: `
  bg-gradient-to-br

  from-[var(--ui-bg-metric-inference-from)]
  via-[var(--ui-bg-metric-inference-via)]
  to-[var(--ui-bg-metric-inference-to)]
`,

  patientRow: `
bg-gradient-to-br

  from-[var(--ui-bg-patient-row-from)]
  via-[var(--ui-bg-patient-row-via)]
  to-[var(--ui-bg-patient-row-to)]
`,

  empty: `
bg-gradient-to-br

  from-[var(--ui-bg-empty-from)]
  via-[var(--ui-bg-empty-via)]
  to-[var(--ui-bg-empty-to)]
`,

  heroInfo: `
  bg-gradient-to-br

  from-[var(--ui-bg-hero-info-from)]
  via-[var(--ui-bg-hero-info-via)]
  to-[var(--ui-bg-hero-info-to)]
`,

  heroAside: `
  bg-gradient-to-br

  from-[var(--ui-bg-hero-aside-from)]
  via-[var(--ui-bg-hero-aside-via)]
  to-[var(--ui-bg-hero-aside-to)]
`,

  /*
   * ============================================================
   * Diagnosis
   * ============================================================
   */

  diagnosis: `
  bg-gradient-to-br

  from-[var(--ui-bg-diagnosis-from)]
  via-[var(--ui-bg-diagnosis-via)]
  to-[var(--ui-bg-diagnosis-to)]
`,

  diagnosisSuccess: `
  bg-gradient-to-br

  from-[var(--ui-bg-diagnosis-success-from)]
  via-[var(--ui-bg-diagnosis-success-via)]
  to-[var(--ui-bg-diagnosis-success-to)]
`,

  diagnosisInfo: `
  bg-gradient-to-br

  from-[var(--ui-bg-diagnosis-info-from)]
  via-[var(--ui-bg-diagnosis-info-via)]
  to-[var(--ui-bg-diagnosis-info-to)]
`,

  diagnosisWarning: `
  bg-gradient-to-br

  from-[var(--ui-bg-diagnosis-warning-from)]
  via-[var(--ui-bg-diagnosis-warning-via)]
  to-[var(--ui-bg-diagnosis-warning-to)]
`,

  diagnosisCritical: `
  bg-gradient-to-br

  from-[var(--ui-bg-diagnosis-critical-from)]
  via-[var(--ui-bg-diagnosis-critical-via)]
  to-[var(--ui-bg-diagnosis-critical-to)]
`,

  /*
   * ============================================================
   * Diagnosis Interpretation
   * ============================================================
   */

  diagnosisInterpretationOrange: `
  bg-gradient-to-br

  from-[var(--ui-bg-diagnosis-interpretation-orange-from)]
  via-[var(--ui-bg-diagnosis-interpretation-orange-via)]
  to-[var(--ui-bg-diagnosis-interpretation-orange-to)]
`,

  diagnosisInterpretationCyan: `
  bg-gradient-to-br

  from-[var(--ui-bg-diagnosis-interpretation-cyan-from)]
  via-[var(--ui-bg-diagnosis-interpretation-cyan-via)]
  to-[var(--ui-bg-diagnosis-interpretation-cyan-to)]
`,

  diagnosisInterpretationBlue: `
  bg-gradient-to-br

  from-[var(--ui-bg-diagnosis-interpretation-blue-from)]
  via-[var(--ui-bg-diagnosis-interpretation-blue-via)]
  to-[var(--ui-bg-diagnosis-interpretation-blue-to)]
`,

  patientHero: `
  bg-gradient-to-br

  from-[var(--ui-bg-patient-hero-from)]
  via-[var(--ui-bg-patient-hero-via)]
  to-[var(--ui-bg-patient-hero-to)]
`,

  patientRecord: `
  bg-[var(--ui-bg-patient-record)]
`,
};

export default backgroundRegistry;
