import clsx from "clsx";

import backgroundRegistry from "./backgroundRegistry";

export default function Background({
  variant,

  background,

  className = "",
}) {
  const current =
    backgroundRegistry[background] ??
    backgroundRegistry[variant] ??
    backgroundRegistry.card;

  return (
    <div
      aria-hidden="true"
      className={clsx("absolute inset-0 z-0", current, className)}
    />
  );
}
