/**
 * ============================================================
 * Clinical UI Kit
 * Empty State Variants
 * ============================================================
 */

import { BrainCircuit } from "lucide-react";

const emptyStateVariants = {
  default: {
    icon: BrainCircuit,

    eyebrow: "Clinical Intelligence",

    buttonText: "Continue",

    minHeight: "min-h-[550px]",
  },

  compact: {
    icon: BrainCircuit,

    eyebrow: "Clinical Intelligence",

    buttonText: "Continue",

    minHeight: "min-h-[380px]",
  },
};

export default emptyStateVariants;
