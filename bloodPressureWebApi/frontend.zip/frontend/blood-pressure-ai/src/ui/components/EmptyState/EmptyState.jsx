import { useNavigate } from "react-router-dom";

import { Activity, ArrowRight } from "lucide-react";

import { cn } from "@/ui/utils/cn";

import Button from "@/ui/components/Button";
import Panel from "@/ui/components/Panel";
import IconBadge from "@/ui/components/IconBadge";

import emptyStateVariants from "./emptyStateVariants";

export default function EmptyState({
  variant = "default",

  title = "Nothing to display",

  subtitle = "There is currently no information available.",

  eyebrow,

  buttonText,

  navigateTo = "/",

  icon,

  action,

  className = "",
}) {
  const navigate = useNavigate();

  const current = emptyStateVariants[variant] ?? emptyStateVariants.default;

  const Icon = icon ?? current.icon;

  const handleClick = () => {
    if (action) {
      action();
      return;
    }

    navigate(navigateTo);
  };

  return (
    <Panel
      variant="empty"
      className={cn(
        current.minHeight,
        "flex items-center justify-center",
        className,
      )}
    >
      <div className="z-10 relative flex flex-col items-center px-8 max-w-3xl text-center">
        <IconBadge
          icon={Icon}
          appearance="
            bg-[var(--ui-empty-icon-bg)]
            text-[var(--ui-empty-icon-text)]
          "
          variant="xxl"
        />

        <p className="mt-8 text-[var(--ui-empty-text-eyebrow)] text-sm uppercase tracking-[0.40em]">
          {eyebrow ?? current.eyebrow}
        </p>

        <h1 className="mt-6 font-bold text-[var(--ui-empty-text-primary)] text-5xl">
          {title}
        </h1>

        <p className="mt-8 max-w-2xl text-[var(--ui-empty-text-secondary)] text-xl leading-relaxed">
          {subtitle}
        </p>

        <Button
          className="mt-16"
          onClick={handleClick}
          leftIcon={<Activity size={18} />}
          rightIcon={<ArrowRight size={18} />}
        >
          {buttonText ?? current.buttonText}
        </Button>

        <div className="bg-[var(--ui-empty-status-bg)] mt-10 px-5 py-2 border border-[var(--ui-empty-status-border)] rounded-full text-[var(--ui-empty-status-text)] text-sm">
          Hybrid AI Ready
        </div>
      </div>
    </Panel>
  );
}
