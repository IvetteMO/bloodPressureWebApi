import { cn } from "@/ui/utils/cn";

import { tabGroupBase, tabVariants } from "./clinicalTabGroupVariants";

export default function ClinicalTabGroup({
  tabs = [],
  activeTab,
  onChange,
  className = "",
}) {
  return (
    <div className={cn(tabGroupBase, className)}>
      {tabs.map((tab) => {
        const isActive = activeTab === tab;

        return (
          <button
            key={tab}
            type="button"
            onClick={() => onChange?.(tab)}
            className={cn(
              tabVariants.base,

              isActive ? tabVariants.active : tabVariants.inactive,
            )}
          >
            <span className="relative z-10">{tab}</span>
          </button>
        );
      })}
    </div>
  );
}
