export const tabGroupBase = `
  flex
  flex-wrap
  gap-4
`;

export const tabVariants = {
  base: `
    relative
    shrink-0

    rounded-full

    border

    px-6
    py-3

    text-sm
    font-semibold

    transition-all
    duration-300

    focus-visible:outline-none
    focus-visible:ring-2
    focus-visible:ring-fuchsia-400/40

    disabled:pointer-events-none
    disabled:opacity-50
  `,

  active: `
    border-fuchsia-400/30

    bg-gradient-to-r
    from-fuchsia-500/20
    to-cyan-400/10

    text-[var(--ui-text-heading)]

    shadow-[0_0_25px_rgba(217,70,239,0.18)]
  `,

  inactive: `
    border-white/10

    bg-white/[0.03]

    text-[var(--ui-text-secondary)]

    hover:border-fuchsia-400/20
    hover:bg-white/[0.05]
    hover:text-white
  `,
};

export default tabVariants;
