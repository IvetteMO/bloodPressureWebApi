export { default } from "./ClinicalTabGroup";
