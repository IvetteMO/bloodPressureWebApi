import { Gauge, GaugeCircle, TriangleAlert } from "lucide-react";

import diagnosisPalette from "../palette/diagnosisPalette";

export function getBPLoadTheme(label) {
  switch (label) {
    case "Normal":
      return {
        ...diagnosisPalette.success,
        diagnosis: "Normal",
        riskLabel: "Low Risk",
        icon: Gauge,
        clinicalDiagnosis:
          "Blood pressure load remains within expected physiological limits indicating stable circadian pressure distribution.",
      };

    case "Intermediate":
      return {
        ...diagnosisPalette.warning,
        diagnosis: "Intermediate",
        riskLabel: "Monitor",
        icon: GaugeCircle,
        clinicalDiagnosis:
          "Moderate elevation in blood pressure load suggesting partial increase in cardiovascular strain.",
      };

    case "High":
      return {
        ...diagnosisPalette.critical,
        diagnosis: "High",
        riskLabel: "High Risk",
        icon: TriangleAlert,

        clinicalDiagnosis:
          "Elevated blood pressure load detected indicating increased cardiovascular burden and potential risk.",
      };

    default:
      return {
        ...diagnosisPalette.critical,
        diagnosis: "Very High",
        riskLabel: "Critical",
        icon: TriangleAlert,
        clinicalDiagnosis:
          "Very high blood pressure load associated with significant cardiovascular burden requiring prompt clinical evaluation.",
      };
  }
}

export default getBPLoadTheme;
