import Panel from "@/ui/components/Panel";
import Grid from "@/ui/primitives/Grid";
import Stack from "@/ui/primitives/Stack";
import { typography } from "@/ui/foundations";

import ClinicalHighlightCard from "./ClinicalHighlightCard";

export default function ClinicalHighlightSection({
  title = "Clinical Diagnosis",
  items = [],
}) {
  if (!items.length) return null;

  return (
    <Panel className="flex flex-col gap-15">
      {/* HEADER */}
      <Stack gap="lg">
        <div>
          <p className={typography.labelCard}>{title}</p>
        </div>

        {/* GRID */}

        <Grid cols={3} gap="md">
          {items.map((item) => (
            <ClinicalHighlightCard key={item.title} {...item} />
          ))}
        </Grid>
      </Stack>
    </Panel>
  );
}
