import { Moon, HeartPulse, Gauge } from "lucide-react";

const highlightPalette = {
  green: {
    background: "diagnosisSuccess",

    glow: "diagnosisSuccessGlow",

    border: "border-emerald-500/20",

    text: "text-emerald-300",

    accent: "bg-emerald-500/15",
  },

  orange: {
    background: "diagnosisWarning",

    glow: "diagnosisWarningGlow",

    border: "border-orange-500/20",

    text: "text-orange-300",

    accent: "bg-orange-500/15",
  },

  cyan: {
    background: "diagnosisInfo",

    glow: "diagnosisInfoGlow",

    border: "border-cyan-500/20",

    text: "text-cyan-300",

    accent: "bg-cyan-500/15",
  },

  red: {
    background: "diagnosisCritical",

    glow: "diagnosisCriticalGlow",

    border: "border-rose-500/20",

    text: "text-rose-300",

    accent: "bg-rose-500/15",
  },
};

export default highlightPalette;
