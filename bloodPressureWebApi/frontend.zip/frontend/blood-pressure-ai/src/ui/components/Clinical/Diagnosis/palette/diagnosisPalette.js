import { ShieldCheck, ShieldAlert, ShieldX, Activity } from "lucide-react";

export const diagnosisPalette = {
  success: {
    status: "success",
    glow: "diagnosisSuccessGlow",
    border: "border-emerald-500/20",
    accent: "bg-emerald-500/15 text-emerald-200",
    text: "text-emerald-300",
    icon: ShieldCheck,
    background: "diagnosisSuccess", // <-- fondo verde
  },

  info: {
    status: "info",
    glow: "diagnosisInfoGlow",
    border: "border-cyan-500/20",
    accent: "bg-cyan-500/15 text-cyan-200",
    text: "text-cyan-300",
    icon: Activity,
    background: "diagnosisInfo", // <-- fondo cyan
  },

  warning: {
    status: "warning",
    glow: "diagnosisWarningGlow",
    border: "border-amber-500/20",
    accent: "bg-amber-500/15 text-amber-200",
    text: "text-amber-300",
    icon: ShieldAlert,
    background: "diagnosisWarning", // <-- fondo amarillo/naranja
  },

  critical: {
    status: "critical",
    glow: "diagnosisCriticalGlow",
    border: "border-rose-500/20",
    accent: "bg-rose-500/15 text-rose-200",
    text: "text-rose-300",
    icon: ShieldX,
    background: "diagnosisCritical", // <-- fondo rojo
  },
};

export default diagnosisPalette;
