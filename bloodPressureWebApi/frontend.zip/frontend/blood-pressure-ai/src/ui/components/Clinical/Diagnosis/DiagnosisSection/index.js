export { default } from "./DiagnosisSection";
