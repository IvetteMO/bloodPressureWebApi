export { default as ClinicalHighlightCard } from "./ClinicalHighlightCard";
export { default as ClinicalHighlightSection } from "./ClinicalHighlightSection";
