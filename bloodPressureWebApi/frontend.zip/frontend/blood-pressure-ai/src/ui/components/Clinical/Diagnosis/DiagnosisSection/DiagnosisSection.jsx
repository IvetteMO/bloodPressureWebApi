import DiagnosisCard from "@/ui/components/Clinical/Diagnosis/DiagnosisCard";

function DiagnosisSection({ theme }) {
  if (!theme) return null;

  return <DiagnosisCard theme={theme} />;
}

export default DiagnosisSection;
