import { cn } from "@/ui/utils/cn";

import Panel from "@/ui/components/Panel";
import IconBadge from "@/ui/components/IconBadge";

import Stack from "@/ui/primitives/Stack";

import { typography } from "@/ui/foundations";

export default function PredictionCard({
  palette,

  title,

  value,

  suffix = "",

  category,

  description,

  rightTitle = "Risk Status",

  rightValue,

  rightSuffix = "",

  className = "",
}) {
  if (!palette) return null;

  const Icon = palette.icon;

  return (
    <Panel
      variant="diagnosis"
      background={palette.background}
      effects={[palette.glow]}
      className={cn(
        palette.border,
        "hover:shadow-[0_0_30px_var(--ui-diagnosis-hover-glow)]",
        className,
      )}
    >
      <div className="flex lg:flex-row flex-col gap-10">
        {/* LEFT */}

        <div className="flex-1">
          <Stack direction="row" gap="md" className="items-center">
            <IconBadge
              icon={Icon}
              appearance={palette.accent}
              variant="lg"
              lineColor={palette.text}
            />

            <p
              className={cn(
                typography.metricLabel,
                palette.text,
                "tracking-[0.35em] uppercase",
              )}
            >
              {title}
            </p>
          </Stack>

          <h1 className={cn(typography.display, palette.text, "mt-4")}>
            {value}
            {suffix}
          </h1>

          {category && (
            <h2 className={cn(typography.sectionTitle, palette.text, "mt-4")}>
              {category}
            </h2>
          )}

          <p
            className={cn(
              typography.bodyLarge,
              "mt-6 max-w-5xl leading-relaxed",
              "text-[var(--ui-diagnosis-text-secondary)]",
            )}
          >
            {description}
          </p>
        </div>

        {/* RIGHT */}

        <div className="flex items-center lg:ml-auto">
          <div className="bg-[var(--ui-diagnosis-aside-bg)] backdrop-blur-xl px-8 py-6 border border-[var(--ui-diagnosis-aside-border)] rounded-[28px]">
            <p className="text-[var(--ui-diagnosis-text-muted)] text-xs uppercase tracking-[0.22em]">
              {rightTitle}
            </p>

            <h3 className={cn(palette.text, "mt-2 text-4xl font-black")}>
              {rightValue}

              {rightSuffix && (
                <span className="ml-2 font-semibold text-[var(--ui-diagnosis-text-muted)] text-lg">
                  {rightSuffix}
                </span>
              )}
            </h3>
          </div>
        </div>
      </div>
    </Panel>
  );
}
