import { cn } from "@/ui/utils/cn";

const statusStyles = {
  success: `
    bg-[var(--ui-status-success-bg)]
    border-[var(--ui-status-success-border)]
    text-[var(--ui-status-success-text)]
  `,

  info: `
    bg-[var(--ui-status-info-bg)]
    border-[var(--ui-status-info-border)]
    text-[var(--ui-status-info-text)]
  `,

  warning: `
    bg-[var(--ui-status-warning-bg)]
    border-[var(--ui-status-warning-border)]
    text-[var(--ui-status-warning-text)]
  `,

  critical: `
    bg-[var(--ui-status-critical-bg)]
    border-[var(--ui-status-critical-border)]
    text-[var(--ui-status-critical-text)]
  `,
};

export default function DiagnosisBadge({
  status = "info",

  children,

  className = "",
}) {
  return (
    <span
      className={cn(
        `inline-flex items-center px-4 py-1.5 border rounded-full font-semibold text-xs uppercase tracking-[0.22em]`,

        statusStyles[status],

        className,
      )}
    >
      {children}
    </span>
  );
}
