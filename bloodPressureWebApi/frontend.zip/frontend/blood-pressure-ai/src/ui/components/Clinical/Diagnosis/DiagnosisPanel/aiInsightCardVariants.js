const aiInsightCardVariants = {
  default: {
    panel: "",

    contentGap: "lg",

    header: "",

    title: "",

    value: "",

    description: "",
  },

  compact: {
    panel: "",

    contentGap: "md",

    header: "items-center",

    title: `
      text-sm
      font-bold
      leading-tight
      text-[var(--ui-diagnosis-text-primary)]
    `,

    value: `
      text-4xl
      font-black
      leading-none
      tracking-[-0.04em]
      break-words
    `,

    description: `
      text-sm
      leading-relaxed
      text-[var(--ui-diagnosis-text-muted)]
    `,
  },
};

export default aiInsightCardVariants;
