import { cn } from "@/ui/utils/cn";

import Panel from "@/ui/components/Panel";
import IconBadge from "@/ui/components/IconBadge";

import Stack from "@/ui/primitives/Stack";

import { typography } from "@/ui/foundations";

export default function DiagnosisSummaryCard({
  title,

  diagnosis,

  palette,

  className = "",
}) {
  if (!palette) return null;

  const Icon = palette.icon;

  return (
    <Panel
      variant="diagnosis"
      background={palette.background}
      effects={[palette.glow]}
      className={cn(
        palette.border,

        className,
      )}
    >
      <Stack align="center" justify="center" gap="xl" className="h-full">
        <IconBadge
          icon={Icon}
          variant="lg"
          appearance={palette.accent}
          lineColor={palette.text}
        />

        <Stack gap="sm" align="center">
          <p className={cn(typography.featureTitle, "text-center")}>{title}</p>

          <h2
            className={cn(
              typography.featureValue,

              palette.text,

              "text-center",
            )}
          >
            {diagnosis}
          </h2>
        </Stack>
      </Stack>
    </Panel>
  );
}
