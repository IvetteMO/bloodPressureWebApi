/**
 * ============================================================
 * Clinical UI Kit
 * Cardiovascular Risk Category
 * ============================================================
 */

export function getCardiovascularRiskCategory(risk) {
  const value = Number(risk);

  if (Number.isNaN(value)) {
    return {
      status: "info",

      label: "Unknown",

      shortLabel: "--",

      min: null,

      max: null,
    };
  }

  if (value < 10) {
    return {
      status: "success",

      label: "Low Risk",

      shortLabel: "Low",

      min: 0,

      max: 9.9,
    };
  }

  if (value < 20) {
    return {
      status: "warning",

      label: "Moderate Risk",

      shortLabel: "Moderate",

      min: 10,

      max: 19.9,
    };
  }

  return {
    status: "critical",

    label: "High Risk",

    shortLabel: "High",

    min: 20,

    max: 100,
  };
}

export default getCardiovascularRiskCategory;
