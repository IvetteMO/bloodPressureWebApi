import {
  Activity,
  Brain,
  Gauge,
  Heart,
  HeartPulse,
  Moon,
  ShieldAlert,
  Sun,
} from "lucide-react";

const formatNumber = (value, decimals = 0) =>
  value != null ? Number(value).toFixed(decimals) : "--";

export default function buildClinicalMetrics(features, diagnosis) {
  return {
    // ============================================
    // 24 HOURS BP
    // ============================================

    bp24h: [
      {
        title: "Systolic Trend",

        value: formatNumber(features?.systolicTrend),

        subtitle: "24-hour behavior",

        icon: HeartPulse,

        accent: "#FB7185",

        appearance: "rose",

        valueColor: "text-rose-300",
      },

      {
        title: "Diastolic Trend",

        value: formatNumber(features?.diastolicTrend),

        subtitle: "24-hour behavior",

        icon: Heart,

        accent: "#22D3EE",

        appearance: "cyan",

        valueColor: "text-cyan-300",
      },

      {
        title: "Heart Rate",

        value: formatNumber(features?.pulseTrend),

        subtitle: "Circadian rhythm",

        icon: Activity,

        accent: "#34D399",

        appearance: "emerald",

        valueColor: "text-emerald-300",
      },
    ],

    // ============================================
    // PRESSURE ANALYSIS
    // ============================================

    pressureAnalysis: [
      {
        title: "Daytime BP",

        value: `${formatNumber(features?.systolicDayMean)} / ${formatNumber(features?.diastolicDayMean)}`,

        subtitle: "Systolic / Diastolic",

        icon: Sun,

        accent: "#34D399",

        appearance: "emerald",

        valueColor: "text-emerald-300",

        valueClassName: `
          text-[42px]
          lg:text-[46px]
          leading-[0.95]
          tracking-[-0.04em]
        `,
      },

      {
        title: "Nighttime BP",

        value: `${formatNumber(features?.systolicNightMean)} / ${formatNumber(features?.diastolicNightMean)}`,

        subtitle: "Systolic / Diastolic",

        icon: Moon,

        accent: "#D946EF",

        appearance: "fuchsia",

        valueColor: "text-fuchsia-300",

        valueClassName: `
          text-[42px]
          lg:text-[46px]
          leading-[0.95]
          tracking-[-0.04em]
        `,
      },

      {
        title: "Pressure Load",

        value: `${formatNumber(features?.dayPressureLoad, 1)}% / ${formatNumber(features?.nightPressureLoad, 1)}%`,

        subtitle: "Day / Night",

        icon: Gauge,

        accent: "#22D3EE",

        appearance: "cyan",

        valueColor: "text-cyan-300",

        valueClassName: `
          text-[38px]
          lg:text-[42px]
          leading-[0.95]
          tracking-[-0.04em]
        `,
      },
    ],

    // ============================================
    // ADVANCED AI
    // ============================================

    advanced: [
      {
        title: "Fuzzy BP",

        value: formatNumber(features?.fuzzyBPRisk, 2),

        subtitle: "Neuro-Fuzzy",

        icon: ShieldAlert,

        accent: "#FB7185",

        appearance: "rose",

        valueColor: "text-rose-300",
      },

      {
        title: "Load Index",

        value: formatNumber(features?.fuzzyLoadC, 2),

        subtitle: "Hybrid AI",

        icon: Gauge,

        accent: "#22D3EE",

        appearance: "cyan",

        valueColor: "text-cyan-300",
      },

      {
        title: "Nocturnal",

        value: formatNumber(features?.fuzzyNocturnalC, 2),

        subtitle: "Circadian",

        icon: Moon,

        accent: "#D946EF",

        appearance: "fuchsia",

        valueColor: "text-fuchsia-300",
      },

      {
        title: "Heart Rate",

        value: formatNumber(features?.fuzzyHeartRC, 2),

        subtitle: "Neural Model",

        icon: Activity,

        accent: "#34D399",

        appearance: "emerald",

        valueColor: "text-emerald-300",
      },
    ],

    // ============================================
    // RISK OVERVIEW
    // ============================================

    risk: [
      {
        title: "Hypertension",

        value: diagnosis?.hypertension4YearRisk ?? "--",

        subtitle: "4-Year Risk",

        suffix: "%",

        icon: ShieldAlert,

        accent: "#FB7185",

        appearance: "rose",

        valueColor: "text-rose-300",
      },

      {
        title: "Cardiovascular",

        value: diagnosis?.cardiovascularRisk ?? "--",

        subtitle: "Overall Risk",

        suffix: "%",

        icon: Brain,

        accent: "#F59E0B",

        appearance: "amber",

        valueColor: "text-amber-300",
      },

      {
        title: "Heart Age",

        value: diagnosis?.heartAge ?? "--",

        subtitle: "Estimated Age",

        suffix: " yrs",

        icon: Heart,

        accent: "#22D3EE",

        appearance: "cyan",

        valueColor: "text-cyan-300",
      },
    ],
  };
}
