import { Moon, MoonStar, Sunrise, TriangleAlert } from "lucide-react";

import diagnosisPalette from "../palette/diagnosisPalette";

export function getNocturnalTheme(label) {
  switch (label) {
    case "Dipper":
      return {
        ...diagnosisPalette.success,
        diagnosis: "Dipper",
        riskLabel: "Normal Circadian Profile",
        icon: Moon,
        clinicalDiagnosis:
          "Normal nocturnal blood pressure reduction according to ambulatory blood pressure monitoring guidelines.",
      };

    case "Extreme Dipper":
      return {
        ...diagnosisPalette.info,
        diagnosis: "Extreme Dipper",
        riskLabel: "Monitor",
        icon: MoonStar,
        clinicalDiagnosis:
          "Excessive nocturnal blood pressure reduction observed. Clinical correlation is recommended.",
      };

    case "Non Dipper":
      return {
        ...diagnosisPalette.warning,
        diagnosis: "Non Dipper",
        riskLabel: "Elevated Risk",
        icon: Sunrise,
        clinicalDiagnosis:
          "Reduced nocturnal blood pressure decline associated with increased cardiovascular risk.",
      };

    default:
      return {
        ...diagnosisPalette.critical,
        diagnosis: "Riser",
        riskLabel: "High Risk",
        icon: TriangleAlert,
        clinicalDiagnosis:
          "Blood pressure increases during the night indicating a markedly abnormal circadian blood pressure profile.",
      };
  }
}

export default getNocturnalTheme;
