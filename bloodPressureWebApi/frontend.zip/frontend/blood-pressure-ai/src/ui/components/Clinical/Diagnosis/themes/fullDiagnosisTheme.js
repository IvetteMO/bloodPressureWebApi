export default function getFullDiagnosisTheme(diagnosis) {
  if (!diagnosis) {
    return {
      prediction: "--",

      category: "No Diagnosis",

      description: "No diagnosis available.",
    };
  }

  return {
    prediction: diagnosis.finalRiskLevel,

    category: diagnosis.finalRiskLevel,

    description:
      "Final hybrid diagnosis generated from the neuro-fuzzy cardiovascular decision support model.",
  };
}
