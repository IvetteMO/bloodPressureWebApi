import { cn } from "@/ui/utils/cn";

import Panel from "@/ui/components/Panel";

export default function DiagnosisPanel({
  theme,

  children,

  className = "",
}) {
  return (
    <Panel
      variant="diagnosis"
      background={theme?.background}
      className={cn("relative overflow-hidden", theme?.border, className)}
    >
      {/* Reflection */}

      {theme?.reflection && (
        <div
          className={cn(
            "pointer-events-none absolute inset-0",
            theme.reflection,
          )}
        />
      )}

      {/* Glow */}

      {theme?.glow && (
        <div
          className={cn("pointer-events-none absolute inset-0", theme.glow)}
        />
      )}

      <div className="relative z-10">{children}</div>
    </Panel>
  );
}
