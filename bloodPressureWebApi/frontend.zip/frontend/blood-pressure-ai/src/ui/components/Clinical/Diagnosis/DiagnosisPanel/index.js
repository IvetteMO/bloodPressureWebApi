export { default } from "./DiagnosisPanel";
export { default as AIInsightCard } from "./AIInsightCard";
export { default as PredictionCard } from "./PredictionCard";
