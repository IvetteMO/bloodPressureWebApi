export { default as diagnosisPalette } from "./palette/diagnosisPalette";

export { default as getBPDiagnosisTheme } from "./themes/bpDiagnosisTheme";

export { default as getBPLoadTheme } from "./themes/bpLoadTheme";

export { default as getHeartRateTheme } from "./themes/heartRateTheme";

export { default as getNocturnalTheme } from "./themes/nocturnalTheme";

export { default as getHypertensionTheme } from "./themes/hypertensionTheme";

export { default as getCardiovascularTheme } from "./themes/cardiovascularTheme";

// ==============================================
// INTERPRETATION
// ==============================================

export { default as getCardiovascularInterpretation } from "./interpretation/cardiovascularInterpretation";

export { default as getHypertensionInterpretation } from "./interpretation/hypertensionInterpretation";

// ==============================================
// CLASSIFICATION
// ==============================================

export { default as getCardiovascularRiskCategory } from "./classification/cardiovascularRiskCategory";

export { default as getLoadCategory } from "./classification/loadDiagnosis";

export { default as DiagnosisCard } from "./DiagnosisCard";

export { getStudyStatus } from "./classification/studyStatus";
