import { cn } from "@/ui/utils/cn";

import Panel from "@/ui/components/Panel";
import IconBadge from "@/ui/components/IconBadge";

import Stack from "@/ui/primitives/Stack";

import { typography } from "@/ui/foundations";

import aiInsightCardVariants from "./aiInsightCardVariants";

export default function AIInsightCard({
  palette,

  interpretation,

  title = "AI Interpretation",

  variant = "default",

  className = "",
}) {
  if (!palette || !interpretation) {
    return null;
  }

  // ============================================
  // CONFIG
  // ============================================

  const current =
    aiInsightCardVariants[variant] ?? aiInsightCardVariants.default;

  const Icon = palette.icon;

  // ============================================
  // INTERPRETATION
  // ============================================

  const summary =
    typeof interpretation === "string"
      ? interpretation
      : interpretation?.summary;

  const description =
    typeof interpretation === "object" ? interpretation?.description : null;

  // ============================================
  // RENDER
  // ============================================

  return (
    <Panel
      variant="diagnosis"
      background={palette.background}
      effects={palette.glow ? [palette.glow] : undefined}
      className={cn(palette.border, current.panel, className)}
    >
      <Stack gap={current.contentGap}>
        {/* ===================================== */}
        {/* HEADER */}
        {/* ===================================== */}

        <Stack direction="row" gap="md" className={current.header}>
          <IconBadge
            icon={Icon}
            variant="lg"
            appearance={palette.accent}
            lineColor={palette.text}
          />

          <p
            className={cn(
              typography.labelCard,

              variant === "default" ? palette.text : current.title,
            )}
          >
            {title}
          </p>
        </Stack>

        {/* ===================================== */}
        {/* VALUE */}
        {/* ===================================== */}

        <p
          className={cn(
            variant === "default" ? typography.bodyXLarge : current.value,

            variant === "default"
              ? `max-w-[1200px] text-[var(--ui-diagnosis-text-primary)]`
              : palette.text,
          )}
        >
          {summary}
        </p>

        {/* ===================================== */}
        {/* DESCRIPTION */}
        {/* ===================================== */}

        {description && variant !== "default" && (
          <p className={current.description}>{description}</p>
        )}
      </Stack>
    </Panel>
  );
}
