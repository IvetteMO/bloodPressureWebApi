import diagnosisPalette from "../palette/diagnosisPalette";

export function getHypertensionTheme(risk = 0) {
  if (risk < 15) {
    return {
      ...diagnosisPalette.success,
      category: "Minimal Risk",
    };
  }

  if (risk < 30) {
    return {
      ...diagnosisPalette.warning,
      category: "Controlled Risk",
    };
  }

  return {
    ...diagnosisPalette.critical,
    category: "Elevated Risk",
  };
}

export default getHypertensionTheme;
