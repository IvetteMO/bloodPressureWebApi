// ============================================
// Study Status Classification
// ============================================

const studyStatusVariants = {
  COMPLETED: {
    appearance: "success",
    label: "Completed",
  },

  PROCESSING: {
    appearance: "info",
    label: "Processing",
  },

  FAILED: {
    appearance: "danger",
    label: "Failed",
  },

  UNKNOWN: {
    appearance: "neutral",
    label: "Unknown",
  },
};

// ============================================
// GET STUDY STATUS
// ============================================

export function getStudyStatus(status) {
  const normalizedStatus =
    typeof status === "string" ? status.trim().toUpperCase() : "UNKNOWN";

  return studyStatusVariants[normalizedStatus] ?? studyStatusVariants.UNKNOWN;
}

export default studyStatusVariants;
