import { Sparkles, BrainCircuit } from "lucide-react";

const predictionPalette = {
  hypertension: {
    title: "AI Interpretation",

    icon: Sparkles,

    background: "diagnosisInterpretationOrange",

    glow: "diagnosisInterpretationOrangeGlow",

    border: "border-orange-500/20",

    accent: "bg-orange-500/12",

    text: "text-orange-300",
  },

  cardiovascular: {
    title: "AI Cardiovascular Interpretation",

    icon: Sparkles,

    background: "diagnosisInterpretationCyan",

    glow: "diagnosisInterpretationCyanGlow",

    border: "border-cyan-500/20",

    accent: "bg-cyan-500/12",

    text: "text-cyan-300",
  },

  fullDiagnosis: {
    title: "Hybrid AI Interpretation",

    icon: BrainCircuit,

    background: "diagnosisInterpretationBlue",

    glow: "diagnosisInterpretationBlueGlow",

    border: "border-sky-500/20",

    accent: "bg-sky-500/12",

    text: "text-sky-300",
  },
};

export default predictionPalette;
