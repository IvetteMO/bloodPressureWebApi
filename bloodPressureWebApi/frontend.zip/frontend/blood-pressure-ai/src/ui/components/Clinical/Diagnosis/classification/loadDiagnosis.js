/**
 * ============================================================
 * Clinical UI Kit
 * Blood Pressure Load Category
 * ============================================================
 */

export function getLoadCategory(load) {
  const value = Number(load);

  if (Number.isNaN(value)) {
    return {
      status: "info",

      label: "Unknown",

      shortLabel: "--",

      min: null,

      max: null,
    };
  }

  if (value < 20) {
    return {
      status: "success",

      label: "Normal",

      shortLabel: "Normal",

      min: 0,

      max: 19.9,
    };
  }

  if (value < 40) {
    return {
      status: "warning",

      label: "Intermediate",

      shortLabel: "Intermediate",

      min: 20,

      max: 39.9,
    };
  }

  return {
    status: "critical",

    label: "High",

    shortLabel: "High",

    min: 40,

    max: 100,
  };
}

export default getLoadCategory;
