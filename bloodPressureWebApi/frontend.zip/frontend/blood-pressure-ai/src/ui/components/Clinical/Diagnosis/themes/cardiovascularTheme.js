import { HeartPulse, ShieldAlert, TriangleAlert } from "lucide-react";

import diagnosisPalette from "../palette/diagnosisPalette";

export function getCardiovascularTheme(risk) {
  if (risk < 10) {
    return {
      ...diagnosisPalette.success,

      diagnosis: "Low Cardiovascular Risk",

      riskLabel: "Low Risk",

      icon: HeartPulse,

      clinicalDiagnosis:
        "Estimated 10-year cardiovascular risk remains low according to the hybrid prediction model.",
    };
  }

  if (risk < 25) {
    return {
      ...diagnosisPalette.warning,

      diagnosis: "Moderate Cardiovascular Risk",

      riskLabel: "Moderate Risk",

      icon: ShieldAlert,

      clinicalDiagnosis:
        "Moderate probability of future cardiovascular events. Preventive measures and clinical follow-up are recommended.",
    };
  }

  return {
    ...diagnosisPalette.critical,

    diagnosis: "High Cardiovascular Risk",

    riskLabel: "High Risk",

    icon: TriangleAlert,

    clinicalDiagnosis:
      "High estimated probability of cardiovascular events requiring comprehensive clinical evaluation and risk management.",
  };
}

export default getCardiovascularTheme;
