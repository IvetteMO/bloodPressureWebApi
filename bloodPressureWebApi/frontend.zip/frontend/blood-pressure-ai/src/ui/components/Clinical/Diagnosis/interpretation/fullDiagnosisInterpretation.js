export default function getFullDiagnosisInterpretation(diagnosis) {
  if (!diagnosis) {
    return "";
  }

  return `
The patient presents a
${diagnosis.finalRiskLevel}
cardiovascular profile generated through
the hybrid neuro-fuzzy inference system,
integrating ambulatory blood pressure,
circadian rhythm, pressure load,
heart rate dynamics and
clinical cardiovascular risk factors.
`;
}
