import { Activity, HeartPulse, TriangleAlert } from "lucide-react";

import diagnosisPalette from "../palette/diagnosisPalette";

export function getBPDiagnosisTheme(label) {
  switch (label) {
    case "Hypotension":
      return {
        ...diagnosisPalette.info,

        diagnosis: "Hypotension",

        riskLabel: "Low Risk",

        icon: Activity,

        clinicalDiagnosis:
          "Blood pressure remains below normal physiological values. Clinical correlation is recommended if symptoms such as dizziness or syncope are present.",
      };

    case "Optimal":
      return {
        ...diagnosisPalette.success,

        diagnosis: "Optimal",

        riskLabel: "Low Risk",

        clinicalDiagnosis:
          "Ambulatory blood pressure profile is within optimal limits according to the European Society of Hypertension recommendations.",
      };

    case "Normal":
      return {
        ...diagnosisPalette.success,

        diagnosis: "Normal",

        riskLabel: "Low Risk",

        clinicalDiagnosis:
          "Blood pressure remains within the normal ambulatory range without evidence of hypertension.",
      };

    case "High Normal":
      return {
        ...diagnosisPalette.warning,

        diagnosis: "High Normal",

        riskLabel: "Monitor",

        icon: HeartPulse,

        clinicalDiagnosis:
          "Blood pressure approaches hypertensive thresholds. Lifestyle modifications and periodic monitoring are recommended.",
      };

    case "Grade 1 Hypertension":
      return {
        ...diagnosisPalette.critical,

        diagnosis: "Grade 1 Hypertension",

        riskLabel: "Moderate Risk",

        clinicalDiagnosis:
          "Mild ambulatory hypertension according to the European Society of Hypertension classification.",
      };

    case "Grade 2 Hypertension":
      return {
        ...diagnosisPalette.critical,

        diagnosis: "Grade 2 Hypertension",

        riskLabel: "High Risk",

        icon: TriangleAlert,

        clinicalDiagnosis:
          "Marked elevation in ambulatory blood pressure requiring comprehensive clinical evaluation.",
      };

    default:
      return {
        ...diagnosisPalette.critical,

        diagnosis: "Grade 3 Hypertension",

        riskLabel: "Critical",

        icon: TriangleAlert,

        clinicalDiagnosis:
          "Severe ambulatory hypertension requiring immediate clinical assessment according to current European hypertension guidelines.",
      };
  }
}

export default getBPDiagnosisTheme;
