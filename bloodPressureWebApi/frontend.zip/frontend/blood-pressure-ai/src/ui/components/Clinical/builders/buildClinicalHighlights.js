import { Moon, HeartPulse, Gauge } from "lucide-react";

import getNocturnalTheme from "../Diagnosis/themes/nocturnalTheme";

import getHeartRateTheme from "../Diagnosis/themes/heartRateTheme";

import getBPLoadTheme from "../Diagnosis/themes/bpLoadTheme";

export default function buildClinicalHighlights(diagnosis) {
  if (!diagnosis) return [];

  return [
    {
      title: "Nocturnal Pattern",
      diagnosis: diagnosis.nocturnalProfile,
      icon: Moon,
      theme: getNocturnalTheme(diagnosis.nocturnalProfile),
    },

    {
      title: "Heart Rate",
      diagnosis: diagnosis.heartRateDiagnosis,
      icon: HeartPulse,
      theme: getHeartRateTheme(diagnosis.heartRateDiagnosis),
    },

    {
      title: "Pressure Load",
      diagnosis: diagnosis.loadDiagnosis,
      icon: Gauge,
      theme: getBPLoadTheme(diagnosis.loadDiagnosis),
    },
  ];
}
