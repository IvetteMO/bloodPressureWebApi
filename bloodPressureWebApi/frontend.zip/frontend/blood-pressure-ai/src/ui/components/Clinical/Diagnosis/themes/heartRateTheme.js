import { HeartPulse, Heart, Activity, TriangleAlert } from "lucide-react";

import diagnosisPalette from "../palette/diagnosisPalette";

export function getHeartRateTheme(label) {
  switch (label) {
    case "Low":
      return {
        ...diagnosisPalette.info,

        diagnosis: "Low",

        riskLabel: "Low Heart Rate",

        icon: Activity,

        clinicalDiagnosis:
          "Heart rate remains below the expected physiological range. Clinical correlation is recommended if symptoms are present.",
      };

    case "Below Normal":
      return {
        ...diagnosisPalette.info,

        diagnosis: "Below Normal",

        riskLabel: "Monitor",

        icon: Activity,

        clinicalDiagnosis:
          "Heart rate is slightly below the normal physiological range without evidence of significant abnormality.",
      };

    case "Excellent":
      return {
        ...diagnosisPalette.success,

        diagnosis: "Excellent",

        riskLabel: "Optimal",

        icon: HeartPulse,

        clinicalDiagnosis:
          "Heart rate profile is within optimal physiological limits indicating excellent cardiovascular adaptation.",
      };

    case "Above Normal":
      return {
        ...diagnosisPalette.warning,

        diagnosis: "Above Normal",

        riskLabel: "Monitor",

        icon: Heart,

        clinicalDiagnosis:
          "Heart rate is above the expected physiological range suggesting increased cardiovascular workload.",
      };

    default:
      return {
        ...diagnosisPalette.critical,

        diagnosis: "Very High",

        riskLabel: "Critical",

        icon: TriangleAlert,

        clinicalDiagnosis:
          "Marked elevation in heart rate associated with increased cardiovascular demand requiring clinical evaluation.",
      };
  }
}

export default getHeartRateTheme;
