import {
  getNocturnalTheme,
  getHeartRateTheme,
  getBPLoadTheme,
} from "@/ui/components/Clinical/Diagnosis";

export default function buildDiagnosisSummary(diagnosis) {
  if (!diagnosis) return [];

  return [
    {
      title: "Nocturnal Pattern",

      diagnosis: diagnosis.nocturnalProfile,

      palette: getNocturnalTheme(diagnosis.nocturnalProfile),
    },

    {
      title: "Heart Rate",

      diagnosis: diagnosis.heartRateDiagnosis,

      palette: getHeartRateTheme(diagnosis.heartRateDiagnosis),
    },

    {
      title: "Pressure Load",

      diagnosis: diagnosis.loadDiagnosis,

      palette: getBPLoadTheme(diagnosis.loadDiagnosis),
    },
  ];
}
