import { Moon, HeartPulse, Gauge } from "lucide-react";

import ClinicalHighlightCard from "@/ui/components/DataDisplay/ClinicalHighlightCard";

import { getNocturnalThemeByLabel } from "../themes/nocturnalTheme";

import { getHeartRateThemeByLabel } from "../../utils/hrDiagnosisThemeByLabels";

import { getBPLoadThemeByLabel } from "../../utils/bpLoadDiagnosisThemeByLabels";

import { layout } from "../../../../theme/layout";
import { spacing } from "../../../../theme/spacing/spacing";

function DiagnosticInterpretationSection({ diagnosis }) {
  if (!diagnosis) return null;

  const nocturnalTheme = getNocturnalThemeByLabel(diagnosis.nocturnalProfile);

  const hrTheme = getHeartRateThemeByLabel(diagnosis.heartRateDiagnosis);

  const loadTheme = getBPLoadThemeByLabel(diagnosis.loadDiagnosis);

  return (
    <div className={`${layout.riskflex} ${spacing.stack}`}>
      <ClinicalHighlightCard
        icon={Moon}
        title="Nocturnal Pattern"
        diagnosis={diagnosis.nocturnalProfile}
        theme={nocturnalTheme}
      />

      <ClinicalHighlightCard
        icon={HeartPulse}
        title="Heart Rate"
        diagnosis={diagnosis.heartRateDiagnosis}
        theme={hrTheme}
      />

      <ClinicalHighlightCard
        icon={Gauge}
        title="Pressure Load"
        diagnosis={diagnosis.loadDiagnosis}
        theme={loadTheme}
      />
    </div>
  );
}

export default DiagnosticInterpretationSection;
