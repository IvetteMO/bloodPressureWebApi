export { getHypertensionInterpretation } from "./hypertensionInterpretation";
export { getCardiovascularInterpretation } from "./cardiovascularInterpretation";
