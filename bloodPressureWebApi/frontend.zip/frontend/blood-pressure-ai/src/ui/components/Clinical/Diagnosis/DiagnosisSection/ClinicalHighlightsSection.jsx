import Panel from "@/ui/components/Panel";

import Grid from "@/ui/primitives/Grid";

import ClinicalHighlightCard from "../DiagnosisCard/ClinicalHighlightCard";

import buildClinicalHighlights from "../../builders/buildClinicalHighlights";

export default function ClinicalHighlightsSection({ diagnosis }) {
  const items = buildClinicalHighlights(diagnosis);

  return (
    <Panel variant="section" background="section">
      <Grid columns={3} gap="lg">
        {items.map((item) => (
          <ClinicalHighlightCard key={item.title} {...item} />
        ))}
      </Grid>
    </Panel>
  );
}
