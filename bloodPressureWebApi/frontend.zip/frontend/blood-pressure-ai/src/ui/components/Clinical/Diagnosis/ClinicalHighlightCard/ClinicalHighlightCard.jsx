import { cn } from "@/ui/utils/cn";

import Panel from "@/ui/components/Panel";
import IconBadge from "@/ui/components/IconBadge";
import Stack from "@/ui/primitives/Stack";
import { typography } from "@/ui/foundations";

export default function ClinicalHighlightCard({
  icon: Icon,
  title,
  diagnosis,
  theme,
  className = "",
}) {
  if (!theme) return null;

  return (
    <Panel
      variant="diagnosis"
      background={theme.background}
      effects={[theme.glow]}
      className={cn(theme.border, "min-h-[165px]", className)}
    >
      <Stack className="h-full" gap="md">
        <Stack direction="row" gap="md" className="items-center">
          <IconBadge
            icon={Icon}
            variant="lg"
            appearance={theme.accent}
            lineColor={theme.text}
          />

          <h3
            className={cn(
              typography.metricLabel,
              "tracking-[0.25em] uppercase",
            )}
          >
            {title}
          </h3>
        </Stack>

        {/* CONTENT */}

        <div className="flex flex-1 items-center justify-center pt-6">
          <h2
            className={cn(
              typography.display,
              theme.text,
              "text-center leading-none",
            )}
          >
            {diagnosis}
          </h2>
        </div>
      </Stack>
    </Panel>
  );
}
