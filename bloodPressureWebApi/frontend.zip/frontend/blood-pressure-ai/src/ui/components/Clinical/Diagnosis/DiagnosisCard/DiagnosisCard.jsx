import { ShieldAlert } from "lucide-react";

import { cn } from "@/ui/utils/cn";

import Panel from "@/ui/components/Panel";
import IconBadge from "@/ui/components/IconBadge";
import Stack from "@/ui/primitives/Stack";

import { typography } from "@/ui/foundations";

import DiagnosisBadge from "../DiagnosisBadge/DiagnosisBadge";

export default function DiagnosisCard({
  theme,
  title = "Clinical Assessment",
  className = "",
}) {
  if (!theme) return null;

  const {
    diagnosis,
    riskLabel,
    clinicalDiagnosis,

    icon: Icon = ShieldAlert,

    accent,
    text,

    glow,
    border,

    status,
  } = theme;

  return (
    <Panel
      variant="diagnosis"
      background={theme.background}
      effects={[glow]}
      className={cn(border, className)}
    >
      <Stack gap="lg" className="h-full">
        {/* HEADER */}

        <div className="flex justify-between items-start gap-6">
          <Stack direction="row" gap="lg" align="center">
            <IconBadge icon={Icon} appearance={accent} variant="xl" />

            <Stack gap="xs">
              <p
                className={cn(
                  typography.metricLabel,
                  "tracking-[0.34em] uppercase",
                )}
              >
                Diagnosis
              </p>

              <h3 className={typography.sectionTitle}>{title}</h3>
            </Stack>
          </Stack>

          <DiagnosisBadge status={status}>{riskLabel}</DiagnosisBadge>
        </div>

        {/* DIAGNOSIS */}

        <h1 className={cn(typography.display, text)}>{diagnosis}</h1>

        {/* DESCRIPTION */}

        <p
          className={cn(
            typography.bodyLarge,
            "max-w-3xl text-[var(--ui-diagnosis-text-secondary)]",
          )}
        >
          {clinicalDiagnosis}
        </p>
      </Stack>
    </Panel>
  );
}
