/**
 * ============================================================
 * Clinical UI Kit
 * Hypertension Interpretation
 * ============================================================
 */

export function getHypertensionInterpretation(risk = 0) {
  const value = Number(risk);

  if (Number.isNaN(value)) {
    return {
      title: "Unavailable",

      summary:
        "Hypertension risk could not be estimated because the supplied value is invalid.",

      recommendation:
        "Verify the calculated probability before generating the clinical interpretation.",
    };
  }

  // ============================================
  // MINIMAL
  // ============================================

  if (risk < 15) {
    return {
      title: "Minimal Risk",

      summary:
        "Current physiological and clinical indicators suggest a low probability of hypertension development in the medium term.",

      recommendation:
        "Maintain healthy dietary habits, regular physical activity and routine blood pressure monitoring.",
    };
  }

  // ============================================
  // CONTROLLED
  // ============================================

  if (risk < 30) {
    return {
      title: "Controlled Risk",

      summary:
        "The patient presents moderate indicators associated with future hypertension development. Continuous monitoring is recommended.",

      recommendation:
        "Increase cardiovascular prevention strategies and perform periodic blood pressure evaluations.",
    };
  }

  // ============================================
  // HIGH
  // ============================================

  return {
    title: "Elevated Risk",

    summary:
      "The patient presents elevated cardiovascular indicators associated with future hypertension development and requires continuous clinical follow-up.",

    recommendation:
      "Medical evaluation, lifestyle intervention and strict cardiovascular surveillance are recommended.",
  };
}

export default getHypertensionInterpretation;
