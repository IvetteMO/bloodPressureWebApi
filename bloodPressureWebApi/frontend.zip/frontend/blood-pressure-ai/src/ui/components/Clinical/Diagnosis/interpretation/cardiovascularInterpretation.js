/**
 * ============================================================
 * Clinical UI Kit
 * Cardiovascular Interpretation
 * ============================================================
 */

export function getCardiovascularInterpretation(risk) {
  const value = Number(risk);

  if (Number.isNaN(value)) {
    return {
      title: "Unavailable",

      summary:
        "The cardiovascular risk could not be estimated because the provided value is invalid.",

      recommendation:
        "Verify the calculated risk before performing a clinical interpretation.",
    };
  }

  if (value < 10) {
    return {
      title: "Low Cardiovascular Risk",

      summary:
        "The estimated probability of experiencing a cardiovascular event within the next ten years is low. The current cardiovascular profile is considered favorable.",

      recommendation:
        "Maintain healthy lifestyle habits, continue routine medical follow-up, and reinforce preventive cardiovascular strategies.",
    };
  }

  if (value < 20) {
    return {
      title: "Moderate Cardiovascular Risk",

      summary:
        "A moderate probability of future cardiovascular events was identified. Preventive interventions may reduce long-term cardiovascular burden.",

      recommendation:
        "Promote lifestyle modifications, periodic monitoring, and individualized clinical assessment according to current cardiovascular prevention guidelines.",
    };
  }

  return {
    title: "High Cardiovascular Risk",

    summary:
      "A high probability of cardiovascular events has been identified. The patient may require intensive risk management and comprehensive clinical evaluation.",

    recommendation:
      "Immediate cardiovascular assessment is recommended together with aggressive management of modifiable risk factors.",
  };
}

export default getCardiovascularInterpretation;
