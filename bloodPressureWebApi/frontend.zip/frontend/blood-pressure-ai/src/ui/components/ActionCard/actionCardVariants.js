const actionCardVariants = {
  fuchsia: {
    card: `
      border-fuchsia-500/10
      hover:border-cyan-400/20
    `,

    glow: `
      from-fuchsia-500/[0.05]
      to-cyan-400/[0.05]
    `,

    icon: `
      bg-fuchsia-500/10
      text-fuchsia-300
    `,
  },

  cyan: {
    card: `
      border-cyan-500/10
      hover:border-fuchsia-400/20
    `,

    glow: `
      from-cyan-500/[0.05]
      to-fuchsia-500/[0.05]
    `,

    icon: `
      bg-cyan-500/10
      text-cyan-300
    `,
  },

  emerald: {
    card: `
      border-emerald-500/10
      hover:border-cyan-400/20
    `,

    glow: `
      from-emerald-500/[0.05]
      to-cyan-400/[0.05]
    `,

    icon: `
      bg-emerald-500/10
      text-emerald-300
    `,
  },
};

export default actionCardVariants;
