import { cn } from "@/ui/utils/cn";

import actionCardVariants from "./actionCardVariants";

export default function ActionCard({
  icon: Icon,

  title,

  subtitle,

  accent = "fuchsia",

  onClick,

  children,

  className = "",
}) {
  const current = actionCardVariants[accent] ?? actionCardVariants.fuchsia;

  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        `group relative flex w-full items-center justify-between overflow-hidden rounded-[28px] border bg-[var(--ui-surface-glass-bg)] p-6 transition-all duration-300`,

        current.card,

        className,
      )}
    >
      <div
        className={cn(
          `absolute inset-0 bg-gradient-to-r opacity-0 transition-opacity duration-300 group-hover:opacity-100`,
          current.glow,
        )}
      />

      <div className="relative z-10 flex items-center gap-5">
        {Icon && (
          <div
            className={cn(
              `flex h-14 w-14 items-center justify-center rounded-2xl`,
              current.icon,
            )}
          >
            <Icon size={24} />
          </div>
        )}

        <div className="text-left">
          <h3 className="text-lg font-bold text-[var(--ui-text-heading)]">
            {title}
          </h3>

          {subtitle && (
            <p className="mt-1 text-sm text-[var(--ui-text-body)]">
              {subtitle}
            </p>
          )}

          {children}
        </div>
      </div>
    </button>
  );
}
