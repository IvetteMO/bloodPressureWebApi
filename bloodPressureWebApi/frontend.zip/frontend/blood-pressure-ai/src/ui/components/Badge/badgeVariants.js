const badgeVariants = {
  violet: `
    inline-flex
    items-center

    rounded-full

    border
    border-fuchsia-500/20

    bg-gradient-to-r
    from-fuchsia-500/20
    to-cyan-400/20

    px-4
    py-2

    text-xs
    font-semibold

    text-fuchsia-300
  `,

  cyan: `
    inline-flex
    items-center

    rounded-full

    border
    border-cyan-500/20

    bg-gradient-to-r
    from-cyan-500/20
    to-violet-500/20

    px-4
    py-2

    text-xs
    font-semibold

    text-cyan-300
  `,

  emerald: `
    inline-flex
    items-center

    rounded-full

    border
    border-emerald-500/20

    bg-gradient-to-r
    from-emerald-500/20
    to-cyan-500/20

    px-4
    py-2

    text-xs
    font-semibold

    text-emerald-300
  `,
};

export default badgeVariants;
