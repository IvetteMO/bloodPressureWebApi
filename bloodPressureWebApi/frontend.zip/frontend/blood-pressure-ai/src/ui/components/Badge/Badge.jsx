import { cn } from "@/ui/utils/cn";

import badgeVariants from "./badgeVariants";

export default function Badge({
  variant = "violet",

  children,

  items,

  className = "",
}) {
  const current = badgeVariants[variant] ?? badgeVariants.violet;

  if (items?.length) {
    return (
      <div className="mt-4 flex flex-wrap gap-3">
        {items.map((item, index) => (
          <span key={index} className={cn(current, className)}>
            {item}
          </span>
        ))}
      </div>
    );
  }

  if (!children) return null;

  return <span className={cn(current, className)}>{children}</span>;
}
