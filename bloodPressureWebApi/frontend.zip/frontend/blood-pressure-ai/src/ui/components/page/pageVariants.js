/**
 * ============================================================
 * Clinical UI Kit
 * Page Variants
 * ============================================================
 */

const pageVariants = {
  default: {
    maxWidth: "max-w-[1800px]",

    spacing: "space-y-8",
  },

  compact: {
    maxWidth: "max-w-[1600px]",

    spacing: "space-y-6",
  },

  spacious: {
    maxWidth: "max-w-[1920px]",

    spacing: "space-y-10",
  },
};

export default pageVariants;
