export { default } from "./Page";
