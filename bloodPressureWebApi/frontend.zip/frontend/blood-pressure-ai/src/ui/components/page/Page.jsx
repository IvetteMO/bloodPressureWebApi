import { cn } from "@/ui/utils/cn";

import { spacing } from "@/ui/foundations";

import pageVariants from "./pageVariants";

export default function Page({
  children,

  variant = "default",

  className = "",
}) {
  const current = pageVariants[variant] ?? pageVariants.default;

  return (
    <main
      className={cn(
        "mx-auto w-full",

        current.maxWidth,

        spacing.page,

        current.spacing,

        className,
      )}
    >
      {children}
    </main>
  );
}
