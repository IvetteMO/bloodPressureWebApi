const buttonSizes = {
  sm: `
px-5
py-2.5

text-sm
`,

  md: `
px-7
py-3.5

text-sm
`,

  lg: `
px-8
py-4

text-base
`,

  hero: `
px-10
py-5

text-lg
font-semibold
`,

  icon: `
w-12
h-12
`,
};

export default buttonSizes;
