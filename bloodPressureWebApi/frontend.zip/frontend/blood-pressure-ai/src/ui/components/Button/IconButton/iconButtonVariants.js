/**
 * ============================================================
 * Clinical UI Kit
 * Icon Button Variants
 * ============================================================
 */

const base = `
relative

flex
items-center
justify-center

h-12
w-12

rounded-[16px]

border

transition-all
duration-300

hover:scale-110

active:scale-95
`;

const iconButtonVariants = {
  default: {
    button: `
${base}

border-[var(--ui-control-border)]

bg-[var(--ui-control-bg)]

text-[var(--ui-control-text)]

hover:bg-[var(--ui-control-bg-hover)]
`,
  },

  ghost: {
    button: `
${base}

border-[var(--ui-surface-border)]

bg-transparent

text-[var(--ui-text-heading)]

hover:bg-[var(--ui-overlay-light)]

hover:border-[var(--ui-surface-accent-border)]
`,
  },

  header: {
    button: `
        ${base}

        border-[var(--ui-header-control-border)]

        bg-[var(--ui-header-control-bg)]

        text-[var(--ui-header-control-text)]

        backdrop-blur-xl

        hover:bg-[var(--ui-header-control-hover)]

        hover:border-[var(--ui-header-control-border-hover)]
    `,
  },

  cyan: {
    button: `
${base}

border-cyan-500/10

bg-cyan-500/10

text-cyan-300
`,
  },

  violet: {
    button: `
${base}

border-fuchsia-500/10

bg-fuchsia-500/10

text-fuchsia-300
`,
  },

  success: {
    button: `
${base}

border-emerald-500/10

bg-emerald-500/10

text-emerald-300
`,
  },

  danger: {
    button: `
${base}

border-rose-500/10

bg-rose-500/10

text-rose-300
`,
  },

  navigation: {
    button: `
${base}

border-[var(--ui-nav-control-border)]

bg-[var(--ui-nav-control-bg)]

text-[var(--ui-nav-control-text)]

backdrop-blur-xl

hover:bg-[var(--ui-nav-control-bg-hover)]
`,
  },
};

export default iconButtonVariants;
