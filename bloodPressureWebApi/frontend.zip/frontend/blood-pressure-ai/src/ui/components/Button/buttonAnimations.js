export const buttonAnimations = {
  glow: `
absolute
inset-0

rounded-full

opacity-0

bg-gradient-to-r
from-fuchsia-500/10
via-violet-400/10
to-cyan-400/10

blur-xl

transition-all
duration-500

group-hover:opacity-100
`,

  shine: `
absolute

top-0
bottom-0

-left-[12%]

w-[12%]

bg-white/10

blur-md

skew-x-[-22deg]

transition-all
duration-700

group-hover:left-[112%]
`,
};
