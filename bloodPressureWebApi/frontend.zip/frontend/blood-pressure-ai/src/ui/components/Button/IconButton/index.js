export { default } from "./IconButton";
