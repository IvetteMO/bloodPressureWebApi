const buttonVariants = {
  primary: `
    border
    border-[var(--ui-button-primary-border)]

    bg-gradient-to-r
    from-[var(--ui-button-primary-from)]
    via-[var(--ui-button-primary-via)]
    to-[var(--ui-button-primary-to)]

    text-[var(--ui-button-primary-text)]
  `,

  secondary: `
    border
    border-[var(--ui-button-secondary-border)]

    bg-[var(--ui-button-secondary-bg)]

    text-[var(--ui-button-secondary-text)]
  `,

  ghost: `
    border
    border-transparent

    bg-transparent

    text-[var(--ui-button-ghost-text)]

    hover:bg-[var(--ui-button-ghost-hover)]
  `,

  success: `
    border
    border-[var(--ui-button-success-border)]

    bg-gradient-to-r
    from-[var(--ui-button-success-from)]
    to-[var(--ui-button-success-to)]

    text-[var(--ui-button-success-text)]
  `,

  danger: `
    border
    border-[var(--ui-button-danger-border)]

    bg-gradient-to-r
    from-[var(--ui-button-danger-from)]
    to-[var(--ui-button-danger-to)]

    text-[var(--ui-button-danger-text)]
  `,

  selectable: `
    rounded-full
    border
    border-[var(--ui-border-subtle)]

    bg-[var(--ui-bg-subtle)]

    text-[var(--ui-text-primary)]

    transition-all
    duration-300

    hover:border-fuchsia-400/25
    hover:bg-fuchsia-400/[0.06]
    hover:text-[var(--ui-text-primary)]

    focus-visible:outline-none
    focus-visible:ring-2
    focus-visible:ring-fuchsia-400/40
  `,

  selectableActive: `
    rounded-full
    border
    border-fuchsia-400/30

    bg-gradient-to-r
    from-fuchsia-500/20
    to-cyan-400/10

    text-[var(--ui-text-primary)]

    shadow-[0_0_25px_rgba(217,70,239,0.18)]

    transition-all
    duration-300

    focus-visible:outline-none
    focus-visible:ring-2
    focus-visible:ring-fuchsia-400/40
  `,
};

export default buttonVariants;
