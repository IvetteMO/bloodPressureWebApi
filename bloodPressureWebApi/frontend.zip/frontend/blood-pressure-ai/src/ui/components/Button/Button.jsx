import { cn } from "@/ui/utils/cn";

import buttonVariants from "./buttonVariants";
import buttonSizes from "./buttonSizes";
import { buttonAnimations } from "./buttonAnimations";

export default function Button({
  children,

  variant = "primary",

  size = "lg",

  leftIcon,

  rightIcon,

  fullWidth = false,

  loading = false,

  disabled = false,

  type = "button",

  className = "",

  onClick,
}) {
  return (
    <button
      type={type}
      disabled={disabled || loading}
      onClick={onClick}
      className={cn(
        `group relative inline-flex items-center justify-center overflow-hidden rounded-full font-semibold backdrop-blur-xl transition-all duration-500 hover:-translate-y-[2px] hover:scale-[1.015] hover:shadow-[var(--ui-interaction-hover-shadow)] active:scale-[0.985] disabled:pointer-events-none disabled:opacity-50`,
        buttonVariants[variant],
        buttonSizes[size],
        fullWidth && "w-full",
        className,
      )}
    >
      {/* Glow */}

      <span className={buttonAnimations.glow} />

      {/* Reflection */}

      <span className="pointer-events-none absolute inset-0 bg-[var(--ui-reflection-soft)]" />

      {/* Shine */}

      <span className={buttonAnimations.shine} />

      {/* Content */}

      <span className="relative z-10 flex items-center justify-center gap-3">
        {leftIcon}

        {loading ? "Loading..." : children}

        {rightIcon}
      </span>
    </button>
  );
}
