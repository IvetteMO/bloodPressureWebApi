import { cn } from "@/ui/utils/cn";

import iconButtonVariants from "./iconButtonVariants";

export default function IconButton({
  icon: Icon,

  variant = "default",

  size = 18,

  onClick,

  disabled = false,

  title,

  className = "",

  ...props
}) {
  const current = iconButtonVariants[variant] ?? iconButtonVariants.default;

  const buttonClass = typeof current === "string" ? current : current.button;

  return (
    <button
      type="button"
      title={title}
      disabled={disabled}
      onClick={onClick}
      className={cn(
        buttonClass,
        disabled && "cursor-not-allowed opacity-50",
        className,
      )}
      {...props}
    >
      {Icon && <Icon size={size} className="top-px relative shrink-0" />}
    </button>
  );
}
