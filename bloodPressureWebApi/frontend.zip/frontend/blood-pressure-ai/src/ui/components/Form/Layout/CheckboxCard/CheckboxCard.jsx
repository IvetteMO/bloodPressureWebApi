import { cn } from "@/ui/utils/cn";

import Stack from "@/ui/primitives/Stack";

import checkboxVariants from "./checkboxVariants";

export default function CheckboxCard({
  title,
  description,
  checked = false,
  onChange,
  disabled = false,
  className = "",
}) {
  return (
    <label
      className={cn(
        checkboxVariants.root,
        checked && checkboxVariants.checked,
        disabled && "cursor-not-allowed opacity-50",
        className,
      )}
    >
      <Stack direction="row" gap="sm" align="start">
        <input
          type="checkbox"
          checked={checked}
          disabled={disabled}
          onChange={(e) => onChange?.(e.target.checked)}
          className={checkboxVariants.input}
        />

        <div className="flex-1">
          <h3 className={checkboxVariants.title}>{title}</h3>

          {description && (
            <p className={checkboxVariants.description}>{description}</p>
          )}
        </div>
      </Stack>
    </label>
  );
}
