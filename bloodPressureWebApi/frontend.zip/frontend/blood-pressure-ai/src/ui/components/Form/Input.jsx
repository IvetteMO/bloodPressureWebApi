import { forwardRef } from "react";

import { cn } from "@/ui/utils/cn";

import inputVariants from "@/ui/foundations/forms/inputVariants";

import Field from "./Field";
import Label from "./Label";
import HelperText from "./HelperText";

const Input = forwardRef(function Input(
  {
    label,
    helper,
    error,

    required = false,

    size = "md",

    className = "",

    ...props
  },
  ref,
) {
  return (
    <Field>
      {label && <Label required={required}>{label}</Label>}

      <input
        ref={ref}
        className={cn(
          inputVariants({
            size,
            invalid: !!error,
            disabled: props.disabled,
          }),
          className,
        )}
        {...props}
      />

      <HelperText error={!!error}>{error || helper}</HelperText>
    </Field>
  );
});

export default Input;
