import Panel from "@/ui/components/Panel";

import Stack from "@/ui/primitives/Stack";

import SectionHeader from "./SectionHeader";

export default function FormSection({
  title,
  subtitle,

  action,

  children,

  background = "card",

  className = "",
}) {
  return (
    <Panel background={background} className={className}>
      <Stack gap="xl">
        {(title || subtitle) && (
          <SectionHeader title={title} subtitle={subtitle} action={action} />
        )}

        {children}
      </Stack>
    </Panel>
  );
}
