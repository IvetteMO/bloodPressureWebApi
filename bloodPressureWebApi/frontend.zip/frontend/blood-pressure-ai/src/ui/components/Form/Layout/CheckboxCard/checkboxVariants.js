export const checkboxVariants = {
  root: `
group
flex
items-start
gap-4

rounded-[24px]

border
border-[var(--ui-border-default)]

bg-[var(--ui-form-bg)]

p-5

transition-all
duration-300

hover:border-[var(--ui-border-strong)]
hover:bg-[var(--ui-form-focus-bg)]
`,

  checked: `
border-cyan-400/35
bg-cyan-500/[0.06]
`,

  input: `
mt-1

h-5
w-5

rounded-md

border
border-[var(--ui-border-default)]

bg-[var(--ui-form-bg)]

text-cyan-400

accent-cyan-400

focus:ring-2
focus:ring-cyan-400/30

transition-colors
`,

  title: `
font-semibold
text-[var(--ui-text-heading)]
`,

  description: `
mt-1
text-sm
text-[var(--ui-text-body)]
`,
};

export default checkboxVariants;
