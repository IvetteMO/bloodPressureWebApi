import { forwardRef } from "react";

import { cn } from "@/ui/utils/cn";

import selectVariants from "@/ui/foundations/forms/selectVariants";

import Field from "./Field";
import Label from "./Label";
import HelperText from "./HelperText";

const Select = forwardRef(function Select(
  {
    label,
    helper,
    error,

    required = false,

    options = [],

    className = "",

    ...props
  },
  ref,
) {
  return (
    <Field>
      {label && <Label required={required}>{label}</Label>}

      <select
        ref={ref}
        className={cn(
          selectVariants({
            invalid: !!error,
            disabled: props.disabled,
          }),
          className,
        )}
        {...props}
      >
        {options.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>

      <HelperText error={!!error}>{error || helper}</HelperText>
    </Field>
  );
});

export default Select;
