import { cn } from "@/ui/utils/cn";

import Stack from "@/ui/primitives/Stack";

import { typography } from "@/ui/foundations";

export default function SectionHeader({
  title,
  subtitle,
  action,
  className = "",
}) {
  return (
    <Stack
      direction="row"
      justify="between"
      align="start"
      className={cn(className)}
    >
      <div>
        <h2 className={typography.labelCard}>{title}</h2>

        {subtitle && <p className={cn(typography.body, "mt-2")}>{subtitle}</p>}
      </div>

      {action}
    </Stack>
  );
}
