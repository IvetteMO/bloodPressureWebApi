import { cn } from "@/ui/utils/cn";
import Stack from "@/ui/primitives/Stack";

export default function FooterActions({
  children,

  className = "",
}) {
  return (
    <Stack
      direction="row"
      gap="md"
      className={cn(
        `mt-8 justify-end border-t border-white/[0.05] pt-8`,
        className,
      )}
    >
      {children}
    </Stack>
  );
}
