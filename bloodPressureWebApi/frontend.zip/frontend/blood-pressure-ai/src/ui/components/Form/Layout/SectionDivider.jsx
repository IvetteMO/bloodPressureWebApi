import { cn } from "@/ui/utils/cn";

import Stack from "@/ui/primitives/Stack";

import { typography } from "@/ui/foundations";

export default function SectionDivider({
  title,

  className = "",
}) {
  return (
    <Stack
      direction="row"
      align="center"
      gap="lg"
      className={cn("py-2", className)}
    >
      {/* LEFT */}

      <div className="h-px flex-1 bg-gradient-to-r from-transparent via-violet-400/20 to-violet-400/40" />

      {/* TITLE */}

      <span
        className={cn(typography.eyebrow, "whitespace-nowrap text-white/45")}
      >
        {title}
      </span>

      {/* RIGHT */}

      <div className="h-px flex-1 bg-gradient-to-l from-transparent via-violet-400/20 to-violet-400/40" />
    </Stack>
  );
}
