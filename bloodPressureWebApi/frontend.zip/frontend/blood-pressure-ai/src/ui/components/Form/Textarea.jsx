import { forwardRef } from "react";

import { cn } from "@/ui/utils/cn";

import textareaVariants from "@/ui/foundations/forms/textareaVariants";

import Field from "./Field";
import Label from "./Label";
import HelperText from "./HelperText";

const Textarea = forwardRef(function Textarea(
  {
    label,
    helper,
    error,

    required = false,

    className = "",

    ...props
  },
  ref,
) {
  return (
    <Field>
      {label && <Label required={required}>{label}</Label>}

      <textarea
        ref={ref}
        className={cn(
          textareaVariants({
            invalid: !!error,
            disabled: props.disabled,
          }),
          className,
        )}
        {...props}
      />

      <HelperText error={!!error}>{error || helper}</HelperText>
    </Field>
  );
});

export default Textarea;
