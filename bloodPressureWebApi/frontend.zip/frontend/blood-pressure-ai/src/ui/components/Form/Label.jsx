import { cn } from "@/ui/utils/cn";

import { labelVariants } from "@/ui/foundations/forms";

export default function Label({ children, required = false, className = "" }) {
  return (
    <label className={cn(labelVariants.label, className)}>
      {children}

      {required && <span className={labelVariants.required}>*</span>}
    </label>
  );
}
