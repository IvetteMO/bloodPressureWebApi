import { cn } from "@/ui/utils/cn";

import Grid from "@/ui/primitives/Grid";

export default function FieldGroup({ children, columns = 2, className = "" }) {
  return (
    <Grid columns={columns} className={cn(className)}>
      {children}
    </Grid>
  );
}
