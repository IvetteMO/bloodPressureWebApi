import { useRef } from "react";
import { Upload } from "lucide-react";

import { cn } from "@/ui/utils/cn";

import Panel from "@/ui/components/Panel";
import Stack from "@/ui/primitives/Stack";

import { typography, spacing } from "@/ui/foundations";

export default function FileDropzone({
  label,
  description,

  accept,

  value,

  onChange,

  icon: Icon = Upload,

  height = "dropzoneLg",

  disabled = false,

  className = "",
}) {
  const inputRef = useRef(null);

  const handleClick = () => {
    if (disabled) return;

    inputRef.current?.click();
  };

  const handleFile = (e) => {
    const file = e.target.files?.[0];

    if (!file) return;

    onChange?.(file);
  };

  return (
    <Panel
      variant="dropzone"
      interactive={!disabled}
      className={cn(
        "border-2 border-dashed border-fuchsia-500/15",

        "transition-all duration-300",

        "hover:border-cyan-400/30",

        className,
      )}
      onClick={handleClick}
    >
      <input
        ref={inputRef}
        type="file"
        accept={accept}
        hidden
        disabled={disabled}
        onChange={handleFile}
      />

      <div
        className={cn(
          "flex items-center justify-center",

          spacing[height],
        )}
      >
        <Stack gap="lg" className="items-center text-center">
          <Icon
            size={52}
            className="text-zinc-500 transition-colors duration-300 group-hover:text-cyan-300"
          />

          <Stack gap="xs">
            <h3 className={cn(typography.sectionTitle, "font-black")}>
              {label}
            </h3>

            <p className="text-sm text-zinc-500">
              {value?.name ?? description}
            </p>
          </Stack>
        </Stack>
      </div>
    </Panel>
  );
}
