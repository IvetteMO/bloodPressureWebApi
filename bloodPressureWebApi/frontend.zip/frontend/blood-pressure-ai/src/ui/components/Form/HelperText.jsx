import { labelVariants } from "@/ui/foundations/forms";

export default function HelperText({ children, error = false }) {
  if (!children) return null;

  return (
    <p className={error ? labelVariants.error : labelVariants.helper}>
      {children}
    </p>
  );
}
