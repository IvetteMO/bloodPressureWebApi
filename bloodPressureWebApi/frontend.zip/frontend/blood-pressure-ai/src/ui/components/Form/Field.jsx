import { cn } from "@/ui/utils/cn";

import { forms } from "@/ui/foundations/forms";

export default function Field({ children, className = "" }) {
  return <div className={cn(forms.field, className)}>{children}</div>;
}
