import Input from "./Input";

export default function TimeInput(props) {
  return <Input type="time" {...props} />;
}
