export const iconBadgeVariants = {
  sm: {
    size: "h-10 w-10",

    icon: 18,

    radius: "rounded-full",
  },

  md: {
    size: "h-12 w-12",

    icon: 20,

    radius: "rounded-full",
  },

  lg: {
    size: "h-14 w-14",

    icon: 24,

    radius: "rounded-full",
  },

  xl: {
    size: "h-16 w-16",

    icon: 28,

    radius: "rounded-full",
  },

  xxl: {
    size: "h-24 w-24",

    icon: 42,

    radius: "rounded-full",
  },

  feature: {
    size: "h-16 w-16",

    icon: 28,

    align: "center",

    radius: "rounded-3xl",
  },
};

export default iconBadgeVariants;
