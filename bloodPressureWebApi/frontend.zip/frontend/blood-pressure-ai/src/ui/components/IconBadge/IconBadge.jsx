import { cn } from "@/ui/utils/cn";

import iconBadgeVariants from "./iconBadgeVariants";

export default function IconBadge({
  icon: Icon,

  appearance = "",

  variant = "lg",

  hover = true,

  glow = true,

  className = "",

  lineColor,
}) {
  const current = iconBadgeVariants[variant] ?? iconBadgeVariants.lg;

  const isCssColor = (value = "") =>
    typeof value === "string" &&
    (value.startsWith("#") ||
      value.startsWith("rgb") ||
      value.startsWith("rgba") ||
      value.startsWith("hsl") ||
      value.startsWith("hsla"));

  const hasTailwindColor =
    typeof lineColor === "string" && !isCssColor(lineColor);

  const iconStyle = isCssColor(lineColor) ? { color: lineColor } : undefined;

  return (
    <div
      className={cn(
        "relative flex shrink-0 items-center justify-center",

        current.size,

        current.radius,

        "transition-all duration-500",

        hover && "group-hover:scale-110",

        appearance,

        className,
      )}
    >
      {glow && (
        <div
          className="absolute inset-0 rounded-full"
          style={{
            background: "var(--ui-icon-glow)",
            boxShadow: "var(--ui-icon-shadow)",
          }}
        />
      )}
      <Icon
        size={current.icon}
        className={cn(
          "relative z-10 transition-colors duration-300",

          hasTailwindColor && lineColor,
        )}
        style={iconStyle}
      />
    </div>
  );
}
