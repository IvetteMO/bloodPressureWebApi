const iconAppearance = {
  intelligence: {
    background: "bg-[var(--ui-icon-bg-intelligence)]",

    color: "text-[var(--ui-icon-intelligence)]",

    glow: "glow-intelligence",
  },

  cardiovascular: {
    background: "bg-[var(--ui-icon-bg-cardiovascular)]",

    color: "text-[var(--ui-icon-cardiovascular)]",

    glow: "glow-cardiovascular",
  },

  inference: {
    background: "bg-[var(--ui-icon-bg-inference)]",

    color: "text-[var(--ui-icon-inference)]",

    glow: "glow-inference",
  },

  nondipper: {
    background: "bg-[var(--ui-icon-bg-nondipper)]",

    color: "text-[var(--ui-icon-nondipper)]",

    glow: "glow-nondipper",
  },
};

export default iconAppearance;
