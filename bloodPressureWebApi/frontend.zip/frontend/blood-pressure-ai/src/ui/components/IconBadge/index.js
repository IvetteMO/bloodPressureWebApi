export { default } from "./IconBadge";
