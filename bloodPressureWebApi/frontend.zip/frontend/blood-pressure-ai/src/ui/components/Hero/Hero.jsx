import { motion } from "framer-motion";

import { cn } from "@/ui/utils/cn";

import { motionPresets } from "@/ui/animations";

import { spacing } from "@/ui/foundations/spacing";
import { typography } from "@/ui/foundations/typography";

import Surface from "@/ui/primitives/Surface";

import heroVariants from "./heroVariants";

export default function Hero({
  variant = "hero",

  eyebrow,

  title,

  subtitle,

  aside,

  actions,

  children,

  animated = true,

  className = "",
}) {
  const current = heroVariants[variant] ?? heroVariants.hero;

  const content = (
    <Surface
      variant={current.surface}
      background={current.background}
      className={cn(spacing[current.spacing], className)}
    >
      <div
        className={cn(
          "z-10 relative flex lg:flex-row flex-col lg:justify-between",
          current.gap,
          current.align === "center" ? "lg:items-center" : "lg:items-start",
        )}
      >
        <div
          className={cn("min-w-0", current.contentOffset, current.contentWidth)}
        >
          {eyebrow && (
            <p
              className={cn(
                typography[current.eyebrow],
                current.eyebrowColor ?? "text-[var(--ui-hero-text-eyebrow)]",
                current.eyebrowMargin,
              )}
            >
              {eyebrow}
            </p>
          )}

          {title && (
            <h1
              className={cn(
                typography[current.title],
                current.titleColor ?? "text-[var(--ui-hero-text-primary)]",
                current.titleMargin,
              )}
            >
              {title}
            </h1>
          )}

          {subtitle && (
            <p
              className={cn(
                typography.heroSubtitle,
                current.subtitleColor ?? "text-[var(--ui-hero-text-secondary)]",
                current.subtitleMargin,
                "max-w-3xl",
              )}
            >
              {subtitle}
            </p>
          )}

          {actions && <div className={current.actionsMargin}>{actions}</div>}

          {children && <div className={current.childrenMargin}>{children}</div>}
        </div>

        {aside && (
          <div className={cn("w-full lg:shrink-0", current.asideContainer)}>
            {aside}
          </div>
        )}
      </div>
    </Surface>
  );

  if (!animated) return content;

  return <motion.section {...motionPresets.fadeUp}>{content}</motion.section>;
}
