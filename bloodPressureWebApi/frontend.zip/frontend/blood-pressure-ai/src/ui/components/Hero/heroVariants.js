/**
 * ============================================================
 * Clinical UI Kit
 * Hero Variants
 * ============================================================
 */

const heroVariants = {
  hero: {
    surface: "hero",

    spacing: "hero",

    title: "heroTitle",

    background: "hero",

    eyebrow: "eyebrow",

    eyebrowMargin: "mt-5",

    align: "start",

    contentWidth: "max-w-[760px]",

    titleMargin: "mt-6",

    subtitleMargin: "mt-10",

    actionsMargin: "mt-7",

    childrenMargin: "mt-7",

    contentOffset: "",

    asideContainer: "lg:w-[320px]",

    gap: "gap-8",
  },

  heroCompact: {
    surface: "hero",

    spacing: "heroCompact",

    title: "heroTitleCompact",

    background: "heroCompact",

    eyebrow: "eyebrowheroCompact",

    eyebrowMargin: "mt-3",

    contentWidth: "max-w-[700px]",

    titleMargin: "mt-2",

    subtitleMargin: "mt-3",

    actionsMargin: "mt-5",

    childrenMargin: "mt-5",

    contentOffset: "",
  },

  compact: {
    surface: "hero",

    spacing: "heroCompact",

    title: "heroTitleCompact",

    background: "heroCompact",

    eyebrow: "eyebrowheroCompact",

    eyebrowMargin: "mt-3",

    align: "center",

    contentWidth: "max-w-[680px]",

    asideContainer: "lg:w-[200px]",

    gap: "gap-6",

    titleMargin: "mt-2",

    subtitleMargin: "mt-3",

    actionsMargin: "mt-5",

    childrenMargin: "mt-5",

    contentOffset: "",
  },

  page: {
    surface: "hero",

    spacing: "hero",

    title: "heroTitle",

    background: "hero",

    eyebrow: "eyebrow",

    eyebrowMargin: "mt-0",

    contentWidth: "max-w-[760px]",

    titleMargin: "mt-5",

    subtitleMargin: "mt-8",

    actionsMargin: "mt-7",

    childrenMargin: "mt-6",

    contentOffset: "-translate-y-3",
  },

  modal: {
    surface: "modal",

    spacing: "heroCompact",

    title: "heroTitle",

    background: "modal",

    eyebrow: "eyebrow",

    eyebrowMargin: "mt-0",

    align: "start",

    contentWidth: "max-w-[760px]",

    titleMargin: "mt-4",

    subtitleMargin: "mt-5",

    actionsMargin: "mt-6",

    childrenMargin: "mt-6",

    contentOffset: "",

    asideContainer: "w-auto",

    gap: "gap-6",
  },
};

export default heroVariants;
