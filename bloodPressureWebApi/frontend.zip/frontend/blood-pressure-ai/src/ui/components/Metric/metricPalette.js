export const metricPalettes = {
  systolic: {
    value: "text-fuchsia-300",
  },

  diastolic: {
    value: "text-cyan-300",
  },

  pulse: {
    value: "text-emerald-400",
  },

  risk: {
    value: "text-fuchsia-400",
  },

  nocturnal: {
    value: "text-cyan-300",
  },
};

export default metricPalettes;
