import { cn } from "@/ui/utils/cn";
import { typography } from "@/ui/foundations";

import metricVariants from "./metricVariants";

export default function Metric({
  label,
  value,
  suffix = "",
  description,

  variant = "default",

  // ============================================
  // APPEARANCE
  // ============================================

  palette,

  lineColor,
  valueColor,

  // ============================================
  // DISPLAY
  // ============================================

  showLabel = true,

  // ============================================
  // CLASS OVERRIDES
  // ============================================

  className = "",

  valueClassName = "",
  labelClassName = "",
  descriptionClassName = "",
}) {
  // ============================================
  // VARIANT
  // ============================================

  const current = metricVariants[variant] ?? metricVariants.default;

  // ============================================
  // COLOR RESOLUTION
  // ============================================

  const resolvedValueColor = valueColor ?? palette?.value ?? null;

  const resolvedLineColor = lineColor ?? palette?.line ?? null;

  // ============================================
  // COLOR HELPERS
  // ============================================

  const isCssColor = (color = "") =>
    typeof color === "string" &&
    (color.startsWith("#") ||
      color.startsWith("rgb") ||
      color.startsWith("rgba") ||
      color.startsWith("hsl") ||
      color.startsWith("hsla") ||
      color.startsWith("var("));

  const hasTailwindColor =
    typeof resolvedValueColor === "string" &&
    resolvedValueColor.length > 0 &&
    !isCssColor(resolvedValueColor);

  // ============================================
  // INLINE COLOR
  // ============================================

  const valueStyle = isCssColor(resolvedValueColor)
    ? {
        color: resolvedValueColor,
      }
    : !hasTailwindColor && resolvedLineColor
      ? {
          color: resolvedLineColor,
        }
      : undefined;

  // ============================================
  // RENDER
  // ============================================

  return (
    <div
      className={cn(
        "flex flex-col",

        current.align,

        current.gap,

        className,
      )}
    >
      {/* ====================================== */}
      {/* LABEL */}
      {/* ====================================== */}

      {showLabel && label && (
        <p
          className={cn(
            typography.metricLabel,

            current.label,

            labelClassName,
          )}
        >
          {label}
        </p>
      )}

      {/* ====================================== */}
      {/* VALUE */}
      {/* ====================================== */}

      <h3
        className={cn(
          typography.metricValue,

          current.value,

          "transition-colors duration-300",

          hasTailwindColor && resolvedValueColor,

          valueClassName,
        )}
        style={valueStyle}
      >
        {value}

        {suffix}
      </h3>

      {/* ====================================== */}
      {/* DESCRIPTION */}
      {/* ====================================== */}

      {description && (
        <p
          className={cn(
            typography.metricSubtitle,

            current.description,

            descriptionClassName,
          )}
        >
          {description}
        </p>
      )}
    </div>
  );
}
