const metricVariants = {
  // ============================================
  // DEFAULT
  // ============================================

  default: {
    align: "items-start",
    gap: "gap-2",
    value: "",
    label: "",
    description: "",
  },

  // ============================================
  // DASHBOARD
  // ============================================

  dashboard: {
    align: "items-start",

    gap: "gap-1",

    value: `
      text-6xl
      font-black
      leading-none
      tracking-[-0.05em]
    `,

    label: `
      text-lg
      font-semibold
      text-[var(--ui-text-heading)]
      leading-tight
    `,

    description: `
      text-sm
      text-[var(--ui-text-supporting)]
      leading-tight
    `,
  },

  // ============================================
  // CLINICAL
  // ============================================

  clinical: {
    align: "items-start",

    gap: "gap-3",

    value: `
      text-[65px]
      font-black
      leading-none
      tracking-[-0.05em]
    `,

    label: `
      uppercase
      tracking-[0.35em]
      font-semibold
      text-[12px]
      text-[var(--ui-text-supporting)]
    `,

    description: `
      mt-auto
      text-[15px]
      font-semibold
      text-[var(--ui-text-supporting)]
    `,
  },

  // ============================================
  // SNAPSHOT
  // ============================================

  snapshot: {
    align: "items-center",

    gap: "gap-1",

    value: `
      text-4xl
      font-black
      leading-none
      text-[var(--ui-text-heading)]
    `,

    label: `
      text-sm
      text-[var(--ui-text-supporting)]
    `,

    description: "",
  },

  // ============================================
  // CLINICAL MODAL
  // ============================================

  clinicalModal: {
    align: "items-start",

    gap: "gap-3",

    value: `
      text-[42px]
      font-black
      leading-none
      tracking-[-0.04em]
    `,

    label: `
      text-sm
      font-medium
      text-[var(--ui-text-supporting)]
    `,

    description: `
      text-sm
      text-[var(--ui-text-supporting)]
    `,
  },

  // ============================================
  // DIAGNOSIS MODAL
  // ============================================

  diagnosisModal: {
    align: "items-start",

    gap: "gap-3",

    value: `
      text-[26px]
      lg:text-[28px]
      font-black
      leading-[1.05]
      tracking-[-0.03em]
      whitespace-normal
      break-words
    `,

    label: `
      text-sm
      font-medium
      text-[var(--ui-text-supporting)]
    `,

    description: `
      text-sm
      text-[var(--ui-text-supporting)]
      leading-relaxed
    `,
  },
};

export default metricVariants;
