// src/ui/components/Portal/Portal.jsx
import { useEffect, useState } from "react";
import { createPortal } from "react-dom";

/**
 * Portal SSR-safe
 * - No accede a document en SSR.
 * - No llama setState sincrónicamente dentro del efecto.
 * - No lee refs durante render.
 */
export default function Portal({ children, container = null }) {
  // Estado que contendrá el nodo DOM del portal (o null en SSR)
  const [mountNode, setMountNode] = useState(() => {
    // En cliente, crear el nodo ya en la inicialización evita un render extra.
    // En SSR (document undefined) devolvemos null.
    if (typeof document === "undefined") return null;
    const el = document.createElement("div");
    return el;
  });

  useEffect(() => {
    // Si estamos en SSR o no hay nodo creado, no hacemos nada.
    if (!mountNode) return;

    const parent = container instanceof HTMLElement ? container : document.body;
    parent.appendChild(mountNode);

    return () => {
      if (parent.contains(mountNode)) parent.removeChild(mountNode);
    };
    // mountNode y container son estables para este efecto.
  }, [mountNode, container]);

  // Si no hay mountNode (SSR o aún no creado), no renderizamos el portal.
  if (!mountNode) return null;

  return createPortal(children, mountNode);
}
