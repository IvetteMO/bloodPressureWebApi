import { cn } from "@/ui/utils/cn";

import { spacing, surfaces, typography } from "@/ui/foundations";

export default function InsightItem({
  icon: Icon,

  text,

  divider = true,
}) {
  return (
    <div
      className={cn(
        "group flex items-start gap-4 rounded-2xl",

        spacing.insight,

        "transition-all duration-300",

        "hover:bg-white/[0.025]",

        divider && "border-b border-white/[0.05]",
      )}
    >
      <div
        className={cn(
          "flex shrink-0 items-center justify-center",

          spacing.insightIcon,

          surfaces.insightIcon,
        )}
      >
        <Icon
          size={18}
          className="text-violet-300 transition-transform duration-300 group-hover:scale-110"
        />
      </div>

      <p
        className={cn(
          typography.insightText,

          "pt-1",
        )}
      >
        {text}
      </p>
    </div>
  );
}
