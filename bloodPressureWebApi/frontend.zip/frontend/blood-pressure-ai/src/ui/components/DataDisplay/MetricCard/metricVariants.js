const metricVariants = {
  dashboard: {
    layout: "dashboard",
    metric: "dashboard",
    iconSize: "lg",
    sparkline: true,
  },

  clinical: {
    layout: "clinical",
    metric: "clinical",
    iconSize: "md",
    sparkline: false,
  },

  clinicalModal: {
    layout: "clinical",
    metric: "clinicalModal",
    iconSize: "md",
    sparkline: false,
  },
};

export default metricVariants;
