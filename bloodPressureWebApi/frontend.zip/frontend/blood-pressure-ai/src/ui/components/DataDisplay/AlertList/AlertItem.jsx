import { cn } from "@/ui/utils/cn";

import { typography } from "@/ui/foundations";

import alertStyles from "./alertStyles";

export default function AlertItem({ title, subtitle, variant = "critical" }) {
  const current = alertStyles[variant];

  const Icon = current.icon;

  return (
    <div
      className={cn(
        "group relative overflow-hidden rounded-[28px] border bg-white/[0.01]",
        "px-5 py-3 transition-all duration-300",
        "hover:-translate-y-[1px]",
        "hover:border-violet-400/35",
        current.border,
      )}
    >
      <div
        className={cn(
          "absolute inset-0 bg-gradient-to-br opacity-30 transition-all duration-500",
          "group-hover:opacity-60",
          current.glow,
        )}
      />

      <div className="relative z-10 flex items-start gap-4">
        <div
          className={cn(
            "relative flex h-10 w-10 items-center justify-center rounded-full",
            current.iconBg,
          )}
        >
          <div className="absolute inset-0 rounded-full bg-[radial-gradient(circle,rgba(255,255,255,.18),transparent_70%)]" />

          <Icon size={20} strokeWidth={2.2} className="relative z-10" />
        </div>

        <div className="flex-1">
          <h3 className={typography.alertTitle}>{title}</h3>

          <p className={typography.alertSubtitle}>{subtitle}</p>
        </div>
      </div>
    </div>
  );
}
