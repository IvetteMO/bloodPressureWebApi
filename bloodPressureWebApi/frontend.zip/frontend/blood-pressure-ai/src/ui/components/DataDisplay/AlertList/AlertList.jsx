import Panel from "@/ui/components/Panel";

import Stack from "@/ui/primitives/Stack";

import { typography } from "@/ui/foundations";

import alertVariants from "./alertVariants";

import AlertItem from "./AlertItem";

export default function AlertList({
  variant = "default",

  title,

  alerts = [],
}) {
  const current = alertVariants[variant] ?? alertVariants.default;

  return (
    <Panel variant={current.panel} className="h-full">
      <Stack gap="xl" className="h-full">
        {title && <p className={typography.insightTitle}>{title}</p>}

        <Stack gap="sm">
          {alerts.map((alert, index) => (
            <AlertItem
              key={index}
              title={alert.title}
              subtitle={alert.subtitle}
              variant={alert.variant}
            />
          ))}
        </Stack>
      </Stack>
    </Panel>
  );
}
