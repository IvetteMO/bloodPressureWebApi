import Panel from "@/ui/components/Panel";

import Stack from "@/ui/primitives/Stack";

import { typography } from "@/ui/foundations";

import InsightItem from "./InsightItem";

import insightVariants from "./insightVariants";

export default function InsightList({
  variant = "default",

  title,

  items = [],

  icons = [],
}) {
  const current = insightVariants[variant] ?? insightVariants.default;

  return (
    <Panel variant={current.panel} className="h-full">
      <Stack gap="lg" className="h-full">
        {title && <p className={typography.insightTitle}>{title}</p>}

        <Stack gap="none" className="flex-1">
          {items.map((item, index) => (
            <InsightItem
              key={index}
              icon={icons[index % icons.length]}
              text={item}
              divider={index < items.length - 1}
            />
          ))}
        </Stack>
      </Stack>
    </Panel>
  );
}
