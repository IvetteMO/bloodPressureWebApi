import { ResponsiveContainer, AreaChart, Area, Line } from "recharts";

export default function MetricSparkline({ data = [], color = "#A855F7" }) {
  // ==========================================================
  // Resolve CSS Variables
  // ==========================================================

  let resolvedColor = color;

  if (color?.startsWith("var(")) {
    const variable = color.replace("var(", "").replace(")", "").trim();

    resolvedColor =
      getComputedStyle(document.documentElement)
        .getPropertyValue(variable)
        .trim() || "#A855F7";
  }

  // ==========================================================
  // Unique Gradient
  // ==========================================================

  const gradientId = `metric-gradient-${resolvedColor.replace("#", "")}`;

  return (
    <div className="relative h-14 w-full overflow-hidden">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data}>
          <defs>
            <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={resolvedColor} stopOpacity={0.58} />

              <stop offset="55%" stopColor={resolvedColor} stopOpacity={0.24} />

              <stop offset="100%" stopColor={resolvedColor} stopOpacity={0} />
            </linearGradient>
          </defs>

          <Area
            type="monotone"
            dataKey="v"
            stroke="none"
            fill={`url(#${gradientId})`}
            fillOpacity={1}
            isAnimationActive={false}
          />

          <Line
            type="monotone"
            dataKey="v"
            stroke={resolvedColor}
            strokeWidth={2.8}
            dot={false}
            isAnimationActive
            animationDuration={700}
            style={{
              filter: `drop-shadow(0 0 8px ${resolvedColor})`,
            }}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
