import { cn } from "@/ui/utils/cn";

import avatarBadgeVariants from "./avatarBadgeVariants";

export default function AvatarBadge({
  icon: Icon,
  variant = "patient",
  size = 24,
  className = "",
}) {
  const current = avatarBadgeVariants[variant] ?? avatarBadgeVariants.patient;

  return (
    <div
      className={cn(current.container, className)}
      style={{
        boxShadow: "var(--ui-avatar-patient-shadow)",
      }}
    >
      <div
        className="absolute inset-0 rounded-[20px]"
        style={{
          background: "var(--ui-avatar-glow)",
        }}
      />

      {Icon && (
        <Icon
          size={size}
          className="relative z-10"
          style={{
            filter: "drop-shadow(var(--ui-avatar-icon-glow))",
          }}
        />
      )}
    </div>
  );
}
