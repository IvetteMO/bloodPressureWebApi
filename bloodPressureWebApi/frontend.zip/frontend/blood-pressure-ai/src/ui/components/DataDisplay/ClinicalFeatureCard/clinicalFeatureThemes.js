const clinicalFeatureThemes = {
  default: {
    icon: "#A855F7",
    value: "text-violet-300",
    appearance: "bg-white/5",
  },

  emerald: {
    icon: "#6EE7B7",
    value: "text-emerald-300",
    appearance: "bg-white/5",
  },

  cyan: {
    icon: "#67E8F9",
    value: "text-cyan-300",
    appearance: "bg-white/5",
  },

  rose: {
    icon: "#FDA4AF",
    value: "text-rose-300",
    appearance: "bg-white/5",
  },

  orange: {
    icon: "#FDBA74",
    value: "text-orange-300",
    appearance: "bg-white/5",
  },

  violet: {
    icon: "#C4B5FD",
    value: "text-violet-300",
    appearance: "bg-white/5",
  },

  fuchsia: {
    icon: "#E879F9",
    value: "text-fuchsia-300",
    appearance: "bg-white/5",
  },
};

export default clinicalFeatureThemes;
