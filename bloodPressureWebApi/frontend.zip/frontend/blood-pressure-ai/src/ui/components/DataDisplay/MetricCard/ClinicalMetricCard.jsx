import { cn } from "@/ui/utils/cn";

import Panel from "@/ui/components/Panel";
import Metric from "@/ui/components/Metric";
import IconBadge from "@/ui/components/IconBadge";

import Stack from "@/ui/primitives/Stack";

export default function ClinicalMetricCard({
  title,
  value,

  subtitle = "",
  showSubtitle = true,

  icon: Icon,

  accent = "#22D3EE",

  appearance = "",

  valueColor,

  valueClassName = "",

  className = "",
}) {
  return (
    <Panel
      variant="metric"
      background="metricClinical"
      className={cn("h-[185px] w-full", className)}
    >
      <Stack className="h-full" gap="md">
        <Stack direction="row" gap="md" align="start">
          <IconBadge
            icon={Icon}
            appearance={appearance}
            variant="lg"
            lineColor={accent}
          />

          <Metric
            variant="clinical"
            showLabel
            label={title}
            value={value}
            description={showSubtitle ? subtitle : ""}
            lineColor={accent}
            valueColor={valueColor}
            valueClassName={valueClassName}
          />
        </Stack>
      </Stack>
    </Panel>
  );
}
