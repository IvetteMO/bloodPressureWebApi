/**
 * ============================================================
 * Avatar Badge Variants
 * ============================================================
 */

const base = `
relative

flex
items-center
justify-center

overflow-hidden

rounded-[20px]

border

transition-all
duration-300
`;

const avatarBadgeVariants = {
  patient: {
    container: `
${base}

h-14
w-14

border-[var(--ui-avatar-patient-border)]
bg-[var(--ui-avatar-patient-bg)]
text-[var(--ui-avatar-patient)]
`,
  },

  intelligence: {
    container: `
${base}

h-14
w-14

border-[var(--ui-avatar-intelligence-border)]
bg-[var(--ui-avatar-intelligence-bg)]
text-[var(--ui-avatar-intelligence)]
`,
  },
};

export default avatarBadgeVariants;
