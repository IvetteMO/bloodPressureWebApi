import { cn } from "@/ui/utils/cn";

import Panel from "@/ui/components/Panel";
import IconBadge from "@/ui/components/IconBadge";
import Metric from "@/ui/components/Metric";

import MetricSparkline from "./MetricSparkline";
import metricThemes from "./metricTheme";

export default function DashboardMetricCard({
  theme = "intelligence",

  title,

  value,

  subtitle,

  sparkline,

  sparklineData,

  className = "",

  valueClassName = "",
}) {
  const current = metricThemes[theme] ?? metricThemes.intelligence;

  const chartData = sparklineData ?? sparkline ?? [];

  return (
    <Panel
      variant="metric"
      background={current.background}
      className={cn("group h-[200px]", className)}
    >
      <div className="flex h-full flex-col">
        {/* Header */}

        <div className="flex items-start gap-4">
          <IconBadge
            icon={current.icon}
            appearance={current.iconBackground}
            variant="lg"
            lineColor={current.lineColor}
          />

          <Metric
            variant="dashboard"
            showLabel
            label={title}
            value={value}
            description={subtitle}
            lineColor={current.lineColor}
            valueClassName={cn("!mt-1", valueClassName)}
            descriptionClassName="!mt-1"
          />
        </div>

        <div className="mt-auto pt-6">
          <MetricSparkline data={chartData} color={current.lineColor} />
        </div>
      </div>
    </Panel>
  );
}
