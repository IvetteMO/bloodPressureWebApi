import { AlertTriangle, MoonStar, Activity, Brain } from "lucide-react";

export const alertStyles = {
  critical: {
    icon: AlertTriangle,

    border: "border-[var(--ui-alert-critical-border)]",

    glow: "from-[var(--ui-alert-critical-glow)] to-transparent",

    iconBg: `
      bg-[var(--ui-alert-critical-bg)]
      text-[var(--ui-alert-critical)]
    `,
  },

  warning: {
    icon: MoonStar,

    border: "border-[var(--ui-alert-warning-border)]",

    glow: "from-[var(--ui-alert-warning-glow)] to-transparent",

    iconBg: `
      bg-[var(--ui-alert-warning-bg)]
      text-[var(--ui-alert-warning)]
    `,
  },

  accent: {
    icon: Activity,

    border: "border-[var(--ui-alert-accent-border)]",

    glow: "from-[var(--ui-alert-accent-glow)] to-transparent",

    iconBg: `
      bg-[var(--ui-alert-accent-bg)]
      text-[var(--ui-alert-accent)]
    `,
  },

  info: {
    icon: Brain,

    border: "border-[var(--ui-alert-info-border)]",

    glow: "from-[var(--ui-alert-info-glow)] to-transparent",

    iconBg: `
      bg-[var(--ui-alert-info-bg)]
      text-[var(--ui-alert-info)]
    `,
  },
};

export default alertStyles;
