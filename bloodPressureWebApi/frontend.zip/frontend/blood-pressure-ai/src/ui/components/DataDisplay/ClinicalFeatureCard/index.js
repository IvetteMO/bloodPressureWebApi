export { default } from "./ClinicalFeatureCard";
