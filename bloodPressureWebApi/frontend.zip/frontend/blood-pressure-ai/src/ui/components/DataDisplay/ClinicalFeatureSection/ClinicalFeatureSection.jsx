import { cn } from "@/ui/utils/cn";

import Panel from "@/ui/components/Panel";
import ClinicalFeatureCard from "@/ui/components/DataDisplay/ClinicalFeatureCard";

import Stack from "@/ui/primitives/Stack";

import { typography } from "@/ui/foundations";

import clinicalFeatureSectionVariants from "./clinicalFeatureSectionVariants";

export default function ClinicalFeatureSection({
  title,

  items = [],

  columns = 2,

  variant = "default",

  className = "",
}) {
  const current =
    clinicalFeatureSectionVariants[variant] ??
    clinicalFeatureSectionVariants.default;

  return (
    <Panel
      variant={current.panel}
      background={current.background}
      className={className}
    >
      <Stack gap="lg">
        {/* HEADER */}

        <p
          className={cn(
            typography.labelCard,

            current.titleMargin,
          )}
        >
          {title}
        </p>

        {/* GRID */}

        <div
          className={cn(
            "grid gap-8",
            columns === 2 && "grid-cols-1 xl:grid-cols-2",
            columns === 3 && "grid-cols-1 md:grid-cols-2 xl:grid-cols-3",
          )}
        >
          {items.map((item) => (
            <ClinicalFeatureCard key={item.title} {...item} />
          ))}
        </div>
      </Stack>
    </Panel>
  );
}
