const clinicalFeatureVariants = {
  default: {
    panel: "metric",

    background: "metricClinical",

    iconVariant: "lg",

    minHeight: "min-h-[190px]",
  },
};

export default clinicalFeatureVariants;
