import { cn } from "@/ui/utils/cn";

import Panel from "@/ui/components/Panel";
import IconBadge from "@/ui/components/IconBadge";

import Stack from "@/ui/primitives/Stack";

import { typography } from "@/ui/foundations";

import clinicalFeatureVariants from "./clinicalFeatureVariants";
import clinicalFeatureThemes from "./clinicalFeatureThemes";

export default function ClinicalFeatureCard({
  title,

  value,

  icon: Icon,

  theme = "default",

  variant = "default",

  className = "",
}) {
  const current =
    clinicalFeatureVariants[variant] ?? clinicalFeatureVariants.default;

  const colors = clinicalFeatureThemes[theme] ?? clinicalFeatureThemes.default;

  return (
    <Panel
      variant={current.panel}
      background={current.background}
      className={cn(current.minHeight, "group h-full", className)}
    >
      <Stack
        className="h-full items-center justify-center text-center"
        gap="xl"
      >
        <IconBadge
          icon={Icon}
          variant={current.feature}
          appearance={colors.appearance}
          lineColor={colors.icon}
        />

        <Stack align="center" gap="sm">
          <p className={cn(typography.featureTitle, "items-center")}>{title}</p>

          <h2
            className={cn(typography.featureValue, colors.value, "text-center")}
          >
            {value ?? "--"}
          </h2>
        </Stack>
      </Stack>
    </Panel>
  );
}
