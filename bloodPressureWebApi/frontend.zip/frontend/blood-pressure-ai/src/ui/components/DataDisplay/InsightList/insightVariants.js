export const insightVariants = {
  default: {
    panel: "interactive",
  },

  compact: {
    panel: "compact",
  },
};

export default insightVariants;
