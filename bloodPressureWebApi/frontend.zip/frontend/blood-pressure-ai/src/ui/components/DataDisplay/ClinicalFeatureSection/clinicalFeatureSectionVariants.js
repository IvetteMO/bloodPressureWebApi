const clinicalFeatureSectionVariants = {
  default: {
    panel: "default",

    background: "surfaceElevated2",

    columns: "grid-cols-1 md:grid-cols-2",

    gap: "gap-6",

    titleMargin: "mb-8",
  },
};

export default clinicalFeatureSectionVariants;
