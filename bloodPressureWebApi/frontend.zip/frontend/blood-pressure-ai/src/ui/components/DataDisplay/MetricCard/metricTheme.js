import {
  Brain,
  Heart,
  Activity,
  HeartPulse,
  MoonStar,
  Gauge,
} from "lucide-react";

const metricThemes = {
  intelligence: {
    icon: Brain,

    background: "metricIntelligence",

    iconBackground: `
      bg-[var(--ui-metric-intelligence-badge)]
      text-[var(--ui-metric-intelligence)]
    `,

    lineColor: "var(--ui-metric-intelligence)",
  },

  cardiovascular: {
    icon: Heart,

    background: "metricCardiovascular",

    iconBackground: `
      bg-[var(--ui-metric-cardiovascular-badge)]
      text-[var(--ui-metric-cardiovascular)]
    `,

    lineColor: "var(--ui-metric-cardiovascular)",
  },

  inference: {
    icon: Activity,

    background: "metricInference",

    iconBackground: `
      bg-[var(--ui-metric-inference-badge)]
      text-[var(--ui-metric-inference)]
    `,

    lineColor: "var(--ui-metric-inference)",
  },

  nondipper: {
    icon: MoonStar,

    background: "metricNondipper",

    iconBackground: `
      bg-[var(--ui-metric-nondipper-badge)]
      text-[var(--ui-metric-nondipper)]
    `,

    lineColor: "var(--ui-metric-nondipper)",
  },

  systolic: {
    icon: Heart,

    background: "metricCardiovascular",

    iconBackground: `
      bg-[var(--ui-metric-systolic-badge)]
      text-[var(--ui-metric-systolic)]
    `,

    lineColor: "var(--ui-metric-systolic)",
  },

  diastolic: {
    icon: Activity,

    background: "metricCardiovascular",

    iconBackground: `
      bg-[var(--ui-metric-diastolic-badge)]
      text-[var(--ui-metric-diastolic)]
    `,

    lineColor: "var(--ui-metric-diastolic)",
  },

  pulse: {
    icon: HeartPulse,

    background: "metricNondipper",

    iconBackground: `
      bg-[var(--ui-metric-pulse-badge)]
      text-[var(--ui-metric-pulse)]
    `,

    lineColor: "var(--ui-metric-pulse)",
  },

  load: {
    icon: Gauge,

    background: "metricCard",

    iconBackground: `
      bg-[var(--ui-metric-load-badge)]
      text-[var(--ui-metric-load)]
    `,

    lineColor: "var(--ui-metric-load)",
  },
};

export default metricThemes;
