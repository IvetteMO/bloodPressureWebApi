const alertVariants = {
  default: {
    panel: "default",
  },
};

export default alertVariants;
