export { default } from "./ClinicalFeatureSection";
