import { cn } from "@/ui/utils/cn";

import Grid from "@/ui/primitives/Grid";

import ClinicalMetricCard from "../../MetricCard/ClinicalMetricCard";

import { typography } from "@/ui/foundations";

export default function MetricSection({
  title,

  items = [],

  columns = 3,

  className = "",
}) {
  return (
    <section className={className}>
      {/* HEADER */}

      {title && <h2 className={cn(typography.labelCard, "mb-8")}>{title}</h2>}

      {/* GRID */}

      <Grid cols={columns} gap="lg">
        {items.map((item) => (
          <ClinicalMetricCard key={item.title} {...item} />
        ))}
      </Grid>
    </section>
  );
}
