import { cn } from "@/ui/utils/cn";
import { spacing } from "@/ui/foundations/spacing";
import { typography } from "@/ui/foundations/typography";
import { Surface } from "@/ui";

export default function ExcelAside({ currentStudy }) {
  return (
    <Surface
      variant="heroAsideExcel"
      interactive // 👈 activa hover con radius y sombra redonda
      className="w-[200px] px-6 py-5" // 👈 ancho fijo y empujado a la derecha
    >
      <p className={cn(typography.eyebrow, "text-zinc-500")}>Excel File</p>
      <h3 className={cn(typography.nameStudy, spacing.nameStudyMargin)}>
        {currentStudy?.excelFileName ?? "No file loaded"}
      </h3>
    </Surface>
  );
}
