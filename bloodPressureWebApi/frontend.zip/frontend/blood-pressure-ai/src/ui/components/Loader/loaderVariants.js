const loaderVariants = {
  default: {
    size: "h-16 w-16",

    title: "Loading...",

    subtitle: "Please wait.",

    spinner: `
border-violet-500/20
border-t-fuchsia-400
`,
  },

  clinical: {
    size: "h-16 w-16",

    title: "Initializing Hybrid AI",

    subtitle: "Loading cardiovascular models...",

    spinner: `
border-violet-500/20
border-t-fuchsia-400
`,
  },
};

export default loaderVariants;
