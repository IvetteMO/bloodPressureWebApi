import { cn } from "@/ui/utils/cn";

import Panel from "@/ui/components/Panel";

import loaderVariants from "./loaderVariants";
import loaderLayouts from "./loaderLayouts";

export default function Loader({
  variant = "default",
  layout = "overlay",
  title,
  subtitle,
  className = "",
}) {
  const current = loaderVariants[variant];
  const currentLayout = loaderLayouts[layout];

  return (
    <div className={cn(currentLayout.wrapper, className)}>
      <Panel variant="modal" className={cn(currentLayout.panel)}>
        <div
          className={cn(
            "mx-auto border-4 rounded-full animate-spin",
            current.size,
            current.spinner,
          )}
        />

        <h2 className="mt-6 font-semibold text-white text-xl">
          {title ?? current.title}
        </h2>

        <p className="mt-2 text-zinc-400">{subtitle ?? current.subtitle}</p>
      </Panel>
    </div>
  );
}
