const loaderLayouts = {
  overlay: {
    wrapper:
      "fixed inset-0 z-[9999] flex items-center justify-center bg-[#05030A]/80 backdrop-blur-xl",

    panel: "w-full max-w-md p-10",
  },

  inline: {
    wrapper: "flex items-center justify-center py-16",

    panel: "w-full max-w-md p-10",
  },

  panel: {
    wrapper: `
absolute
inset-0
z-50

flex
items-center
justify-center

rounded-[inherit]
overflow-hidden

bg-[#0A0713]/55
backdrop-blur-sm
`,

    panel: "w-full max-w-md p-10",
  },
};

export default loaderLayouts;
