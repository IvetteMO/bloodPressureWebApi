import { cn } from "@/ui/utils/cn";
import sectionVariants from "./sectionVariants";

export default function Section({
  children,
  variant = "default",
  className = "",
}) {
  const current = sectionVariants[variant] ?? sectionVariants.default;

  return (
    <section
      className={cn(
        current.spacing,

        "w-full",

        className,
      )}
    >
      {children}
    </section>
  );
}
