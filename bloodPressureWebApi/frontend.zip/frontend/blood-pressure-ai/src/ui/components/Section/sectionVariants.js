const sectionVariants = {
  default: {
    spacing: `

flex
flex-col

gap-6
`,
  },

  compact: {
    spacing: `
      flex
      flex-col

      gap-4

      pt-6
    `,
  },

  spacious: {
    spacing: `
      flex
      flex-col

      gap-8

      pt-14
    `,
  },
};

export default sectionVariants;
