export const panelVariants = {
  default: {
    surface: "panel",
    spacing: "panel",
    interactive: false,
  },

  interactive: {
    surface: "panel",
    spacing: "panel",
    interactive: true,
  },

  chart: {
    surface: "panel",
    spacing: "panel",
    interactive: true,
  },

  hero: {
    surface: "hero",
    spacing: "hero",
    interactive: false,
  },

  heroCompact: {
    surface: "heroCompact",
    spacing: "heroCompact",
    interactive: false,
  },

  compact: {
    surface: "card",
    spacing: "compact",
    interactive: false,
  },

  flat: {
    surface: "card",
    spacing: "card",
    interactive: false,
  },
};

export default panelVariants;
