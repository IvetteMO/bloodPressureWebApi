import typography from "../../../foundations/typography/typography";

export default function ChartLegend({ items = [] }) {
  return (
    <div className="flex flex-wrap items-center gap-5 mt-3">
      {items.map((item) => (
        <div key={item.label} className="flex items-center gap-2">
          <span
            className="rounded-full w-2 h-2"
            style={{
              background: item.color,
            }}
          />

          <span className={typography.chartLegend}>{item.label}</span>
        </div>
      ))}
    </div>
  );
}
