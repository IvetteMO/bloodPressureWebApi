import {
  ResponsiveContainer,
  LineChart,
  Line,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
} from "recharts";

import {
  ChartTooltip,
  xAxisProps,
  yAxisProps,
  gridProps,
  activeDot,
  lineAnimation,
} from "@/ui/components/DataVisualization/Chart";

function HeartRateChart({
  data,

  pulseColor = "#4ade80",
}) {
  return (
    <ResponsiveContainer width="100%" height="100%" minHeight={280}>
      <LineChart data={data}>
        <CartesianGrid {...gridProps} />

        <XAxis dataKey="time" {...xAxisProps} />

        <YAxis {...yAxisProps} />

        <Tooltip
          cursor={{
            stroke: "rgba(168,85,247,.20)",
          }}
          content={
            <ChartTooltip
              items={[
                {
                  dataKey: "pulse",
                  label: "Heart Rate",
                  color: pulseColor,
                },
              ]}
            />
          }
        />

        <Line
          type="monotone"
          dataKey="pulse"
          stroke={pulseColor}
          strokeWidth={4}
          dot={false}
          activeDot={activeDot(pulseColor)}
          {...lineAnimation}
        />
      </LineChart>
    </ResponsiveContainer>
  );
}

export default HeartRateChart;
