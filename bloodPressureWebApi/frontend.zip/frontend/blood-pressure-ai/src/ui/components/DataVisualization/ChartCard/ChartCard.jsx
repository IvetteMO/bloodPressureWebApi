import { cn } from "@/ui/utils/cn";

import Panel from "@/ui/components/Panel";
import IconBadge from "@/ui/components/IconBadge";
import Stack from "@/ui/primitives/Stack";
import { typography } from "@/ui/foundations";

import chartCardVariants from "./chartCardVariants";

export default function ChartCard({
  icon,

  eyebrow,

  title,

  children,

  variant = "default",
}) {
  const current = chartCardVariants[variant] ?? chartCardVariants.default;

  return (
    <Panel variant="chart" className="h-full">
      <div className="flex h-full flex-col">
        <div
          className={cn(
            "flex items-start",

            current.headerGap,

            current.headerMargin,
          )}
        >
          <IconBadge
            icon={icon}
            appearance={current.icon}
            variant={current.iconVariant}
          />

          <Stack gap="xs">
            {eyebrow && <p className={typography.metricLabel}>{eyebrow}</p>}

            <h2
              className={cn(
                typography.chartTitle,

                current.titleMargin,
              )}
            >
              {title}
            </h2>
          </Stack>
        </div>

        <div className="min-h-0 flex-1">{children}</div>
      </div>
    </Panel>
  );
}
