import { cn } from "@/ui/utils/cn";

import { surfaces, spacing, typography } from "@/ui/foundations";

export default function ChartTooltip({
  active,
  payload,
  items = [],
  timeField = "time",
}) {
  if (!active || !payload?.length) return null;

  return (
    <div
      className={cn(
        surfaces.tooltip,

        spacing.tooltip,

        "w-fit max-w-[220px] min-w-[150px]",
      )}
    >
      {payload?.[0]?.payload?.[timeField] && (
        <p
          className={cn(
            typography.tooltipTitle,

            "mb-3",
          )}
        >
          {payload[0].payload[timeField]}
        </p>
      )}

      <div className="space-y-1">
        {items.map((item) => {
          const point = payload.find((p) => p.dataKey === item.dataKey);

          return (
            <p
              key={item.dataKey}
              className={cn(
                typography.tooltipLabel,

                "whitespace-nowrap",
              )}
              style={{
                color: item.color,
              }}
            >
              {item.label}: {point?.value}
            </p>
          );
        })}
      </div>
    </div>
  );
}
