export const xAxisProps = {
  interval: "preserveStartEnd",
  minTickGap: 60,

  tickLine: false,
  axisLine: false,

  tick: {
    fill: "var(--ui-chart-axis)",
    fontSize: 11,
  },
};

export const yAxisProps = {
  tickLine: false,
  axisLine: false,

  tick: {
    fill: "var(--ui-chart-axis)",
    fontSize: 11,
  },
};

export const gridProps = {
  stroke: "var(--ui-chart-grid)",
  strokeDasharray: "3 3",
  opacity: 1,
};

export const tooltipCursor = {
  stroke: "var(--ui-chart-cursor)",
};

export const activeDot = (color) => ({
  r: 6,
  fill: color,
  stroke: "var(--ui-chart-active-dot-stroke)",
  strokeWidth: 2,
});

export const lineAnimation = {
  isAnimationActive: true,
  animationDuration: 1200,
  animationEasing: "ease-out",
};

export default {
  xAxisProps,
  yAxisProps,
  gridProps,
  tooltipCursor,
  activeDot,
  lineAnimation,
};
