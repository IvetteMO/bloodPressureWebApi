const chartCardVariants = {
  default: {
    icon: "bg-violet-500/15",

    headerGap: "gap-5",

    headerMargin: "mb-8",

    titleMargin: "mt-2",

    iconVariant: "xl",
  },
};

export default chartCardVariants;
