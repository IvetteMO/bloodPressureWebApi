const chartVariants = {
  default: {
    height: "h-[320px]",

    minHeight: 240,
  },

  compact: {
    height: "h-[220px]",

    minHeight: 180,
  },
};

export default chartVariants;
