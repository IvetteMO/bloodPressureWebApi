import {
  ResponsiveContainer,
  LineChart,
  Line,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
} from "recharts";

import {
  ChartTooltip,
  xAxisProps,
  yAxisProps,
  gridProps,
  activeDot,
  lineAnimation,
} from "@/ui/components/DataVisualization/Chart";

function BPTrendChart({
  data,

  systolicColor = "#fb7185",

  diastolicColor = "#67e8f9",
}) {
  return (
    <ResponsiveContainer width="100%" height="100%" minHeight={280}>
      <LineChart data={data}>
        <CartesianGrid {...gridProps} />

        <XAxis dataKey="time" {...xAxisProps} />

        <YAxis {...yAxisProps} />

        <Tooltip
          cursor={{
            stroke: "rgba(168,85,247,.20)",
          }}
          content={
            <ChartTooltip
              items={[
                {
                  dataKey: "systolic",
                  label: "Systolic",
                  color: systolicColor,
                },
                {
                  dataKey: "diastolic",
                  label: "Diastolic",
                  color: diastolicColor,
                },
              ]}
            />
          }
        />

        <Line
          type="monotone"
          dataKey="systolic"
          stroke={systolicColor}
          strokeWidth={4}
          dot={false}
          activeDot={activeDot(systolicColor)}
          {...lineAnimation}
        />

        <Line
          type="monotone"
          dataKey="diastolic"
          stroke={diastolicColor}
          strokeWidth={4}
          dot={false}
          activeDot={activeDot(diastolicColor)}
          {...lineAnimation}
        />
      </LineChart>
    </ResponsiveContainer>
  );
}

export default BPTrendChart;
