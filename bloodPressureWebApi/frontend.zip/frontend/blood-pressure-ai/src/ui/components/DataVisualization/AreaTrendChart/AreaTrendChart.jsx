import {
  ResponsiveContainer,
  AreaChart,
  Area,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
} from "recharts";

import Panel from "@/ui/components/Panel";

import ChartLegend from "../Chart/ChartLegend";
import ChartTooltip from "../Chart/ChartTooltip";
import chartVariants from "../Chart/chartVariants";

import { cn } from "@/ui/utils/cn";
import { typography } from "@/ui/foundations";

export default function AreaTrendChart({
  chartId = "chart",

  variant = "default",

  eyebrow,

  title,

  data = [],

  legend = [],

  series = [],

  timeField = "time",
}) {
  const current = chartVariants[variant] ?? chartVariants.default;

  return (
    <Panel variant="chart">
      <div className="flex h-full flex-col">
        <div className="mb-5">
          {eyebrow && <p className={typography.eyebrow}>{eyebrow}</p>}

          {title && (
            <h2 className={cn(typography.sectionTitle, "mt-2")}>{title}</h2>
          )}

          <ChartLegend items={legend} />
        </div>

        <div className={cn("flex-1", current.height)}>
          <ResponsiveContainer
            width="100%"
            height="100%"
            minHeight={current.minHeight}
          >
            <AreaChart data={data}>
              <defs>
                {series.map((item) => (
                  <linearGradient
                    key={item.dataKey}
                    id={`${chartId}-${item.dataKey}`}
                    x1="0"
                    y1="0"
                    x2="0"
                    y2="1"
                  >
                    <stop
                      offset="0%"
                      stopColor={item.color}
                      stopOpacity={item.opacity ?? 0.3}
                    />

                    <stop
                      offset="100%"
                      stopColor={item.color}
                      stopOpacity={0}
                    />
                  </linearGradient>
                ))}
              </defs>

              <CartesianGrid stroke="var(--ui-chart-grid)" vertical={false} />

              <XAxis
                dataKey={timeField}
                tickLine={false}
                axisLine={false}
                tick={{
                  fill: "var(--ui-chart-axis)",
                  fontSize: 11,
                }}
              />

              <YAxis
                tickLine={false}
                axisLine={false}
                tick={{
                  fill: "var(--ui-chart-axis)",
                  fontSize: 11,
                }}
              />

              <Tooltip
                cursor={{
                  stroke: "var(--ui-chart-cursor)",
                }}
                content={<ChartTooltip items={legend} timeField={timeField} />}
              />

              {series.map((item) => (
                <Area
                  key={item.dataKey}
                  type="monotone"
                  dataKey={item.dataKey}
                  stroke={item.color}
                  strokeWidth={3}
                  fill={`url(#${chartId}-${item.dataKey})`}
                  isAnimationActive
                  animationDuration={1200}
                  animationEasing="ease-out"
                  dot={false}
                  activeDot={{
                    r: 6,
                    fill: item.color,
                    stroke: "#fff",
                    strokeWidth: 2,
                  }}
                />
              ))}
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
    </Panel>
  );
}
