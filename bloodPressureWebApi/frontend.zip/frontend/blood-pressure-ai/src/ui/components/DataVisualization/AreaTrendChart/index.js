export { default } from "./AreaTrendChart";
