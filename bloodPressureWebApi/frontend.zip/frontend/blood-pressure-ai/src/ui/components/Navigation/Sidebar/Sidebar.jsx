import { Link, useLocation } from "react-router-dom";

import { useState } from "react";

import { Brain, ChevronDown, ChevronLeft, ChevronRight } from "lucide-react";

// ============================================
// UI KIT
// ============================================

import Panel from "@/ui/components/Panel";
import Stack from "@/ui/primitives/Stack";
import { cn } from "@/ui/utils/cn";

import SidebarItem from "./SidebarItem";

import sidebarItems from "./sidebarItems";
import sidebarVariants from "./sidebarVariants";

import { typography } from "@/ui/foundations";
import Decoration from "@/ui/primitives/Decoration";

// ============================================
// COMPONENT
// ============================================

function Sidebar({
  collapsed = false,
  setCollapsed = () => {},
  mobile = false,
  setSidebarOpen = () => {},
}) {
  const location = useLocation();

  const [riskOpen, setRiskOpen] = useState(true);

  // ============================================
  // MOBILE
  // ============================================

  function handleClick() {
    if (mobile) {
      setSidebarOpen(false);
    }
  }

  // ============================================
  // UI
  // ============================================

  return (
    <aside className={sidebarVariants.root(collapsed)}>
      {/* ====================================== */}
      {/* EFFECTS */}
      {/* ====================================== */}

      <Decoration effect="navigationReflection" />

      <Decoration effect="navigationWhiteGlow" />

      <Decoration effect="navigationVioletGlow" />

      <Decoration effect="navigationLogoGlow" />

      <Stack
        direction="row"
        align="center"
        className={`mb-12 ${collapsed ? "justify-center" : "justify-between"} `}
      >
        {!collapsed && (
          <div>
            <h1 className={typography.navigationTitle}>Soft Diagnosis</h1>

            <p className={typography.navigationSubtitle}>
              Nocturnal Clinical Intelligence
            </p>
          </div>
        )}

        {!mobile && (
          <button
            onClick={() => setCollapsed(!collapsed)}
            className={sidebarVariants.collapseButton}
          >
            {collapsed ? <ChevronRight size={20} /> : <ChevronLeft size={20} />}
          </button>
        )}
      </Stack>

      {/* ====================================== */}
      {/* MENU */}
      {/* ====================================== */}

      <Stack className="flex-1" gap="sm">
        {sidebarItems
          .filter((item) => item.type === "item")
          .slice(0, 5)
          .map((item) => (
            <SidebarItem
              key={item.to}
              item={item}
              collapsed={collapsed}
              onClick={handleClick}
            />
          ))}

        {/* ====================================== */}
        {/* GROUP */}
        {/* ====================================== */}

        <button
          onClick={() => {
            if (collapsed) {
              handleClick();

              window.location.href = "/hypertension";

              return;
            }

            setRiskOpen(!riskOpen);
          }}
          className={sidebarVariants.groupButton}
        >
          <Stack direction="row" align="center" className="justify-between">
            <Stack
              direction="row"
              gap="md"
              align="center"
              className={collapsed ? "w-full justify-center" : ""}
            >
              <Brain size={21} strokeWidth={1.8} />

              {!collapsed && (
                <span className={typography.bodyMedium}>Risk Diagnosis</span>
              )}
            </Stack>

            {!collapsed && (
              <ChevronDown
                size={18}
                className={`transition-transform duration-300 ${riskOpen ? "rotate-180" : ""} `}
              />
            )}
          </Stack>
        </button>

        {riskOpen && !collapsed && (
          <div className={sidebarVariants.submenu}>
            <Link to="/hypertension" onClick={handleClick}>
              <div
                className={sidebarVariants.menuItem({
                  activeItem: location.pathname === "/hypertension",
                  collapsed: false,
                })}
              >
                Hypertension
              </div>
            </Link>

            <Link to="/cardiovascular-event" onClick={handleClick}>
              <div
                className={sidebarVariants.menuItem({
                  activeItem: location.pathname === "/cardiovascular-event",
                  collapsed: false,
                })}
              >
                Cardiovascular Event
              </div>
            </Link>
          </div>
        )}

        {/* ====================================== */}
        {/* REMAINING ITEMS */}
        {/* ====================================== */}

        {sidebarItems
          .filter((item) => item.type === "item")
          .slice(5)
          .map((item) => (
            <SidebarItem
              key={item.to}
              item={item}
              collapsed={collapsed}
              onClick={handleClick}
            />
          ))}
      </Stack>

      {/* ====================================== */}
      {/* USER */}
      {/* ====================================== */}

      {!collapsed ? (
        <Panel className={sidebarVariants.userCard}>
          <Stack direction="row" gap="md" align="center">
            {/* AVATAR */}

            <div className={` ${sidebarVariants.avatar} h-12 w-12`}>CI</div>

            {/* INFO */}

            <div>
              <p className="font-medium text-[var(--ui-nav-user-text)]">
                Dr. Ivette
              </p>

              <p className="text-[var(--ui-nav-user-text-secondary)] text-xs">
                Clinical Researcher
              </p>
            </div>
          </Stack>
        </Panel>
      ) : (
        <div className="flex justify-center mt-10">
          <div className="relative">
            <div className={sidebarVariants.avatarGlow} />

            <div
              className={cn(
                sidebarVariants.avatar,
                sidebarVariants.avatarCollapsed,
              )}
            >
              CI
            </div>

            <div className={sidebarVariants.avatarStatus} />
          </div>
        </div>
      )}
    </aside>
  );
}

export default Sidebar;
