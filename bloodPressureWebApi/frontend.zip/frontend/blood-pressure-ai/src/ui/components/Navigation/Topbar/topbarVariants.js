import { cn } from "@/ui/utils/cn";

const root = `
sticky
top-0

z-40

flex
items-center
justify-between

h-20

px-8

border-b
border-[var(--ui-topbar-border)]

bg-[var(--ui-topbar-bg)]

backdrop-blur-3xl
`;

const left = `
flex
items-center
gap-5
`;

const right = `
flex
items-center
gap-4
`;

const status = (online) =>
  cn(
    `
flex
items-center
gap-3
`,
    online ? "text-emerald-300" : "text-rose-300",
  );

const dot = (online) =>
  cn(
    `
h-3
w-3

rounded-full
`,
    online
      ? "bg-emerald-400 shadow-[0_0_12px_rgba(52,211,153,.8)]"
      : "bg-rose-400 shadow-[0_0_12px_rgba(251,113,133,.8)]",
  );

export default {
  root,
  left,
  right,
  status,
  dot,
};
