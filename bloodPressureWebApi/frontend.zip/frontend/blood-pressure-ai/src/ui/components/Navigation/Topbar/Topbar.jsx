import { useEffect, useState } from "react";

import { Menu, Moon, Sun } from "lucide-react";

import { cn } from "@/ui/utils/cn";

import { checkHealth } from "@/api/healtApi";

import IconButton from "@/ui/components/Button/IconButton";

import Stack from "@/ui/primitives/Stack";

import { typography, useTheme } from "@/ui/foundations";

import topbarVariants from "./topbarVariants";

function Topbar({ sidebarOpen = false, setSidebarOpen = () => {} }) {
  const [aiOnline, setAiOnline] = useState(false);

  const { theme, toggleTheme } = useTheme();

  useEffect(() => {
    async function loadHealth() {
      try {
        await checkHealth();

        setAiOnline(true);
      } catch {
        setAiOnline(false);
      }
    }

    loadHealth();

    const interval = setInterval(loadHealth, 30000);

    return () => clearInterval(interval);
  }, []);

  return (
    <header className={topbarVariants.root}>
      <Stack direction="row" align="center" justify="between">
        <IconButton
          icon={Menu}
          variant="navigation"
          className="xl:hidden"
          onClick={() => setSidebarOpen(true)}
          aria-label="Abrir menú"
        />

        <div>
          <p className={typography.headerminiText}>Clinical Intelligence</p>

          <h1 className={typography.headerTitle}>Soft Diagnosis</h1>
        </div>
      </Stack>

      <Stack direction="row" gap="md" align="center">
        <div className={cn(topbarVariants.status(aiOnline), "hidden md:flex")}>
          <div className={topbarVariants.dot(aiOnline)} />

          <span className={typography.headerLabels}>
            {aiOnline ? "Clinical AI Ready" : "Clinical AI Offline"}
          </span>
        </div>

        <IconButton
          icon={theme === "dark" ? Sun : Moon}
          variant="navigation"
          onClick={toggleTheme}
          aria-label={
            theme === "dark" ? "Activar modo claro" : "Activar modo oscuro"
          }
          title={theme === "dark" ? "Modo claro" : "Modo oscuro"}
        />
      </Stack>
    </header>
  );
}

export default Topbar;
