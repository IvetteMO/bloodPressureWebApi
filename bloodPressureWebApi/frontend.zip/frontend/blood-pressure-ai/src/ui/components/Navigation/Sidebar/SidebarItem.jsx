import { Link, useLocation } from "react-router-dom";

import Stack from "@/ui/primitives/Stack";

import { cn } from "@/ui/utils/cn";

import { typography } from "@/ui/foundations";

import sidebarVariants from "./sidebarVariants";

export default function SidebarItem({
  item,
  collapsed = false,
  onClick = () => {},
}) {
  const location = useLocation();

  const active = location.pathname === item.to;

  const Icon = item.icon;

  return (
    <Link to={item.to} onClick={onClick}>
      <Stack
        direction="row"
        gap="md"
        align="center"
        className={sidebarVariants.menuItem({
          activeItem: active,
          collapsed,
        })}
      >
        <Icon size={21} strokeWidth={1.8} />

        {!collapsed && (
          <span className={cn(typography.bodyMedium, "font-medium")}>
            {item.title}
          </span>
        )}
      </Stack>
    </Link>
  );
}
