import {
  LayoutDashboard,
  Users,
  Activity,
  Heart,
  Moon,
  Brain,
  FileText,
} from "lucide-react";

const sidebarItems = [
  {
    type: "item",

    title: "Dashboard",

    icon: LayoutDashboard,

    to: "/",
  },

  {
    type: "item",

    title: "Patients",

    icon: Users,

    to: "/patients",
  },

  {
    type: "item",

    title: "BP Analysis",

    icon: Activity,

    to: "/bp-analysis",
  },

  {
    type: "item",

    title: "BP Load",

    icon: Activity,

    to: "/bp-load",
  },

  {
    type: "item",

    title: "Heart Rate",

    icon: Heart,

    to: "/heart-rate",
  },

  {
    type: "group",

    title: "Risk Diagnosis",

    icon: Brain,

    children: [
      {
        title: "Hypertension",

        to: "/hypertension",
      },

      {
        title: "Cardiovascular Event",

        to: "/cardiovascular-event",
      },
    ],
  },

  {
    type: "item",

    title: "Nocturnal Profile",

    icon: Moon,

    to: "/nocturnal-profile",
  },

  {
    type: "item",

    title: "Full Diagnosis",

    icon: FileText,

    to: "/full-diagnosis",
  },
];

export default sidebarItems;
