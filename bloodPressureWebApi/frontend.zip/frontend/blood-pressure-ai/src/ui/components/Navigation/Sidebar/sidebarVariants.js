import { cn } from "@/ui/utils/cn";

import { surfaces } from "@/ui/foundations";

const base = `
group

flex
items-center

rounded-[24px]

transition-all
duration-300
`;

const spacing = `
px-4
py-3
`;

const active = `
border
border-[var(--ui-nav-active-border)]

bg-gradient-to-r
from-[var(--ui-nav-active-from)]
to-[var(--ui-nav-active-to)]

text-[var(--ui-nav-active-text)]

shadow-lg
shadow-violet-500/10
`;

const inactive = `
text-[var(--ui-nav-text)]

hover:bg-[var(--ui-nav-hover)]
hover:text-[var(--ui-nav-text-hover)]
`;

const submenu = `
mt-3

ml-7

space-y-2

border-l
border-[var(--ui-nav-submenu-border)]

pl-5
`;

const groupButton = `
w-full

rounded-[24px]

px-4
py-3

transition-all
duration-300

text-[var(--ui-nav-text)]

hover:bg-[var(--ui-nav-hover)]
hover:text-[var(--ui-nav-text-hover)]
`;

const collapseButton = `
flex
items-center
justify-center

h-12
w-12

rounded-2xl

border
border-[var(--ui-nav-control-border)]

bg-[var(--ui-nav-control-bg)]

text-[var(--ui-nav-control-text)]

transition-all
duration-300

hover:bg-[var(--ui-nav-control-bg-hover)]
`;

const userCard = `
mt-10

rounded-[28px]

border
border-[var(--ui-nav-user-border)]

bg-gradient-to-br
from-[var(--ui-nav-user-from)]
to-[var(--ui-nav-user-to)]

p-4
`;

const avatar = `
flex
items-center
justify-center

rounded-full

bg-gradient-to-br
from-[var(--ui-nav-avatar-from)]
to-[var(--ui-nav-avatar-to)]

font-semibold
text-[var(--ui-nav-avatar-text)]
`;

const avatarCollapsed = `
relative

h-14
w-14

border
border-[var(--ui-nav-avatar-border)]
`;

const avatarGlow = `
absolute
inset-0

rounded-full

bg-[var(--ui-nav-avatar-glow)]

blur-xl
`;

const avatarStatus = `
absolute
right-0
bottom-0

h-3
w-3

rounded-full

border
border-[var(--ui-nav-avatar-status-border)]

bg-emerald-400

shadow-[0_0_10px_rgba(52,211,153,0.8)]
`;

/* NUEVO */

export default {
  root(collapsed) {
    return cn(
      surfaces.navigation,

      `
      sticky
      top-0

      flex
      flex-col

      min-h-screen

      overflow-hidden

      px-5
      py-8
      `,

      collapsed ? "w-28" : "w-[280px] xl:w-[320px]",
    );
  },

  menuItem({ activeItem, collapsed }) {
    return cn(
      base,

      spacing,

      activeItem ? active : inactive,

      collapsed
        ? `
          justify-center
          px-0
        `
        : `
          justify-start
          gap-4
        `,
    );
  },

  submenu,
  groupButton,
  collapseButton,
  userCard,
  avatar,
  avatarCollapsed,
  avatarGlow,
  avatarStatus,
};
