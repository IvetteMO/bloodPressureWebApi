import { cn } from "../../utils/cn";
import { spacing } from "../../foundations";

import Surface from "../../primitives/Surface";

import panelVariants from "./panelVariants";

export default function Panel({
  variant = "default",

  background,

  effects = [],

  children,

  className = "",

  ...props
}) {
  const current = panelVariants[variant] ?? panelVariants.default;

  return (
    <Surface
      variant={current.surface}
      background={background}
      effects={effects}
      interactive={current.interactive}
      className={cn(
        spacing[current.spacing],

        className,
      )}
      {...props}
    >
      {children}
    </Surface>
  );
}
