export { default } from "./Panel";
