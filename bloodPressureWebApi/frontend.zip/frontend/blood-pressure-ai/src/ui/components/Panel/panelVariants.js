/**
 * ============================================================
 * Clinical UI Kit
 * Panel Variants
 * ============================================================
 */

export const panelVariants = {
  default: {
    surface: "panel",
    spacing: "panel",
    interactive: false,
  },

  interactive: {
    surface: "panel",
    spacing: "panel",
    interactive: true,
  },

  hero: {
    surface: "hero",
    spacing: "hero",
    interactive: false,
  },

  heroCompact: {
    surface: "hero",
    spacing: "heroCompact",
    interactive: false,
  },

  compact: {
    surface: "card",
    spacing: "compact",
    interactive: false,
  },

  flat: {
    surface: "card",
    spacing: "card",
    interactive: false,
  },

  chart: {
    surface: "panel",
    spacing: "panel",
    interactive: true,
  },

  metric: {
    surface: "metric",
    spacing: "metric",
    interactive: true,
  },

  listItem: {
    surface: "listItem",
    spacing: "metric",
    interactive: true,
  },

  patientRow: {
    surface: "patientRow",
    spacing: "metric",
    interactive: true,
  },

  empty: {
    surface: "empty",
    spacing: "empty",
    interactive: false,
  },

  heroInfo: {
    surface: "heroInfo",
    spacing: "compact",
    interactive: false,
  },

  diagnosis: {
    surface: "diagnosis",
    spacing: "diagnosis",
    interactive: true,
  },

  patientHero: {
    surface: "patientHero",
    spacing: "panel",
    interactive: false,
  },

  patientRecord: {
    surface: "patientRecord",
    spacing: "compact",
    interactive: false,
  },

  dropzone: {
    surface: "panel",
    spacing: "compact",
    interactive: true,
  },

  studySummary: {
    surface: "studySummary",
    spacing: "compact",
    interactive: false,
  },
};

export default panelVariants;
