/**
 * ============================================================
 * Clinical UI Kit
 * Search Field Variants
 * ============================================================
 */

const searchFieldVariants = {
  default: {
    container: `
      relative
      w-full
    `,

    icon: `
      absolute
      left-5
      top-1/2
      -translate-y-1/2
      z-10
      pointer-events-none

      text-[var(--ui-text-caption)]
    `,

    input: `
      pl-12
    `,
  },

  compact: {
    container: `
      relative
      w-full
    `,

    icon: `
      absolute
      left-4
      top-1/2
      -translate-y-1/2
      z-10
      pointer-events-none

      text-[var(--ui-text-caption)]
    `,

    input: `
      pl-11
    `,
  },
};

export default searchFieldVariants;
