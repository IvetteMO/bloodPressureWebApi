import { Search } from "lucide-react";

import { cn } from "@/ui/utils/cn";

import { forms } from "@/ui/foundations/forms";

import searchFieldVariants from "./searchFieldVariants";

export default function SearchField({
  value,

  onChange,

  placeholder = "Search...",

  variant = "default",

  icon: Icon = Search,

  className = "",
}) {
  const current = searchFieldVariants[variant] ?? searchFieldVariants.default;

  return (
    <div
      className={cn(
        current.container,

        className,
      )}
    >
      <Icon size={18} className={current.icon} />

      <input
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        className={cn(
          forms.search,
          current.input,
          "bg-transparent",
          "backdrop-blur-xl",
        )}
      />
    </div>
  );
}
