import { cn } from "../../utils/cn";

export default function Split({
  left,

  right,

  ratio = "8-4",

  className = "",
}) {
  return (
    <div
      className={cn(
        "grid grid-cols-1 gap-6 lg:grid-cols-12",

        className,
      )}
    >
      <div
        className={
          ratio === "9-3"
            ? "lg:col-span-9"
            : ratio === "8-4"
              ? "lg:col-span-8"
              : ratio === "4-8"
                ? "lg:col-span-4"
                : "lg:col-span-6"
        }
      >
        {left}
      </div>

      <div
        className={
          ratio === "9-3"
            ? "lg:col-span-3"
            : ratio === "8-4"
              ? "lg:col-span-4"
              : ratio === "4-8"
                ? "lg:col-span-8"
                : "lg:col-span-6"
        }
      >
        {right}
      </div>
    </div>
  );
}
