export { default } from "./Split";
