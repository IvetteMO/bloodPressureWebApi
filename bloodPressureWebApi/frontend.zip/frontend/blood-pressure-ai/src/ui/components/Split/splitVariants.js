export const splitVariants = {
  "8-4": "grid grid-cols-1 gap-6 lg:grid-cols-12",

  "4-8": "grid grid-cols-1 gap-6 lg:grid-cols-12",

  "6-6": "grid grid-cols-1 gap-6 lg:grid-cols-2",
};
