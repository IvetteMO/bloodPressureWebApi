import { cn } from "@/ui/utils/cn";

export default function ModalBody({
  children,

  className,
}) {
  return <div className={cn("space-y-8", className)}>{children}</div>;
}
