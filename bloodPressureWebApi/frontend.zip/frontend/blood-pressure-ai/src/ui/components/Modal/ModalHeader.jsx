import { X } from "lucide-react";
import { motion } from "framer-motion";

import { cn } from "@/ui/utils/cn";

import { motionPresets } from "@/ui/animations";
import Badge from "@/ui/components/Badge";
import { spacing } from "@/ui/foundations/spacing";
import { typography } from "@/ui/foundations/typography";

import IconButton from "@/ui/components/Button/IconButton";

import modalHeaderVariants from "./modalHeaderVariants";

export default function ModalHeader({
  variant = "default",

  eyebrow,

  title,

  subtitle,

  onClose,

  badges,

  children,

  animated = true,

  className = "",
}) {
  const current = modalHeaderVariants[variant] ?? modalHeaderVariants.default;

  const content = (
    <div className={cn(spacing[current.spacing], current.container, className)}>
      <div className={current.header}>
        <div className={cn("min-w-0", current.contentWidth)}>
          {eyebrow && <p className={typography[current.eyebrow]}>{eyebrow}</p>}

          {title && (
            <h1 className={cn(typography[current.title], current.titleMargin)}>
              {title}
            </h1>
          )}

          {subtitle && (
            <p className={cn(typography.heroSubtitle, current.subtitleMargin)}>
              {subtitle}
            </p>
          )}

          {badges?.length > 0 && <Badge variant="violet" items={badges} />}

          {children && <div className={current.childrenMargin}>{children}</div>}
        </div>

        {onClose && (
          <div className={current.actions}>
            <IconButton variant="ghost" icon={X} onClick={onClose} />
          </div>
        )}
      </div>
    </div>
  );

  if (!animated) return content;

  return <motion.section {...motionPresets.fadeUp}>{content}</motion.section>;
}
