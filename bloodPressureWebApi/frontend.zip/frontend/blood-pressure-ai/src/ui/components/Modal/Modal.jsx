import { AnimatePresence, motion } from "framer-motion";

import modalVariants from "./modalVariants";

export default function Modal({
  open = true,

  onClose,

  size = "xl",

  children,
}) {
  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className={modalVariants.overlay}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.22 }}
          onClick={onClose}
        >
          <motion.div
            className={modalVariants.size(size)}
            initial={{
              opacity: 0,
              y: 40,
              scale: 0.96,
            }}
            animate={{
              opacity: 1,
              y: 0,
              scale: 1,
            }}
            exit={{
              opacity: 0,
              y: 20,
              scale: 0.98,
            }}
            transition={{
              duration: 0.28,
              ease: "easeOut",
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className={modalVariants.panel}>{children}</div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
