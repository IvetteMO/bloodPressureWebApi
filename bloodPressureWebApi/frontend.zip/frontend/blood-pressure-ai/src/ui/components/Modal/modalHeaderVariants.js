const modalHeaderVariants = {
  default: {
    spacing: "heroCompact",

    header: "flex items-start justify-between gap-6",

    actions: "flex shrink-0 items-start",

    eyebrow: "eyebrow",

    title: "heroTitle",

    contentWidth: "max-w-[760px]",

    container: "pt-4",

    titleMargin: "mt-5",

    subtitleMargin: "mt-5",

    childrenMargin: "mt-5",
  },

  compact: {
    spacing: "compact",

    header: "flex items-start justify-between gap-6",

    actions: "flex shrink-0 items-start",

    eyebrow: "eyebrow",

    title: "heroTitleCompact",

    contentWidth: "max-w-[680px]",
    container: "pt-4",

    titleMargin: "mt-2",

    subtitleMargin: "mt-3",

    childrenMargin: "mt-4",
  },
};

export default modalHeaderVariants;
