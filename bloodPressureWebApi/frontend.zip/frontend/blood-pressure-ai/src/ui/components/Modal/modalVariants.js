import { cn } from "@/ui/utils/cn";

import { surfaces } from "@/ui/foundations";

const overlay = `
fixed
inset-0

z-[9999]

flex
items-start
justify-center

overflow-y-auto
overflow-x-hidden

px-4
py-10

md:px-6
md:py-12

bg-black/75

backdrop-blur-xl
`;

const container = `
relative

w-full

overflow-hidden
`;

const sizes = {
  sm: "max-w-2xl",

  md: "max-w-4xl",

  lg: "max-w-6xl",

  xl: "max-w-7xl",
};

const panel = `
relative

overflow-hidden

${surfaces.floating}
`;

export default {
  overlay,

  container,

  panel,

  size(size = "xl") {
    return cn(container, sizes[size]);
  },
};
