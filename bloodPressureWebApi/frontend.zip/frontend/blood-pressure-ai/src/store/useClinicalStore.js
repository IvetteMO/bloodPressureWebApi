import { create }
  from "zustand";

const useClinicalStore =
  create((set) => ({

    // =====================================
    // CURRENT ENTITIES
    // =====================================

    currentPatient: null,

    currentStudy: null,

    currentDiagnosis: null,

    // =====================================
    // SETTERS
    // =====================================

    setCurrentPatient:
      (patient) =>

        set({
          currentPatient: patient
        }),

    setCurrentStudy:
      (study) =>

        set({
          currentStudy: study
        }),

    setCurrentDiagnosis:
      (diagnosis) =>

        set({
          currentDiagnosis: diagnosis
        }),

    // =====================================
    // CLEAR STUDY
    // =====================================

    clearCurrentStudy:
      () =>

        set({
          currentStudy: null
        }),

    // =====================================
    // CLEAR SESSION
    // =====================================

    clearClinicalSession:
      () =>

        set({

          currentPatient: null,

          currentStudy: null,

          currentDiagnosis: null
        })
  }));

export default useClinicalStore;