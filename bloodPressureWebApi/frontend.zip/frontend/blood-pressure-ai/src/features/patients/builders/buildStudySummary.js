// ============================================
// buildStudySummary.js
// ============================================

export default function buildStudySummary({
  awakeTime,

  sleepTime,
}) {
  let estimatedReadings = "~47";

  let schedule = "Custom";

  if (awakeTime === "06:00" && sleepTime === "23:00") {
    schedule = "Standard";
  }

  return {
    estimatedReadings,

    schedule,
  };
}
