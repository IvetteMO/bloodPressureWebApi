// ============================================
// buildBMI.js
// ============================================

export default function buildBMI(height, weight) {
  const h = Number(height);
  const w = Number(weight);

  if (!h || !w) {
    return {
      value: "--",
      subtitle: "Calculated automatically",
      appearance: "bg-cyan-500/10",
    };
  }

  const bmi = w / (h * h);
  const value = bmi.toFixed(1);

  if (bmi < 18.5) {
    return {
      value,
      subtitle: "Underweight",
      appearance: "bg-sky-500/10",
    };
  }

  if (bmi < 25) {
    return {
      value,
      subtitle: "Normal",
      appearance: "bg-emerald-500/10",
    };
  }

  if (bmi < 30) {
    return {
      value,
      subtitle: "Overweight",
      appearance: "bg-amber-500/10",
    };
  }

  return {
    value,
    subtitle: "Obesity",
    appearance: "bg-fuchsia-500/10",
  };
}
