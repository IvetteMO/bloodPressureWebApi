import { FolderOpen, Pencil, Plus, Trash2, User } from "lucide-react";
import { typography } from "@/ui/foundations/typography";
import Panel from "@/ui/components/Panel";
import AvatarBadge from "@/ui/components/DataDisplay/AvatarBadge";
import IconButton from "@/ui/components/Button/IconButton";

export default function PatientRow({
  patient,

  onDetails,

  onEdit,

  onStudy,

  onDelete,
}) {
  return (
    <Panel variant="patientRow" className="group">
      <div className="flex lg:flex-row flex-col lg:justify-between lg:items-center gap-8">
        <div className="flex items-center gap-4">
          <AvatarBadge icon={User} variant="patient" />

          <div>
            <h3 className={typography.entityTitle}>
              {patient.firstName} {patient.lastName}
            </h3>

            <p className={typography.entityMeta}>
              Patient ID #{patient.patientId}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <IconButton
            icon={FolderOpen}
            variant="cyan"
            glow
            onClick={onDetails}
          />

          <IconButton icon={Pencil} variant="violet" glow onClick={onEdit} />

          <IconButton icon={Plus} variant="success" glow onClick={onStudy} />

          <IconButton icon={Trash2} variant="danger" glow onClick={onDelete} />
        </div>
      </div>
    </Panel>
  );
}
