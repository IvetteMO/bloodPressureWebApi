import Panel from "@/ui/components/Panel";
import Grid from "@/ui/primitives/Grid";

export default function StudySummaryCard({ readings, schedule }) {
  return (
    <Panel variant="compact">
      <Grid cols={2} gap="lg">
        <div>
          <p className="text-xs tracking-[0.25em] text-zinc-500 uppercase">
            Readings
          </p>

          <h2 className="mt-3 text-4xl font-black text-white">{readings}</h2>
        </div>

        <div>
          <p className="text-xs tracking-[0.25em] text-zinc-500 uppercase">
            Schedule
          </p>

          <h2 className="mt-3 text-3xl font-bold text-cyan-300">{schedule}</h2>
        </div>
      </Grid>
    </Panel>
  );
}
