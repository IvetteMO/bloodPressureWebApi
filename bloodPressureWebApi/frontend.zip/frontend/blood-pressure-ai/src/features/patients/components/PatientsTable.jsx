// ============================================
// PatientsTable.jsx
// ============================================
import { useMemo, useState } from "react";
import { User, ArrowRight } from "lucide-react";

import { usePatients } from "../hooks/usePatients";
import { useDeletePatient } from "../hooks/useDeletePatient";
import { usePatient } from "../hooks/usePatient";
import { usePatientStudies } from "../hooks/usePatientStudies";

import Button from "@/ui/components/Button/Button";

import PatientDetailsModal from "../modals/PatientDetailsModal";
import EditPatientModal from "../modals/EditPatientModal";
import CreateStudyModal from "../modals/CreateStudyModal";
import SearchField from "@/ui/components/SearchField/SearchField";
import PatientsRow from "./PatientRow";
import Panel from "@/ui/components/Panel";
import Loader from "@/ui/components/Loader";

export default function PatientsTable({ onNewPatient }) {
  // ======================
  // STATE
  // ======================
  const [search, setSearch] = useState("");
  const [activeModal, setActiveModal] = useState(null);
  const [selectedPatientId, setSelectedPatientId] = useState(null);

  // ======================
  // DATA
  // ======================
  const { data: patients = [] } = usePatients();

  const { data: selectedPatient, isLoading } = usePatient(selectedPatientId);

  const { data: studies = [] } = usePatientStudies(selectedPatientId);

  const currentStudy = studies?.[0];

  const deleteMutation = useDeletePatient();

  const loadingPatient = isLoading && selectedPatientId !== null;

  // ======================
  // FILTER
  // ======================
  const filteredPatients = useMemo(() => {
    const term = search.toLowerCase();
    return patients.filter((p) =>
      `${p.firstName} ${p.lastName}`.toLowerCase().includes(term),
    );
  }, [patients, search]);

  // ======================
  // MODALS
  // ======================
  const openModal = (modal, id) => {
    setSelectedPatientId(id);
    setActiveModal(modal);
  };

  const closeModal = () => {
    setActiveModal(null);
    setSelectedPatientId(null);
  };

  // ======================
  // DELETE
  // ======================
  const handleDelete = async (id) => {
    if (!window.confirm("Delete patient?")) return;

    try {
      await deleteMutation.mutateAsync(id);
    } catch (err) {
      console.error(err);
      alert("Delete failed");
    }
  };

  return (
    <>
      <Panel variant="default">
        {/* HEADER */}

        <div className="mb-8 flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
          {/* SEARCH */}
          <div className="w-full lg:max-w-[460px]">
            <SearchField
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search patient..."
            />
          </div>

          {/* BUTTON */}
          <Button
            variant="primary"
            size="lg"
            leftIcon={<User size={18} />}
            rightIcon={<ArrowRight size={18} />}
            onClick={onNewPatient}
            className="w-full lg:w-[260px]"
          >
            New Patient
          </Button>
        </div>

        {/* ROWS */}

        <div className="space-y-4">
          {filteredPatients.map((patient) => (
            <PatientsRow
              key={patient.patientId}
              patient={patient}
              onDetails={() => openModal("details", patient.patientId)}
              onEdit={() => openModal("edit", patient.patientId)}
              onStudy={() => openModal("study", patient.patientId)}
              onDelete={() => handleDelete(patient.patientId)}
            />
          ))}

          {/* LOADING OVERLAY */}
          {loadingPatient && selectedPatientId && (
            <Loader variant="clinical" layout="panel" />
          )}
        </div>
      </Panel>

      {/* MODALS */}
      {activeModal === "details" && selectedPatient && (
        <PatientDetailsModal patient={selectedPatient} onClose={closeModal} />
      )}

      {activeModal === "edit" && selectedPatient && (
        <EditPatientModal
          patient={selectedPatient}
          currentStudy={currentStudy}
          onClose={closeModal}
        />
      )}

      {activeModal === "study" && selectedPatient && (
        <CreateStudyModal patient={selectedPatient} onClose={closeModal} />
      )}
    </>
  );
}
