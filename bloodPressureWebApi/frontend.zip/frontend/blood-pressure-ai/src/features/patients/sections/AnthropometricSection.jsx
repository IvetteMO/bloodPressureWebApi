import { Scale } from "lucide-react";

import { FormSection } from "@/ui/components/Form/Layout";
import { Input } from "@/ui/components/Form";
import { ClinicalMetricCard } from "@/ui/components/DataDisplay/MetricCard";
import Grid from "@/ui/primitives/Grid";
import Stack from "@/ui/primitives/Stack";

import { cn } from "@/ui/utils/cn";

export default function AnthropometricSection({
  value,

  onChange,

  className,
}) {
  const bmi = (() => {
    const height = Number(value.height);
    const weight = Number(value.weight);

    if (!height || !weight) {
      return "--";
    }

    return (weight / (height * height)).toFixed(1);
  })();

  return (
    <FormSection
      className={cn(className)}
      title="Anthropometric Data"
      subtitle="Body composition and cardiovascular indicators."
    >
      <Stack gap="md">
        <Grid cols={2} gapX="x-md" gapY="y-md">
          <Input
            label="Height (m)"
            type="number"
            placeholder="Height"
            value={value.height}
            onChange={(e) => onChange("height", e.target.value)}
          />

          <Input
            label="Weight (kg)"
            type="number"
            placeholder="Weight"
            value={value.weight}
            onChange={(e) => onChange("weight", e.target.value)}
          />
        </Grid>

        <ClinicalMetricCard
          variant="clinicalMetric"
          title="Body Mass Index"
          value={bmi}
          subtitle="Calculated automatically"
          icon={Scale}
          accent="#22D3EE"
          appearance="bg-cyan-500/10"
        />
      </Stack>
    </FormSection>
  );
}
