// ============================================
// StudySelectorSection.jsx
// ============================================

import Button from "@/ui/components/Button";
import { typography } from "@/ui/foundations";
import Stack from "@/ui/primitives/Stack";

// ============================================
// COMPONENT
// ============================================

export default function StudySelectorSection({
  studies = [],

  selectedStudy,

  onSelect,

  className = "",
}) {
  if (!studies.length) {
    return null;
  }

  return (
    <Stack gap="sm" className={className}>
      <p className={typography.patientRecordLabel}>Available Studies</p>

      <div className="flex flex-wrap gap-4">
        {studies.map((study) => {
          const isActive = selectedStudy?.studyId === study.studyId;

          return (
            <Button
              key={study.studyId}
              variant={isActive ? "selectableActive" : "selectable"}
              size="sm"
              onClick={() => onSelect?.(study)}
            >
              Study #{study.studyId}
            </Button>
          );
        })}
      </div>
    </Stack>
  );
}
