// ============================================
// PatientStudyMetricsSection.jsx
// ============================================

import Metric from "@/ui/components/Metric";
import metricPalettes from "@/ui/components/Metric/metricPalette";
import Panel from "@/ui/components/Panel";
import { typography } from "../../../ui/foundations";
import Grid from "@/ui/primitives/Grid";
import Stack from "@/ui/primitives/Stack";

// ============================================
// HELPERS
// ============================================

function formatNumber(value, decimals = 0) {
  if (value === null || value === undefined) {
    return "--";
  }

  const number = Number(value);

  if (Number.isNaN(number)) {
    return "--";
  }

  return number.toFixed(decimals);
}

function formatPressure(systolic, diastolic) {
  if (
    systolic === null ||
    systolic === undefined ||
    diastolic === null ||
    diastolic === undefined
  ) {
    return "--";
  }

  return `${formatNumber(systolic)} / ${formatNumber(diastolic)}`;
}

// ============================================
// COMPONENT
// ============================================

export default function PatientStudyMetricsSection({
  study,

  activeTab,

  className = "",
}) {
  if (!study) {
    return null;
  }

  // ============================================
  // DATA
  // ============================================

  const features = study?.features;

  const diagnosis = study?.diagnosis;

  // ============================================
  // RENDER
  // ============================================

  return (
    <Panel variant="default" className={className}>
      <Stack gap="xl">
        {/* ===================================== */}
        {/* HEADER */}
        {/* ===================================== */}

        <Stack gap="xs">
          <h2 className={typography.cardTitle}>Clinical Metrics</h2>

          <p className={typography.caption}>
            Ambulatory cardiovascular measurements and intelligent analysis.
          </p>
        </Stack>

        {/* ===================================== */}
        {/* OVERVIEW */}
        {/* ===================================== */}
        <Panel variant="compact">
          {activeTab === "Overview" && (
            <Grid cols={3} gapX="lg" gapY="xl" className="mx-8 my-35 mt-6">
              <Metric
                className="mt-15"
                variant="clinicalModal"
                label="SYS Trend"
                value={formatNumber(features?.systolicTrend)}
                palette={metricPalettes.systolic}
              />

              <Metric
                className="mt-15"
                variant="clinicalModal"
                label="DIA Trend"
                value={formatNumber(features?.diastolicTrend)}
                palette={metricPalettes.diastolic}
              />

              <Metric
                className="mt-15"
                variant="clinicalModal"
                label="Pulse"
                value={formatNumber(features?.meanPulse)}
                palette={metricPalettes.pulse}
              />
            </Grid>
          )}

          {/* ===================================== */}
          {/* PRESSURE */}
          {/* ===================================== */}

          {activeTab === "Pressure" && (
            <Grid cols={3} gapX="md" gapY="md" className="mx-8 my-35 mt-6">
              <Metric
                className="mt-15"
                variant="clinicalModal"
                label="Day Mean"
                value={formatPressure(
                  features?.daySystolicMean,
                  features?.dayDiastolicMean,
                )}
                size="md"
                palette={metricPalettes.pulse}
              />

              <Metric
                className="mt-15"
                variant="clinicalModal"
                label="Night Mean"
                value={formatPressure(
                  features?.nightSystolicMean,
                  features?.nightDiastolicMean,
                )}
                size="md"
                palette={metricPalettes.diastolic}
              />

              <Metric
                className="mt-15"
                variant="clinicalModal"
                label="Pressure Load"
                value={formatNumber(features?.totalPressureLoad, 1)}
                suffix="%"
                palette={metricPalettes.systolic}
              />
            </Grid>
          )}

          {/* ===================================== */}
          {/* NOCTURNAL */}
          {/* ===================================== */}

          {activeTab === "Nocturnal" && (
            <Grid cols={3} gapX="md" gapY="md" className="mx-8 my-35 mt-6">
              <Metric
                className="mt-15"
                variant="clinicalModal"
                label="Dipping"
                value={formatNumber(features?.dippingPercent, 1)}
                suffix="%"
                palette={metricPalettes.pulse}
              />

              <Metric
                className="mt-15"
                variant="clinicalModal"
                label="SYS Ratio"
                value={formatNumber(features?.systolicNightRatio, 2)}
                palette={metricPalettes.nocturnal}
              />

              <Metric
                className="mt-15"
                variant="clinicalModal"
                label="DIA Ratio"
                value={formatNumber(features?.diastolicNightRatio, 2)}
                palette={metricPalettes.diastolic}
              />
            </Grid>
          )}

          {/* ===================================== */}
          {/* TRENDS */}
          {/* ===================================== */}

          {activeTab === "Trends" && (
            <Grid cols={3} gapX="md" gapY="md" className="mx-8 my-35 mt-6">
              <Metric
                className="mt-15"
                variant="clinicalModal"
                label="Day Load"
                value={formatNumber(features?.dayPressureLoad, 1)}
                suffix="%"
                palette={metricPalettes.risk}
              />

              <Metric
                className="mt-15"
                variant="clinicalModal"
                label="Night Load"
                value={formatNumber(features?.nightPressureLoad, 1)}
                suffix="%"
                palette={metricPalettes.diastolic}
              />

              <Metric
                className="mt-15"
                variant="clinicalModal"
                label="Pulse"
                value={formatNumber(features?.meanPulse)}
                palette={metricPalettes.pulse}
              />
            </Grid>
          )}

          {/* ===================================== */}
          {/* AI */}
          {/* ===================================== */}

          {activeTab === "AI" && (
            <Grid cols={3} gapX="md" gapY="md" className="mx-8 my-35 mt-6">
              <Metric
                className="mt-15"
                variant="diagnosisModal"
                label="Final Risk"
                value={diagnosis?.finalRiskLevel ?? "--"}
                size="md"
                palette={metricPalettes.risk}
              />

              <Metric
                className="mt-15"
                variant="diagnosisModal"
                label="Heart Rate"
                value={diagnosis?.heartRateDiagnosis ?? "--"}
                size="md"
                palette={metricPalettes.diastolic}
              />

              <Metric
                className="mt-15"
                variant="diagnosisModal"
                label="Nocturnal"
                value={diagnosis?.nocturnalProfile ?? "--"}
                size="md"
                palette={metricPalettes.systolic}
              />
            </Grid>
          )}
        </Panel>
      </Stack>
    </Panel>
  );
}
