import { FormSection } from "@/ui/components/Form/Layout";

import Stack from "@/ui/primitives/Stack";

import { CheckboxCard, Select } from "@/ui/components/Form";

import { cn } from "@/ui/utils/cn";

export default function RiskFactorsSection({
  value,

  onChange,

  className,
}) {
  return (
    <FormSection
      className={cn(className)}
      title="Cardiovascular Risk"
      subtitle="Lifestyle and hereditary cardiovascular risk indicators."
    >
      <Stack gap="sm">
        <CheckboxCard
          accent="fuchsia"
          title="Smoking"
          description="Active smoking behavior associated with elevated cardiovascular risk."
          checked={value.smoking}
          onChange={(checked) => onChange("smoking", checked)}
        />

        <CheckboxCard
          accent="cyan"
          title="Diabetes"
          description="Diabetes mellitus cardiovascular risk condition."
          checked={value.diabetes}
          onChange={(checked) => onChange("diabetes", checked)}
        />

        <CheckboxCard
          accent="emerald"
          title="Hypertension Treatment"
          description="Current antihypertensive pharmacological treatment."
          checked={value.hypertensionTreatment}
          onChange={(checked) => onChange("hypertensionTreatment", checked)}
        />
      </Stack>

      <Select
        className="mt-4"
        label="Parental Hypertension"
        value={value.parentalHypertension}
        onChange={(e) =>
          onChange("parentalHypertension", Number(e.target.value))
        }
        options={[
          {
            label: "None",
            value: 0,
          },
          {
            label: "One Parent",
            value: 1,
          },
          {
            label: "Both Parents",
            value: 2,
          },
        ]}
      />
    </FormSection>
  );
}
