import { FormSection } from "@/ui/components/Form/Layout";
import { Input } from "@/ui/components/Form";

import Panel from "@/ui/components/Panel";

import Grid from "@/ui/primitives/Grid";
import Stack from "@/ui/primitives/Stack";

import { cn } from "@/ui/utils/cn";

export default function StudyConfigurationSection({
  value,
  onChange,
  className,
}) {
  return (
    <FormSection
      className={cn(className)}
      title="Study Configuration"
      subtitle="Circadian ambulatory monitoring configuration."
    >
      <Stack gap="lg">
        <Grid cols={2} gapX="x-md" gapY="y-md">
          <Input
            label="Awake Time"
            type="time"
            value={value.awakeTime}
            onChange={(e) => onChange("awakeTime", e.target.value)}
          />

          <Input
            label="Sleep Time"
            type="time"
            value={value.sleepTime}
            onChange={(e) => onChange("sleepTime", e.target.value)}
          />
        </Grid>

        <Panel variant="compact">
          <Stack gap="lg">
            <p className="text-xs tracking-[0.28em] text-zinc-500 uppercase">
              Expected Analysis Window
            </p>

            <Grid cols={3} gapX="x-lg">
              <div>
                <p className="text-sm text-zinc-500">Readings</p>

                <h3 className="mt-2 text-4xl font-black text-[var(--ui-text-body)]">
                  ~47
                </h3>
              </div>

              <div>
                <p className="text-sm text-zinc-500">Awake</p>

                <h3 className="mt-2 text-2xl font-bold text-cyan-300">
                  {value.awakeTime}
                </h3>
              </div>

              <div>
                <p className="text-sm text-zinc-500">Sleep</p>

                <h3 className="mt-2 text-2xl font-bold text-fuchsia-300">
                  {value.sleepTime}
                </h3>
              </div>
            </Grid>
          </Stack>
        </Panel>
      </Stack>
    </FormSection>
  );
}
