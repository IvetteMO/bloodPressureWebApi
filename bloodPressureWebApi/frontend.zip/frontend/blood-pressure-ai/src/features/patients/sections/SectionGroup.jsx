import { cn } from "@/ui/utils/cn";

export default function SectionGroup({ children, className = "" }) {
  return <div className={cn("pb-6", className)}>{children}</div>;
}
