import { FormSection } from "@/ui/components/Form/Layout";

import { FileDropzone } from "@/ui/components/Form";

import { cn } from "@/ui/utils/cn";

export default function DatasetUploadSection({
  file,

  onChange,

  className,
}) {
  return (
    <FormSection
      className={cn(className)}
      title="ABPM Dataset Import"
      subtitle="Upload ambulatory blood pressure monitoring dataset for intelligent analysis."
    >
      <FileDropzone
        className="mt-5"
        label="Upload Excel File"
        description="Click to select a .xlsx or .xls file"
        accept=".xlsx,.xls"
        value={file}
        onChange={onChange}
      />
    </FormSection>
  );
}
