import { ShieldAlert } from "lucide-react";

import { FormSection } from "@/ui/components/Form/Layout";

import ActionCard from "@/ui/components/ActionCard";

import { cn } from "@/ui/utils/cn";

export default function RiskFactorsActionSection({
  onClick,

  className,
}) {
  return (
    <FormSection
      className={cn(className)}
      title="Cardiovascular Risk"
      subtitle="Update intelligent cardiovascular risk assessment variables."
    >
      <ActionCard
        icon={ShieldAlert}
        accent="fuchsia"
        title="Edit Risk Factors"
        description="Smoking, diabetes, hereditary hypertension and cardiovascular profile."
        onClick={onClick}
      />
    </FormSection>
  );
}
