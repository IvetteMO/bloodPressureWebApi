import Panel from "@/ui/components/Panel";
import { typography } from "@/ui/foundations/typography";
import { spacing } from "@/ui/foundations/spacing";
import { cn } from "@/ui/utils/cn";

export default function PatientHero({ patient }) {
  return (
    <Panel variant="patientHero" className={spacing.patientHero}>
      <div className="flex items-center justify-between">
        <div>
          <p className={typography.patientHeroLabel}>Clinical Patient</p>

          <h2 className={typography.patientHeroName}>
            {patient?.firstName} {patient?.lastName}
          </h2>

          <p className={typography.patientHeroSubtitle}>
            Patient ID: {patient?.patientId}
          </p>
        </div>

        <Panel
          variant="patientRecord"
          className={cn(spacing.patientRecord, "text-center")}
        >
          <p className={typography.patientRecordLabel}>Clinical Record</p>

          <h3 className={typography.patientRecordValue}>
            #{patient?.patientId}
          </h3>
        </Panel>
      </div>
    </Panel>
  );
}
