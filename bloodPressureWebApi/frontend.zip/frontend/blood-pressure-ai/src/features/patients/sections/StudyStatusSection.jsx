// ============================================
// StudyStatusSection.jsx
// ============================================

import Panel from "@/ui/components/Panel";
import Badge from "@/ui/components/Badge";

import Stack from "@/ui/primitives/Stack";

import { getStudyStatus } from "@/ui/components/Clinical/Diagnosis";

import { cn } from "@/ui/utils/cn";
import { typography } from "../../../ui/foundations";

export default function StudyStatusSection({
  study,

  className = "",
}) {
  if (!study) {
    return null;
  }

  // ============================================
  // STATUS
  // ============================================

  const status = getStudyStatus(study.studyStatus);

  // ============================================
  // RENDER
  // ============================================

  return (
    <Panel variant="default" className={cn(className)}>
      <div className="flex w-full items-center justify-between">
        {/* ==================================== */}
        {/* STUDY */}
        {/* ==================================== */}

        <Stack gap="xs">
          <p className={typography.caption}>Selected Study</p>

          <h3 className={typography.cardTitle}>Study #{study.studyId}</h3>
        </Stack>

        {/* ==================================== */}
        {/* STATUS */}
        {/* ==================================== */}

        <Badge appearance={status.appearance}>{status.label}</Badge>
      </div>
    </Panel>
  );
}
