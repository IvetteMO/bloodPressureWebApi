import Grid from "@/ui/primitives/Grid";

import { FormSection } from "@/ui/components/Form/Layout";

import { Input, Select } from "@/ui/components/Form";

export default function PatientInformationSection({
  value,

  onChange,
}) {
  return (
    <FormSection
      title="Patient Information"
      subtitle="Core patient demographic and identification data."
    >
      <Grid cols={2} gapX="x-md" gapY="y-md">
        <Input
          label="First Name"
          value={value.firstName}
          onChange={(e) => onChange("firstName", e.target.value)}
        />

        <Input
          label="Last Name"
          value={value.lastName}
          onChange={(e) => onChange("lastName", e.target.value)}
        />

        <Input
          label="Birth Date"
          type="date"
          value={value.birthDate}
          onChange={(e) => onChange("birthDate", e.target.value)}
        />

        <Select
          label="Sex"
          value={value.gender}
          onChange={(e) => onChange("gender", e.target.value)}
          options={[
            {
              label: "Male",
              value: "Male",
            },
            {
              label: "Female",
              value: "Female",
            },
          ]}
        />

        <Input
          label="Phone"
          value={value.phone}
          onChange={(e) => onChange("phone", e.target.value)}
        />

        <Input
          type="email"
          label="Email"
          value={value.email}
          onChange={(e) => onChange("email", e.target.value)}
        />
      </Grid>
    </FormSection>
  );
}
