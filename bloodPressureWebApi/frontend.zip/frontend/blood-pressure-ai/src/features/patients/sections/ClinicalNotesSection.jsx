import { cn } from "@/ui/utils/cn";
import { FormSection } from "@/ui/components/Form/Layout";
import { Textarea } from "@/ui/components/Form";

export default function ClinicalNotesSection({
  value,

  onChange,

  className,
}) {
  return (
    <FormSection
      className={cn(className)}
      title="Clinical Notes"
      subtitle="Physician observations, cardiovascular comments and clinical context."
    >
      <Textarea
        label="Physician Notes"
        rows={15}
        value={value.clinicalNotes}
        onChange={(e) => onChange("clinicalNotes", e.target.value)}
      />
    </FormSection>
  );
}
