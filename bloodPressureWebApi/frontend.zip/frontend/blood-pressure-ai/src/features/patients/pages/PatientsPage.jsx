import { useState } from "react";

import Page from "@/ui/components/Page";
import Hero from "@/ui/components/Hero";

import PatientsTable from "../components/PatientsTable";

import CreateFullPatientModal from "../modals/CreateFullPatientModal";

export default function PatientsPage() {
  const [openCreate, setOpenCreate] = useState(false);

  return (
    <Page>
      <Hero
        variant="heroCompact"
        eyebrow="Clinical Registry"
        title="Patients"
        subtitle="Unified nocturnal cardiovascular patient workflow."
      />

      <PatientsTable onNewPatient={() => setOpenCreate(true)} />

      {openCreate && (
        <CreateFullPatientModal onClose={() => setOpenCreate(false)} />
      )}
    </Page>
  );
}
