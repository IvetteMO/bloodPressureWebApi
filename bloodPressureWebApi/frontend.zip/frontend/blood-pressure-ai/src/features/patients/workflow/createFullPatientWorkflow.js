import { createPatient } from "../../../api/patientApi";

import {
  createStudy,
  //previewImport,
  uploadStudyFile,
} from "../../../api/studyApi";

import {
  createRiskFactors,
} from "../../../api/riskFactorsApi";

export async function createFullPatientWorkflow({
  form,
  file,
}) {
  

  console.log("WORKFLOW START");

  

  if (!file) {
    throw new Error("Please upload Excel file");
  }

  // =========================
  // CREATE PATIENT
  // =========================

  const createdPatient = await createPatient({
    firstName: form.firstName,
    lastName: form.lastName,
    phoneNumber: form.phoneNumber,
    email: form.email,
    birthDate: form.birthDate,
    sex: form.sex === "Female" ? 1 : 0,
  });

  if (!createdPatient?.patientId) {
    throw new Error("Patient creation failed");
  }

  // 🚨 ELIMINADO preview (causaba problemas)

  // =========================
  // CREATE STUDY
  // =========================

  const studyResponse = await createStudy({
    patientId: Number(createdPatient.patientId),
    awakeTime: `${form.awakeTime}:00`,
    sleepTime: `${form.sleepTime}:00`,
    customSchedule: true,
  });

  // ✅ NORMALIZAR BIEN
  const createdStudy = {
    studyId: studyResponse.studyId
  };

  if (!createdStudy.studyId) {
    throw new Error("Study creation failed");
  }

  // =========================
  // RISK FACTORS
  // =========================

  const height = parseFloat(form.height);
  const weight = parseFloat(form.weight);

  if (!height || !weight) {
    throw new Error("Invalid height or weight");
  }

  const bmi = Number(
    (weight / (height * height)).toFixed(1)
  );

  await createRiskFactors({
    studyId: createdStudy.studyId,
    weight,
    height,
    bmi,
    smoking: form.smoking ? 1 : 0,
    diabetes: form.diabetes ? 1 : 0,
    hypertensionTreatment: form.hypertensionTreatment ? 1 : 0,
    parentalHypertension: Number(form.parentalHypertension),
  });

  console.log("UPLOADING STUDY:", createdStudy.studyId);

  // pequeña espera (muy útil por EF + transacción)
  await new Promise(r => setTimeout(r, 300));

  // =========================
  // UPLOAD
  // =========================

  await uploadStudyFile(
    createdStudy.studyId,
    file
  );

  return {
    patient: createdPatient,
    study: createdStudy,
  };
}