import {
  createStudy,
  previewImport,
  uploadStudyFile,
} from "../../../api/studyApi";

import {
  createRiskFactors,
} from "../../../api/riskFactorsApi";

export async function createStudyWorkflow({
  patient,
  file,
  form,
}) {
  if (!file) {
    throw new Error("Please upload Excel file");
  }

  // =========================
  // PREVIEW
  // =========================

  const preview = await previewImport(
    patient.patientId,
    file
  );

  if (
    preview.studyExists &&
    preview.sameHash
  ) {
    throw new Error(
      "This study already exists"
    );
  }

  // =========================
  // CREATE STUDY
  // =========================

  const createdStudy = await createStudy({
    patientId: Number(patient.patientId),

    awakeTime: `${form.awakeTime}:00`,

    sleepTime: `${form.sleepTime}:00`,

    customSchedule: true,
  });

  if (!createdStudy?.studyId) {
    throw new Error(
      "Study creation failed"
    );
  }

  // =========================
  // BMI
  // =========================

  const height = parseFloat(form.height);

  const weight = parseFloat(form.weight);

  const bmi = Number(
    (weight / (height * height)).toFixed(1)
  );

  // =========================
  // RISK FACTORS
  // =========================

  await createRiskFactors({
    studyId: createdStudy.studyId,

    weight,
    height,
    bmi,

    smoking: form.smoking ? 1 : 0,

    diabetes: form.diabetes ? 1 : 0,

    hypertensionTreatment:
      form.hypertensionTreatment
        ? 1
        : 0,

    parentalHypertension:
      Number(form.parentalHypertension),
  });

  // =========================
  // FILE
  // =========================

  await uploadStudyFile(
    createdStudy.studyId,
    file
  );

  return createdStudy;
}