// ============================================
// EditRiskFactorsModal.jsx
// ============================================

import { FilePenLine } from "lucide-react";

import { Modal, ModalHeader } from "@/ui/components/Modal";
import Page from "@/ui/components/Page";
import Button from "@/ui/components/Button";

import { FooterActions } from "@/ui/components/Form/Layout";

import RiskFactorsSection from "../sections/RiskFactorsSection";

import useRiskFactorsForm from "../hooks/useRiskFactorsForm";
import { useUpdateRiskFactors } from "../hooks/useUpdateRiskFactors";

function EditRiskFactorsModal({
  currentStudy,

  onClose,
}) {
  // ============================================
  // EXISTING DATA
  // ============================================

  const existingRisk = currentStudy?.riskFactors?.[0];

  // ============================================
  // FORM
  // ============================================

  const {
    form,

    updateField,
  } = useRiskFactorsForm(existingRisk);

  // ============================================
  // MUTATION
  // ============================================

  const updateRiskMutation = useUpdateRiskFactors();

  // ============================================
  // SAVE
  // ============================================

  const handleSave = async () => {
    try {
      await updateRiskMutation.mutateAsync({
        studyId: currentStudy.studyId,

        patientId: currentStudy.patientId,

        payload: {
          smoking: form.smoking,

          diabetes: form.diabetes,

          hypertensionTreatment: form.hypertensionTreatment,

          parentalHypertension: Number(form.parentalHypertension),
        },
      });

      onClose();
    } catch (err) {
      console.error(err);

      alert(err?.response?.data?.message ?? "Error updating risk factors");
    }
  };

  // ============================================
  // RENDER
  // ============================================

  return (
    <Modal open size="lg" onClose={onClose}>
      <Page>
        <ModalHeader
          eyebrow="CARDIOVASCULAR RISK"
          title="Risk Factors"
          subtitle="Update lifestyle and hereditary cardiovascular risk indicators."
          badges={[`Patient ID ${currentStudy?.patientId}`]}
          onClose={onClose}
        />

        <RiskFactorsSection value={form} onChange={updateField} />

        <FooterActions className="justify-between">
          <Button variant="primary" onClick={onClose}>
            Cancel
          </Button>

          <Button
            variant="primary"
            leftIcon={<FilePenLine size={18} />}
            disabled={updateRiskMutation.isPending}
            onClick={handleSave}
          >
            {updateRiskMutation.isPending ? "Updating..." : "Save Changes"}
          </Button>
        </FooterActions>
      </Page>
    </Modal>
  );
}

export default EditRiskFactorsModal;
