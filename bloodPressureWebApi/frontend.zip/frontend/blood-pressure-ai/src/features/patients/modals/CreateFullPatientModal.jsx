// ============================================
// CreateFullPatientModal.jsx
// ============================================

import { useRef, useState } from "react";

import { ArrowRight } from "lucide-react";

import { useCreateFullPatient } from "../hooks/useCreateFullPatient";
import useCreateFullPatientForm from "../hooks/useCreateFullPatientForm";
import usePatientBMI from "../hooks/usePatientBMI";
import usePatientFile from "../hooks/usePatientFile";

import { Modal, ModalHeader } from "@/ui/components/Modal";

import Page from "@/ui/components/Page";

import Button from "@/ui/components/Button";

import Grid from "@/ui/primitives/Grid";

import { FooterActions } from "@/ui/components/Form/Layout";

import PatientInformationSection from "../sections/PatientInformationSection";
import AnthropometricSection from "../sections/AnthropometricSection";
import RiskFactorsSection from "../sections/RiskFactorsSection";
import StudyConfigurationSection from "../sections/StudyConfigurationSection";
import ClinicalNotesSection from "../sections/ClinicalNotesSection";
import DatasetUploadSection from "../sections/DatasetUploadSection";

function CreateFullPatientModal({
  onClose,

  onSaved,
}) {
  // ============================================
  // FORM
  // ============================================
  const {
    form,

    updateField,
  } = useCreateFullPatientForm();

  // ============================================
  // BMI
  // ============================================
  const bmi = usePatientBMI(form);

  // ============================================
  // FILE
  // ============================================
  const {
    file,

    setFile,
  } = usePatientFile();

  // ============================================
  // MUTATION
  // ============================================
  const createMutation = useCreateFullPatient();

  // ============================================
  // STATE
  // ============================================
  const [loading, setLoading] = useState(false);

  const isSubmitting = useRef(false);

  // ============================================
  // CREATE
  // ============================================
  const handleCreate = async () => {
    if (isSubmitting.current) return;

    isSubmitting.current = true;

    setLoading(true);

    try {
      if (!file) {
        throw new Error("Please upload ABPM file");
      }

      await createMutation.mutateAsync({
        form,

        file,
      });

      await onSaved?.();

      onClose();
    } catch (err) {
      console.error(err);

      alert(
        err?.response?.data?.message ?? err.message ?? "Error creating patient",
      );
    } finally {
      setLoading(false);

      setTimeout(() => {
        isSubmitting.current = false;
      }, 800);
    }
  };

  // ============================================
  // RENDER
  // ============================================
  return (
    <Modal open size="xl" onClose={onClose}>
      <Page>
        <ModalHeader
          eyebrow="Clinical Workflow"
          title="New Patient & ABPM Study"
          subtitle="Create a complete clinical patient profile and ambulatory blood pressure monitoring study."
          badges={["Clinical Record", "ABPM", "Hybrid AI"]}
          onClose={onClose}
        />

        <PatientInformationSection value={form} onChange={updateField} />

        <Grid cols={2} gapX="xl" gapY="xl">
          <AnthropometricSection
            value={form}
            bmi={bmi}
            onChange={updateField}
          />

          <StudyConfigurationSection value={form} onChange={updateField} />

          <RiskFactorsSection value={form} onChange={updateField} />

          <ClinicalNotesSection value={form} onChange={updateField} />

          <div className="md:col-span-2">
            <DatasetUploadSection file={file} onChange={setFile} />
          </div>
        </Grid>
        <FooterActions className="justify-between">
          <Button variant="primary" onClick={onClose} disabled={loading}>
            Cancel
          </Button>

          <Button
            variant="primary"
            leftIcon={<ArrowRight size={18} />}
            onClick={handleCreate}
            disabled={loading || createMutation.isPending || !file}
          >
            {loading || createMutation.isPending
              ? "Creating Patient..."
              : "Create Patient"}
          </Button>
        </FooterActions>
      </Page>
    </Modal>
  );
}

export default CreateFullPatientModal;
