import { useState } from "react";
import { FilePenLine } from "lucide-react";

import { useUpdatePatient } from "../hooks/useUpdatePatient";
import usePatientForm from "../hooks/usePatientForm";

import EditRiskFactorsModal from "./EditRiskFactorsModal";

import { Modal, ModalHeader } from "@/ui/components/Modal";
import Page from "@/ui/components/Page";

import Button from "@/ui/components/Button";

import { FooterActions } from "@/ui/components/Form/Layout";

import PatientInformationSection from "../sections/PatientInformationSection";
import ClinicalNotesSection from "../sections/ClinicalNotesSection";
import RiskFactorsActionSection from "../sections/RiskFactorsActionSection";

function EditPatientModal({
  patient,

  currentStudy,

  onClose,
}) {
  const [showRiskModal, setShowRiskModal] = useState(false);

  const updatePatientMutation = useUpdatePatient();

  const {
    form,

    updateField,
  } = usePatientForm(patient);

  const handleSave = async () => {
    try {
      await updatePatientMutation.mutateAsync({
        patientId: patient.patientId,

        payload: {
          firstName: form.firstName,

          lastName: form.lastName,

          phoneNumber: form.phone,

          email: form.email,

          birthDate: form.birthDate,

          sex: form.gender === "Male" ? 0 : 1,

          clinicalNotes: form.clinicalNotes,
        },
      });

      onClose();
    } catch (err) {
      console.error(err);

      alert(err?.response?.data?.message ?? "Error updating patient");
    }
  };

  return (
    <>
      <Modal open size="lg" onClose={onClose}>
        <Page>
          <ModalHeader
            eyebrow="CLINICAL PROFILE"
            title="Edit Patient"
            subtitle="Update demographic and clinical patient data."
            badges={[`Patient ID ${patient?.patientId}`]}
            onClose={onClose}
          />

          <PatientInformationSection value={form} onChange={updateField} />

          <ClinicalNotesSection value={form} onChange={updateField} />

          <RiskFactorsActionSection onClick={() => setShowRiskModal(true)} />
          <FooterActions className="justify-between">
            <Button variant="primary" onClick={onClose}>
              Cancel
            </Button>

            <Button
              variant="primary"
              leftIcon={<FilePenLine size={18} />}
              disabled={updatePatientMutation.isPending}
              onClick={handleSave}
            >
              {updatePatientMutation.isPending
                ? "Updating..."
                : "Update Patient"}
            </Button>
          </FooterActions>
        </Page>
      </Modal>

      {showRiskModal && (
        <EditRiskFactorsModal
          currentStudy={currentStudy}
          onClose={() => setShowRiskModal(false)}
        />
      )}
    </>
  );
}

export default EditPatientModal;
