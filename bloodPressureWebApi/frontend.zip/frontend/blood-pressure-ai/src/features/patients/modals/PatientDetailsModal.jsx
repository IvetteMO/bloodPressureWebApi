// ============================================
// PatientDetailsModal.jsx
// ============================================
import { Activity, FolderOpen, BrainCircuit } from "lucide-react";
import { useState } from "react";

import { useNavigate } from "react-router-dom";

import { getFullStudy } from "../../../api/studyApi";

import useClinicalStore from "../../../store/useClinicalStore";

import { usePatientStudies } from "../hooks/usePatientStudies";

import { Modal, ModalHeader } from "@/ui/components/Modal";

import Page from "@/ui/components/Page";
import Button from "@/ui/components/Button";
import EmptyState from "@/ui/components/EmptyState";
import ClinicalTabGroup from "@/ui/components/ClinicalTabGroup";

import AIInsightCard from "@/ui/components/Clinical/Diagnosis/DiagnosisPanel/AIInsightCard";

import Stack from "@/ui/primitives/Stack";
import Grid from "@/ui/primitives/Grid";
import { FooterActions } from "@/ui/components/Form/Layout";

import StudySelectorSection from "../sections/StudySelectorSection";
import StudyStatusSection from "../sections/StudyStatusSection";
import PatientStudyMetricsSection from "../sections/PatientStudyMetricsSection";

// ============================================
// TABS
// ============================================

const STUDY_TABS = ["Overview", "Pressure", "Nocturnal", "Trends", "AI"];

// ============================================
// COMPONENT
// ============================================

function PatientDetailsModal({
  patient,

  onClose,
}) {
  // ============================================
  // NAVIGATION
  // ============================================

  const navigate = useNavigate();

  // ============================================
  // CLINICAL STORE
  // ============================================

  const setCurrentStudy = useClinicalStore((state) => state.setCurrentStudy);

  // ============================================
  // STUDIES
  // ============================================

  const {
    data: studies = [],

    isLoading,

    isError,
  } = usePatientStudies(patient?.patientId);

  // ============================================
  // LOCAL STATE
  // ============================================

  const [selectedStudyId, setSelectedStudyId] = useState(null);

  const [activeTab, setActiveTab] = useState(STUDY_TABS[0]);

  const [isOpening, setIsOpening] = useState(false);

  // ============================================
  // SELECTED STUDY
  // ============================================

  const selectedStudy =
    studies.find((study) => study.studyId === selectedStudyId) ??
    studies[0] ??
    null;

  // ============================================
  // DIAGNOSIS
  // IMPORTANTE:
  // Debe declararse DESPUÉS de selectedStudy
  // ============================================

  const diagnosis = selectedStudy?.diagnosis;

  // ============================================
  // SELECT STUDY
  // ============================================

  const handleSelectStudy = (study) => {
    setSelectedStudyId(study.studyId);

    setActiveTab(STUDY_TABS[0]);
  };

  // ============================================
  // OPEN FULL STUDY
  // ============================================

  const handleOpenStudy = async () => {
    if (!selectedStudy?.studyId || isOpening) {
      return;
    }

    try {
      setIsOpening(true);

      const fullStudy = await getFullStudy(selectedStudy.studyId);

      setCurrentStudy(fullStudy);

      onClose?.();

      navigate("/bp-analysis");
    } catch (err) {
      console.error("Error opening study:", err);

      alert(
        err?.response?.data?.message ?? "Unable to open the selected study.",
      );
    } finally {
      setIsOpening(false);
    }
  };

  // ============================================
  // RENDER
  // ============================================

  return (
    <Modal open size="xl" onClose={onClose}>
      <Page>
        {/* ===================================== */}
        {/* HEADER */}
        {/* ===================================== */}

        <ModalHeader
          eyebrow="Clinical Patient"
          title={`${patient?.firstName ?? ""} ${patient?.lastName ?? ""}`}
          subtitle="Review ambulatory blood pressure studies, cardiovascular metrics and intelligent clinical analysis."
          badges={[
            `Patient ID ${patient?.patientId ?? "--"}`,

            `${studies.length} ${studies.length === 1 ? "Study" : "Studies"}`,
          ]}
          onClose={onClose}
        />

        {/* ===================================== */}
        {/* LOADING */}
        {/* ===================================== */}

        {isLoading && (
          <EmptyState
            variant="compact"
            icon={Activity}
            eyebrow="Clinical Studies"
            title="Loading Studies"
            subtitle="Retrieving ambulatory blood pressure monitoring studies."
            buttonText="Close"
            action={onClose}
          />
        )}

        {/* ===================================== */}
        {/* ERROR */}
        {/* ===================================== */}

        {!isLoading && isError && (
          <EmptyState
            variant="compact"
            icon={Activity}
            eyebrow="Clinical Studies"
            title="Unable to Load Studies"
            subtitle="The patient's ambulatory monitoring studies could not be retrieved."
            buttonText="Close"
            action={onClose}
          />
        )}

        {/* ===================================== */}
        {/* EMPTY */}
        {/* ===================================== */}

        {!isLoading && !isError && studies.length === 0 && (
          <EmptyState
            variant="compact"
            icon={Activity}
            eyebrow="Clinical Studies"
            title="No ABPM Studies"
            subtitle="This patient does not currently have ambulatory blood pressure monitoring studies."
            buttonText="Close"
            action={onClose}
          />
        )}

        {/* ===================================== */}
        {/* STUDIES */}
        {/* ===================================== */}

        {!isLoading && !isError && selectedStudy && (
          <Stack gap="xl">
            {/* ================================= */}
            {/* STUDY SELECTOR */}
            {/* ================================= */}

            <StudySelectorSection
              studies={studies}
              selectedStudy={selectedStudy}
              onSelect={handleSelectStudy}
            />

            {/* ================================= */}
            {/* STUDY STATUS */}
            {/* ================================= */}

            <StudyStatusSection study={selectedStudy} />

            {/* ================================= */}
            {/* CLINICAL TABS */}
            {/* ================================= */}

            <ClinicalTabGroup
              tabs={STUDY_TABS}
              activeTab={activeTab}
              onChange={setActiveTab}
            />

            {/* ================================= */}
            {/* CONTENT */}
            {/* ================================= */}

            <Grid cols={2} gap="lg">
              {/* ===================================== */}
              {/* LEFT */}
              {/* ===================================== */}

              <div className="h-full min-w-0">
                <PatientStudyMetricsSection
                  study={selectedStudy}
                  activeTab={activeTab}
                  className="h-full"
                />
              </div>

              {/* ===================================== */}
              {/* RIGHT */}
              {/* ===================================== */}

              <Stack gap="md" className="min-w-0">
                <AIInsightCard
                  variant="compact"
                  title="AI Cardiovascular Risk"
                  interpretation={{
                    summary: diagnosis?.finalRiskLevel ?? "Pending",
                    description:
                      "Hybrid neuro-fuzzy cardiovascular intelligent assessment.",
                  }}
                  palette={{
                    icon: BrainCircuit,
                    accent: "text-pink-400",
                    text: "text-pink-400",
                  }}
                />

                <AIInsightCard
                  variant="compact"
                  title="Nocturnal Profile"
                  interpretation={{
                    summary: diagnosis?.nocturnalProfile ?? "Pending",
                    description:
                      "Circadian cardiovascular nocturnal behavior classification.",
                  }}
                  palette={{
                    icon: BrainCircuit,
                    accent: "text-cyan-300",
                    text: "text-cyan-300",
                  }}
                />
              </Stack>
            </Grid>
            {/* ================================= */}
            {/* ACTIONS */}
            {/* ================================= */}

            <FooterActions className="justify-between">
              <Button variant="primary" onClick={onClose} disabled={isOpening}>
                Close
              </Button>

              <Button
                variant="primary"
                leftIcon={<FolderOpen size={18} />}
                onClick={handleOpenStudy}
                disabled={isOpening}
              >
                {isOpening ? "Opening..." : "Open Analysis"}
              </Button>
            </FooterActions>
          </Stack>
        )}
      </Page>
    </Modal>
  );
}

export default PatientDetailsModal;
