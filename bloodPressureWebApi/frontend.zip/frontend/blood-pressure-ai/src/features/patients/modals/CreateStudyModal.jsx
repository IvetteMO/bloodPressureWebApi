// ============================================
// CreateStudyModal.jsx
// ============================================

import { FilePen } from "lucide-react";

import { useCreateStudy } from "../hooks/useCreateStudy";
import useCreateStudyForm from "../hooks/useCreateStudyForm";
import useStudyFile from "../hooks/useStudyFile";

import { Modal, ModalHeader } from "@/ui/components/Modal";
import Page from "@/ui/components/Page";
import Button from "@/ui/components/Button";

import Grid from "@/ui/primitives/Grid";
import { FooterActions } from "@/ui/components/Form/Layout";

import AnthropometricSection from "../sections/AnthropometricSection";
import RiskFactorsSection from "../sections/RiskFactorsSection";
import StudyConfigurationSection from "../sections/StudyConfigurationSection";
import DatasetUploadSection from "../sections/DatasetUploadSection";
import PatientHero from "../sections/PatientHero";

function CreateStudyModal({
  patient,

  onClose,

  onSaved,
}) {
  // ============================================
  // FORM
  // ============================================

  const {
    form,

    updateField,
  } = useCreateStudyForm();

  // ============================================
  // FILE
  // ============================================

  const {
    file,

    setFile,
  } = useStudyFile();

  // ============================================
  // MUTATION
  // ============================================

  const createStudyMutation = useCreateStudy();

  // ============================================
  // ACTIONS
  // ============================================

  const handleCreateStudy = async () => {
    try {
      await createStudyMutation.mutateAsync({
        patient,

        file,

        form,
      });

      await onSaved?.();

      onClose();
    } catch (err) {
      console.error(err);

      alert(err?.response?.data?.message ?? "Failed to create study");
    }
  };

  // ============================================
  // RENDER
  // ============================================

  return (
    <Modal open size="lg" onClose={onClose}>
      <Page>
        <ModalHeader
          eyebrow="Clinical Workflow"
          title="New ABPM Study"
          subtitle="Intelligent ambulatory blood pressure monitoring workflow."
          badges={[`Patient ${patient?.patientId}`, "ABPM", "Hybrid AI"]}
          onClose={onClose}
        />

        <PatientHero patient={patient} />

        <Grid cols={2} gapX="2xl" gapY="xl">
          <AnthropometricSection value={form} onChange={updateField} />

          <StudyConfigurationSection value={form} onChange={updateField} />

          <RiskFactorsSection value={form} onChange={updateField} />

          <DatasetUploadSection file={file} onChange={setFile} />
        </Grid>
        <FooterActions className="justify-between">
          <Button variant="primary" onClick={onClose}>
            Cancel
          </Button>

          <Button
            variant="primary"
            leftIcon={<FilePen size={18} />}
            onClick={handleCreateStudy}
            disabled={createStudyMutation.isPending || !file}
          >
            {createStudyMutation.isPending ? "Creating..." : "Create Study"}
          </Button>
        </FooterActions>
      </Page>
    </Modal>
  );
}

export default CreateStudyModal;
