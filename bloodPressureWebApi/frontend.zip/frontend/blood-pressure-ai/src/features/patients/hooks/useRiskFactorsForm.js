import { useState } from "react";

function createForm(existingRisk) {
  return {
    smoking: existingRisk?.smoking ?? false,

    diabetes: existingRisk?.diabetes ?? false,

    hypertensionTreatment: existingRisk?.hypertensionTreatment ?? false,

    parentalHypertension: existingRisk?.parentalHypertension ?? 0,
  };
}

export default function useRiskFactorsForm(existingRisk) {
  const [form, setForm] = useState(() => createForm(existingRisk));

  const updateField = (field, value) => {
    setForm((prev) => ({
      ...prev,

      [field]: value,
    }));
  };

  return {
    form,

    updateField,

    setForm,
  };
}
