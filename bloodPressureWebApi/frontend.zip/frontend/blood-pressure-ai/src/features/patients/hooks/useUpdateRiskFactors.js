import {

  useMutation,
  useQueryClient,

} from "@tanstack/react-query";

import {

  updateRiskFactors,

} from "../../../api/riskFactorsApi";

export function useUpdateRiskFactors() {

  const queryClient =
    useQueryClient();

  return useMutation({

    mutationFn: ({

      studyId,
      payload,

    }) =>

      updateRiskFactors(

        studyId,
        payload
      ),

    onSuccess: (_, variables) => {

      // =====================
      // REFRESH CURRENT
      // =====================

      queryClient.invalidateQueries({

        queryKey: [

          "patient",

          variables.patientId,
        ],
      });

      // =====================
      // REFRESH TABLE
      // =====================

      queryClient.invalidateQueries({

        queryKey: ["patients"],
      });
    },
  });
}