// ============================================
// usePatientStudies.js
// ============================================

import {
  useQuery
} from "@tanstack/react-query";

import {
  getStudiesByPatient
} from "../../../api/studyApi";

export function usePatientStudies(
  patientId
) {

  return useQuery({

    queryKey: [
      "patient-studies",
      patientId
    ],

    queryFn: () =>
      getStudiesByPatient(
        patientId
      ),

    enabled: !!patientId
  });
}