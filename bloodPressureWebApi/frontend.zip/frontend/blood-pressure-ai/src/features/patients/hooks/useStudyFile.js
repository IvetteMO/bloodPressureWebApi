import { useState } from "react";

export default function useStudyFile() {
  const [file, setFile] = useState(null);

  const clearFile = () => {
    setFile(null);
  };

  return {
    file,
    setFile,
    clearFile,
  };
}
