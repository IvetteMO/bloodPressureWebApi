import {
  useMutation,
  useQueryClient
} from "@tanstack/react-query";

import {
  createFullPatientWorkflow
} from "../workflow/createFullPatientWorkflow";

export function useCreateFullPatient() {

  const queryClient = useQueryClient();

  return useMutation({

    mutationFn: createFullPatientWorkflow,

    
    retry: false,              // 🔥 IMPORTANTE
    retryOnMount: false,       // 🔥 IMPORTANTE


    onSuccess: () => {

      queryClient.invalidateQueries({
        queryKey: ["patients"],
      });

    },

  });
}