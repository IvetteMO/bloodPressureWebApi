import { useState } from "react";

function createForm(patient) {
  return {
    firstName: patient?.firstName ?? "",

    lastName: patient?.lastName ?? "",

    birthDate: patient?.birthDate ?? "",

    gender: patient?.gender ?? "",

    phone: patient?.phone ?? "",

    email: patient?.email ?? "",

    clinicalNotes: patient?.clinicalNotes ?? "",
  };
}

export default function usePatientForm(patient) {
  const [form, setForm] = useState(() => createForm(patient));

  const updateField = (field, value) => {
    setForm((prev) => ({
      ...prev,

      [field]: value,
    }));
  };

  const reset = () => {
    setForm(createForm(patient));
  };

  return {
    form,

    updateField,

    reset,

    setForm,
  };
}
