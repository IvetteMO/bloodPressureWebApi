import { useState } from "react";

export default function usePatientFile() {
  const [file, setFile] = useState(null);

  return {
    file,
    setFile,
  };
}
