import { useState } from "react";

export default function useCreateFullPatientForm() {
  const [form, setForm] = useState({
    // =====================================
    // PATIENT
    // =====================================

    firstName: "",

    lastName: "",

    birthDate: "",

    sex: "Male",

    phoneNumber: "",

    email: "",

    // =====================================
    // BODY
    // =====================================

    height: "",

    weight: "",

    // =====================================
    // RISK FACTORS
    // =====================================

    smoking: false,

    diabetes: false,

    hypertensionTreatment: false,

    parentalHypertension: 0,

    // =====================================
    // STUDY
    // =====================================

    awakeTime: "06:00",

    sleepTime: "23:00",

    // =====================================
    // NOTES
    // =====================================

    clinicalNotes: "",
  });

  const updateField = (field, value) => {
    setForm((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  return {
    form,
    setForm,
    updateField,
  };
}
