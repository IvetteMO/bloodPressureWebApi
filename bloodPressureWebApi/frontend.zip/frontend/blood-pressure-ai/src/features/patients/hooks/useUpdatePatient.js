import {

  useMutation,
  useQueryClient,

} from "@tanstack/react-query";

import {

  updatePatient,

} from "../../../api/patientApi";

export function useUpdatePatient() {

  const queryClient =
    useQueryClient();

  return useMutation({

    mutationFn: ({

      patientId,
      payload,

    }) =>

      updatePatient(

        patientId,
        payload
      ),

    onSuccess: (_, variables) => {

      // =====================
      // REFRESH PATIENTS
      // =====================

      queryClient.invalidateQueries({

        queryKey: ["patients"],
      });

      // =====================
      // REFRESH CURRENT
      // =====================

      queryClient.invalidateQueries({

        queryKey: [

          "patient",

          variables.patientId,
        ],
      });
    },
  });
}