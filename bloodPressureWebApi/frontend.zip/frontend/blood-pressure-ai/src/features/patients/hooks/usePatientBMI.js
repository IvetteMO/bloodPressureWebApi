import { useMemo } from "react";

import buildBMI from "../builders/buildBMI";

export default function usePatientBMI(form) {
  return useMemo(
    () => buildBMI(form.height, form.weight),
    [form.height, form.weight],
  );
}
