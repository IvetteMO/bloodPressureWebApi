import { useMutation } from "@tanstack/react-query";

import { useQueryClient } from "@tanstack/react-query";

import {
  createStudyWorkflow,
} from "../workflow/createStudyWorkflow";

export function useCreateStudy() {

  const queryClient =
    useQueryClient();

  return useMutation({

    mutationFn:
      createStudyWorkflow,

    onSuccess: (_, variables) => {

      // =========================
      // REFRESH PATIENTS
      // =========================

      queryClient.invalidateQueries({
        queryKey: ["patients"],
      });

      // =========================
      // REFRESH CURRENT PATIENT
      // =========================

      if (variables?.patient?.patientId) {

        queryClient.invalidateQueries({

          queryKey: [

            "patient",

            variables.patient.patientId

          ],
        });
      }

      // =========================
      // REFRESH STUDIES
      // =========================

      queryClient.invalidateQueries({

        queryKey: ["studies"],
      });
    },
  });
}