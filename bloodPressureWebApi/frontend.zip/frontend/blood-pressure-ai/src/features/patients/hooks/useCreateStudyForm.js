import { useState } from "react";

function createForm() {
  return {
    // Anthropometric
    height: "",
    weight: "",

    // Cardiovascular Risk
    smoking: false,
    diabetes: false,
    hypertensionTreatment: false,
    parentalHypertension: 0,

    // Study Configuration
    awakeTime: "06:00",
    sleepTime: "23:00",
  };
}

export default function useCreateStudyForm() {
  const [form, setForm] = useState(() => createForm());

  const updateField = (field, value) => {
    setForm((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const reset = () => {
    setForm(createForm());
  };

  return {
    form,
    updateField,
    reset,
    setForm,
  };
}
