import { useQuery } from "@tanstack/react-query";

import {
  getPatientById,
} from "../../../api/patientApi";

import {
  getStudiesByPatient,
} from "../../../api/studyApi";

export function usePatient(patientId) {
  return useQuery({
    queryKey: ["patient", patientId],

    enabled: !!patientId,

    queryFn: async () => {
      const patient = await getPatientById(patientId);

      const studies = await getStudiesByPatient(patientId);

      return {
        ...patient,
        studies,
      };
    },
  });
}