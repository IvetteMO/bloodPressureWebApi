import {

  useMutation,
  useQueryClient,

} from "@tanstack/react-query";

import {

  deletePatient,

} from "../../../api/patientApi";

export function useDeletePatient() {

  const queryClient =
    useQueryClient();

  return useMutation({

    mutationFn:
      deletePatient,

    onSuccess: () => {

      queryClient.invalidateQueries({

        queryKey: ["patients"],
      });
    },
  });
}