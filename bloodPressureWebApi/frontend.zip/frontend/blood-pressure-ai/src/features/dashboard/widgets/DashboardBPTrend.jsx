import { useMemo } from "react";

import AreaTrendChart from "@/ui/components/DataVisualization/AreaTrendChart";

import { useDashboardTrends } from "../hooks/useDashboardTrends";

export default function DashboardBPTrend() {
  const { data, isLoading } = useDashboardTrends(1);

  const chartData = useMemo(() => {
    return (data ?? []).map((item) => ({
      time: item.time,

      systolic: item.systolic,

      diastolic: item.diastolic,
    }));
  }, [data]);

  if (isLoading) {
    return (
      <AreaTrendChart
        variant="default"
        eyebrow="Circadian Pressure Dynamics"
        title="Blood Pressure Trends"
      />
    );
  }

  return (
    <AreaTrendChart
      chartId="dashboard-bp"
      eyebrow="Circadian Pressure Dynamics"
      title="Blood Pressure Trends"
      timeField="time"
      data={chartData}
      legend={[
        {
          dataKey: "systolic",
          label: "Systolic (mmHg)",
          color: "#A855F7",
        },

        {
          dataKey: "diastolic",
          label: "Diastolic (mmHg)",
          color: "#EC4899",
        },
      ]}
      series={[
        {
          dataKey: "systolic",
          color: "#A855F7",
          opacity: 0.3,
        },

        {
          dataKey: "diastolic",
          color: "#EC4899",
          opacity: 0.22,
        },
      ]}
    />
  );
}
