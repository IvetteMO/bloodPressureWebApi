import { useDashboardSnapshot } from "../hooks/useDashboardSnapshot";

import Panel from "@/ui/components/Panel";
import Metric from "@/ui/components/Metric";

import Stack from "@/ui/primitives/Stack";
import { typography } from "@/ui/foundations";

export default function ClinicalSnapshot() {
  const { data, isLoading } = useDashboardSnapshot();

  if (isLoading) {
    return (
      <Panel>
        <p className={typography.insightTitle}>Loading snapshot...</p>
      </Panel>
    );
  }

  return (
    <Panel variant="interactive">
      <Stack
        gap="md"
        className="justify-between items-center h-full text-center"
      >
        <p className={typography.eyebrow}>Clinical Snapshot</p>
        <Stack gap="sm">
          <Metric
            variant="snapshot"
            label="High Risk Patients"
            value={data?.highRiskPatients}
          />

          <Metric
            variant="snapshot"
            label="Non-Dipper Profiles"
            value={data?.nonDipperRate}
            suffix="%"
          />

          <Metric
            variant="snapshot"
            label="Critical Studies Today"
            value={data?.criticalStudiesToday}
          />
        </Stack>
      </Stack>
    </Panel>
  );
}
