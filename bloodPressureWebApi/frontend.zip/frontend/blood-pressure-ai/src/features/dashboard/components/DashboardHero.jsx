import Hero from "@/ui/components/Hero";
import ClinicalSnapshot from "../components/ClinicalSnapshots";

export default function DashboardHero() {
  return (
    <Hero
      variant="hero"
      eyebrow="Clinical Intelligence Overview"
      title="Cardiovascular Intelligence System"
      subtitle="Hybrid explainable AI platform for ambulatory cardiovascular interpretation and nocturnal physiological analysis."
      aside={<ClinicalSnapshot />} // 👈 aquí va el snapshot
    />
  );
}
