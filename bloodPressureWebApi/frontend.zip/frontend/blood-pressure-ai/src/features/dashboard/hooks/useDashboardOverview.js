import {
  useQuery
} from "@tanstack/react-query";

import {
  getDashboardOverview
} from "../../../api/dashboardApi";

export function useDashboardOverview() {

  return useQuery({

    queryKey: [
      "dashboard-overview"
    ],

    queryFn:
      getDashboardOverview
  });
}