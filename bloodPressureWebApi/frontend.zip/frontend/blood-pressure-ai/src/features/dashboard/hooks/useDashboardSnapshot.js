import {
  useQuery
} from "@tanstack/react-query";

import {
  getDashboardSnapshot
}
from "../../../api/dashboardApi";

export function useDashboardSnapshot() {

  return useQuery({

    queryKey: [
      "dashboard-snapshot"
    ],

    queryFn:
      getDashboardSnapshot
  });
}