import {
  useQuery
} from "@tanstack/react-query";

import {
  getDashboardInsights
} from "../../../api/dashboardApi";

export function useDashboardInsights(
  studyId
) {

  return useQuery({

    queryKey: [
      "dashboard-insights",
      studyId
    ],

    queryFn: () =>

      getDashboardInsights(
        studyId
      ),

    enabled:
      !!studyId
  });
}