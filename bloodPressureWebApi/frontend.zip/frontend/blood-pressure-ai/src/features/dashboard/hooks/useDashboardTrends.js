import {
  useQuery
} from "@tanstack/react-query";

import {
  getDashboardTrends
}
from "../../../api/dashboardApi";

export function useDashboardTrends(
  studyId
) {

  return useQuery({

    queryKey: [
      "dashboard-trends",
      studyId
    ],

    queryFn: () =>

      getDashboardTrends(
        studyId
      ),

    enabled:
      !!studyId
  });
}