// ============================================
// DashboardPage.jsx
// ============================================

import Page from "@/ui/components/Page";

import DashboardHero from "../components/DashboardHero";
import DashboardOverviewSection from "../sections/DashboardOverviewSection";

export default function DashboardPage() {
  return (
    <Page variant="dashboard">
      <DashboardHero />

      <DashboardOverviewSection />
    </Page>
  );
}
