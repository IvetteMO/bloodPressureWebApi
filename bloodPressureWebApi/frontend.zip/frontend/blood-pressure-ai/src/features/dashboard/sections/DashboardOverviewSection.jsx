import { motion } from "framer-motion";
import Split from "@/ui/components/Split";

import DashboardMetrics from "../../../ui/features/dashboard/components/DashboardMetric";
import DashboardAlerts from "../../../ui/features/dashboard/components/DashboardAlerts";
import DashboardInsightPanel from "../../../ui/features/dashboard/components/DashboardInsightsPanel";
import DashboardBPTrend from "../widgets/DashboardBPTrend";

import { motionPresets } from "@/ui/animations";

export default function DashboardOverviewSection() {
  return (
    <motion.div
      className="flex flex-col gap-8"
      initial="hidden"
      animate="visible"
      variants={{
        hidden: {},

        visible: {
          transition: {
            staggerChildren: 0.12,

            delayChildren: 0.05,
          },
        },
      }}
    >
      <motion.div {...motionPresets.fadeUp}>
        <Split
          ratio="8-4"
          left={<DashboardBPTrend />}
          right={<DashboardInsightPanel />}
        />
      </motion.div>

      <motion.div {...motionPresets.fadeUp}>
        <DashboardMetrics />
      </motion.div>

      <motion.div {...motionPresets.fadeUp}>
        <DashboardAlerts />
      </motion.div>
    </motion.div>
  );
}
