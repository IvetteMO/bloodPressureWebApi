import PredictionCard from "@/ui/components/Clinical/Diagnosis/DiagnosisPanel/PredictionCard";

import getHypertensionTheme from "@/ui/components/Clinical/Diagnosis/themes/hypertensionTheme";

export default function HypertensionResultSection({ diagnosis }) {
  const risk = diagnosis?.hypertension4YearRisk ?? 0;

  const theme = getHypertensionTheme(risk);

  return (
    <PredictionCard
      palette={theme}
      title="Predicted Hypertension Risk"
      value={risk.toFixed(1)}
      suffix="%"
      description="Estimated probability of developing hypertension within four years based on ambulatory blood pressure, circadian profile and cardiovascular risk factors."
      rightTitle="Risk Status"
      rightValue={theme.category}
    />
  );
}
