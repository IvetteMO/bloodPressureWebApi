import { useEffect, useState } from "react";
import useClinicalStore from "../../../../store/useClinicalStore";
import { getFullStudy } from "../../../../api/studyApi";

// ============================================
// GLOBAL COMPONENTS
// ============================================
import ExcelAside from "@/ui/components/Aside";
import { Page, Hero, Loader, EmptyState } from "@/ui";

// ============================================
// CLINICAL UI
// ============================================
import AIInsightCard from "@/ui/components/Clinical/Diagnosis/DiagnosisPanel/AIInsightCard";
import predictionPalette from "@/ui/components/Clinical/Diagnosis/palette/predictionPalette";
import { getHypertensionInterpretation } from "@/ui/components/Clinical/Diagnosis/interpretation";

// ============================================
// SECTIONS
// ============================================
import PhysiologicalFeaturesSection from "../../components/sections/PhysiologicalFeaturesSection";
import ClinicalRiskFactorsSection from "../../components/sections/ClinicalRiskFactorsSection";
import HypertensionResultSection from "../sections/HypertensionResultSection";

// ============================================
// COMPONENT
// ============================================

function HypertensionRiskPage() {
  const { currentStudy } = useClinicalStore();

  const [features, setFeatures] = useState(null);
  const [diagnosis, setDiagnosis] = useState(null);
  const [riskFactors, setRiskFactors] = useState([]);
  const [loading, setLoading] = useState(false);

  // ============================================
  // LOAD DATA
  // ============================================

  useEffect(() => {
    async function loadData() {
      if (!currentStudy) return;

      try {
        setLoading(true);

        const fullStudy = await getFullStudy(currentStudy.studyId);

        setFeatures(fullStudy.features);
        setDiagnosis(fullStudy.diagnosis);
        setRiskFactors(fullStudy.riskFactors || []);
      } catch (error) {
        console.error(error);
      } finally {
        setLoading(false);
      }
    }

    loadData();
  }, [currentStudy]);

  // ============================================
  // EMPTY
  // ============================================

  if (!currentStudy) {
    return (
      <Page>
        <EmptyState
          title="No Hypertension Study"
          subtitle="Select a cardiovascular study to begin predictive hypertension analysis."
          buttonText="Select Study"
          navigateTo="/patients"
        />
      </Page>
    );
  }

  if (loading) {
    return <Loader variant="clinical" />;
  }

  // ============================================
  // PATIENT
  // ============================================

  const patientName = `
    ${currentStudy?.patient?.firstName ?? ""}
    ${currentStudy?.patient?.lastName ?? ""}
  `.trim();

  // ============================================
  // INTERPRETATION
  // ============================================

  const risk = diagnosis?.hypertension4YearRisk ?? 0;

  const interpretation = getHypertensionInterpretation(risk);

  const palette = predictionPalette.hypertension;

  // ============================================
  // UI
  // ============================================

  return (
    <Page>
      {/* HERO */}

      <Hero
        variant="compact"
        eyebrow="Hypertension Prediction"
        title={patientName}
        subtitle="AI-assisted predictive cardiovascular analysis for hypertension development estimation."
        aside={<ExcelAside currentStudy={currentStudy} />}
      />

      {/* FEATURES */}

      <div className="grid grid-cols-1 gap-8 xl:grid-cols-2">
        <PhysiologicalFeaturesSection
          model="hypertension"
          features={features}
        />

        <ClinicalRiskFactorsSection
          model="hypertension"
          riskFactors={riskFactors}
          patient={currentStudy?.patient}
        />
      </div>

      {/* AI INTERPRETATION */}

      <AIInsightCard palette={palette} interpretation={interpretation} />

      {/* RESULT */}

      <HypertensionResultSection diagnosis={diagnosis} />
    </Page>
  );
}

export default HypertensionRiskPage;
