export function getLoadDiagnosis(
  diagnosis
) {

  const value =
    diagnosis?.fuzzyLoadC ?? 0;

  if (value <= 20)
    return "Normal";

  if (
    value >= 20.1 &&
    value <= 40
  )
    return "Intermediate";

  return "High Load";
}

export function getLoadDiagnosisColor(
  diagnosis
) {

  const value =
    diagnosis?.fuzzyLoadC ?? 0;

  if (value <= 20)
    return "text-green-400";

  if (
    value >= 20.1 &&
    value <= 40
  )
    return "text-yellow-400";

  return "text-red-400";
}