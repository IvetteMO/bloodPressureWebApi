export function getHypertensionRiskTheme(risk = 0) {
  // ============================================
  // MINIMAL
  // ============================================

  if (risk < 15) {
    return {
      category: "Minimal Risk",

      gradient: `
          from-emerald-500/20
          via-emerald-500/5
        `,

      border: `
          border-emerald-500/20
        `,

      text: `
          text-emerald-300
        `,

      glow: `
          bg-emerald-500/20
        `,
    };
  }

  // ============================================
  // CONTROLLED
  // ============================================

  if (risk < 30) {
    return {
      category: "Controlled Risk",

      gradient: `
          from-orange-500/20
          via-amber-500/5
        `,

      border: `
          border-orange-500/20
        `,

      text: `
          text-orange-300
        `,

      glow: `
          bg-orange-500/20
        `,
    };
  }

  // ============================================
  // ELEVATED
  // ============================================

  return {
    category: "Elevated Risk",

    gradient: `
        from-rose-500/20
        via-red-500/5
      `,

    border: `
        border-rose-500/20
      `,

    text: `
        text-rose-300
      `,

    glow: `
        bg-rose-500/20
      `,
  };
}
