
export function getHypertensionInterpretation(

  risk = 0

) {

  // ============================================
  // LOW
  // ============================================

  if (risk < 15) {

    return `
      Current physiological and
      clinical indicators suggest
      a low probability of
      hypertension development
      in the medium term.
    `;
  }

  // ============================================
  // MODERATE
  // ============================================

  if (risk < 30) {

    return `
      The patient presents
      moderate indicators associated
      with future hypertension
      development. Continuous
      monitoring is recommended.
    `;
  }

  // ============================================
  // HIGH
  // ============================================

  return `
    The patient presents elevated
    cardiovascular indicators
    associated with future
    hypertension development
    and requires clinical
    follow-up.
  `;
}
