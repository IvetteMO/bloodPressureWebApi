export function getCardiovascularInterpretation(
  risk
) {

  if (risk < 10) {

    return `
      Cardiovascular indicators suggest
      low probability of future
      cardiovascular events with
      preserved vascular stability
      and favorable hemodynamic
      behavior.
    `;
  }

  if (risk < 25) {

    return `
      Cardiovascular dynamics indicate
      moderate vascular stress and
      potential early cardiovascular
      alterations requiring
      periodic monitoring.
    `;
  }

  return `
    Cardiovascular behavior suggests
    elevated vascular compromise
    associated with abnormal pressure
    regulation and increased long-term
    cardiovascular risk.
  `;
}