// ============================================
// FILE:
// bpDiagnosisThemeByLabels.js
// ============================================

import {
  ShieldCheck,
  ShieldAlert,
  ShieldX,
  Activity,
  TriangleAlert,
  HeartPulse,
} from "lucide-react";

export function getBPDiagnosisThemeByLabel(label) {
  switch (label) {
    // ============================================
    // HYPOTENSION
    // ============================================

    case "Hypotension":
      return {
        result: "Hypotension",

        icon: Activity,

        background: `
            bg-gradient-to-br
            from-emerald-500/20
            via-emerald-500/5
            to-transparent
          `,

        border: `
            border-emerald-400/20
          `,

        text: `
            text-emerald-300
          `,

        glow: `
            shadow-[0_0_80px_rgba(16,185,129,0.18)]
          `,

        clinicalDiagnosis:
          "Low blood pressure levels observed\nwhich may result in dizziness or reduced perfusion.",

        riskLabel: "Low Risk",
      };

    // ============================================
    // OPTIMAL
    // ============================================

    case "Optimal":
      return {
        result: "Optimal",

        icon: ShieldCheck,

        background: `
            bg-gradient-to-br
from-emerald-400/20
via-emerald-500/8
to-transparent
          `,

        border: `
            border-green-400/20
          `,

        text: `
            text-green-300
          `,

        glow: `
            shadow-[0_0_80px_rgba(34,197,94,0.18)]
          `,

        clinicalDiagnosis:
          "Normal ambulatory blood pressure profile \nwith no evidence of hypertension.",

        riskLabel: "Low Risk",
      };

    // ============================================
    // HIGH NORMAL
    // ============================================

    case "High Normal":
      return {
        result: "High Normal",

        icon: HeartPulse,

        background: `
            bg-gradient-to-br
            from-amber-500/20
            via-orange-500/5
            to-transparent
          `,

        border: `
            border-orange-400/20
          `,

        text: `
            text-orange-300
          `,

        glow: `
            shadow-[0_0_80px_rgba(251,146,60,0.18)]
          `,
        clinicalDiagnosis:
          "Blood pressure remains within acceptable \nlimits but approaches hypertensive thresholds.",

        riskLabel: "Monitor",
      };

    // ============================================
    // GRADE 1
    // ============================================

    case "Grade 1 Hypertension":
      return {
        result: "Grade 1 Hypertension",

        icon: ShieldAlert,

        background: `
            bg-gradient-to-br
            from-orange-600/20
            via-red-500/5
            to-transparent
          `,

        border: `
            border-orange-500/20
          `,

        text: `
            text-orange-400
          `,

        glow: `
            shadow-[0_0_80px_rgba(249,115,22,0.18)]
          `,

        clinicalDiagnosis:
          "Mild elevation in blood pressure requiring \nlifestyle modification and clinical follow-up.",

        riskLabel: "Moderate Risk",
      };

    // ============================================
    // GRADE 2
    // ============================================

    case "Grade 2 Hypertension":
      return {
        result: "Grade 2 Hypertension",

        icon: TriangleAlert,

        background: `
            bg-gradient-to-br
            from-red-600/20
            via-red-500/5
            to-transparent
          `,

        border: `
            border-red-500/20
          `,

        text: `
            text-red-400
          `,

        glow: `
            shadow-[0_0_80px_rgba(239,68,68,0.18)]
          `,

        clinicalDiagnosis:
          "Significant blood pressure elevation associated \nwith increased cardiovascular risk.",

        riskLabel: "High Risk",
      };

    // ============================================
    // DEFAULT
    // ============================================

    default:
      return {
        result: "Grade 3 Hypertension",

        icon: ShieldX,

        background: `
            bg-gradient-to-br
            from-rose-900/40
            via-red-900/20
            to-transparent
          `,

        border: `
            border-rose-700/30
          `,

        text: `
            text-rose-500
          `,

        glow: `
            shadow-[0_0_90px_rgba(244,63,94,0.22)]
          `,
        clinicalDiagnosis:
          "Severe hypertension requiring immediate \nmedical assessment and management.",

        riskLabel: "Critical",
      };
  }
}
