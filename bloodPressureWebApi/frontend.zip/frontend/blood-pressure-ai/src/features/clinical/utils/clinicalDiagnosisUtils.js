export function getDiagnosisTheme(
  diagnosis,
  value
) {

  // ============================================
  // HYPOTENSION
  // ============================================

  if (value < 18.25) {

    return {

      text:
        "Hypotension",

      gradient:
        `
          from-emerald-500/20
          to-lime-500/10
        `,

      border:
        `
          border-emerald-400/20
        `,

      textColor:
        `
          text-emerald-300
        `
    };
  }

  // ============================================
  // OPTIMAL / NORMAL
  // ============================================

  if (
    value >= 17 &&
    value <= 49
  ) {

    return {

      text:
        diagnosis,

      gradient:
        `
          from-emerald-500/20
          to-cyan-500/10
        `,

      border:
        `
          border-emerald-400/20
        `,

      textColor:
        `
          text-emerald-300
        `
    };
  }

  // ============================================
  // HIGH NORMAL
  // ============================================

  if (
    value >= 48 &&
    value <= 56
  ) {

    return {

      text:
        "High Normal",

      gradient:
        `
          from-amber-500/20
          to-orange-500/10
        `,

      border:
        `
          border-amber-400/20
        `,

      textColor:
        `
          text-amber-300
        `
    };
  }

  // ============================================
  // GRADE 1
  // ============================================

  if (
    value >= 54 &&
    value <= 68
  ) {

    return {

      text:
        diagnosis,

      gradient:
        `
          from-orange-500/20
          to-rose-500/10
        `,

      border:
        `
          border-orange-400/20
        `,

      textColor:
        `
          text-orange-300
        `
    };
  }

  // ============================================
  // GRADE 2
  // ============================================

  if (
    value >= 67 &&
    value <= 79
  ) {

    return {

      text:
        diagnosis,

      gradient:
        `
          from-rose-500/20
          to-red-500/10
        `,

      border:
        `
          border-rose-400/20
        `,

      textColor:
        `
          text-rose-300
        `
    };
  }

  // ============================================
  // GRADE 3
  // ============================================

  return {

    text:
      diagnosis,

    gradient:
      `
        from-red-700/20
        to-red-950/20
      `,

    border:
      `
        border-red-700/20
      `,

    textColor:
      `
        text-red-300
      `
  };
}