export function getCardiovascularRiskCategory(
  risk
) {

  if (risk < 10) {

    return {

      label:
        "Minimal Risk",

      background:
        `
          bg-gradient-to-br
          from-emerald-500/20
          via-cyan-500/5
          to-transparent
        `,

      border:
        `
          border-emerald-400/20
        `,

      glow:
        `
          bg-emerald-500/20
        `,

      text:
        `
          text-emerald-300
        `
    };
  }

  if (risk < 25) {

    return {

      label:
        "Moderate Risk",

      background:
        `
          bg-gradient-to-br
          from-orange-500/20
          via-amber-500/5
          to-transparent
        `,

      border:
        `
          border-orange-400/20
        `,

      glow:
        `
          bg-orange-500/20
        `,

      text:
        `
          text-orange-300
        `
    };
  }

  return {

    label:
      "Elevated Risk",

    background:
      `
        bg-gradient-to-br
        from-rose-500/20
        via-red-500/5
        to-transparent
      `,

    border:
      `
        border-rose-400/20
      `,

    glow:
      `
        bg-rose-500/20
      `,

    text:
      `
        text-rose-300
      `
  };
}