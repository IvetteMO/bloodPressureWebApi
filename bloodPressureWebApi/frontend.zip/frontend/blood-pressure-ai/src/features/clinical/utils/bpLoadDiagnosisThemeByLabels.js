// ============================================
// FILE:
// bpLoadDiagnosisThemeByLabels.js
// ============================================

import { Gauge, GaugeCircle, TriangleAlert } from "lucide-react";

export function getBPLoadThemeByLabel(label) {
  switch (label) {
    // ============================================
    // NORMAL
    // ============================================

    case "Normal":
      return {
        result: "Normal",

        icon: Gauge,

        background: `
          bg-gradient-to-br
            from-emerald-500/25
            via-emerald-400/10
            to-teal-500/10
          `,

        border: `
            border-emerald-400/20
          `,

        text: `
            text-emerald-300
          `,

        glow: `
            shadow-[0_0_80px_rgba(16,185,129,0.18)]
          `,

        clinicalDiagnosis:
          "Blood pressure load remains within expected \nphysiological limits indicating stable \ncircadian pressure distribution.",

        riskLabel: "Low Risk",
      };

    // ============================================
    // INTERMEDIATE
    // ============================================

    case "Intermediate":
      return {
        result: "Intermediate",

        icon: GaugeCircle,

        background: `
            
        bg-gradient-to-br
          from-amber-500/25
          via-amber-400/10
          to-orange-500/10

          `,

        border: `
            border-amber-400/20
          `,

        text: `
            text-amber-300
          `,

        glow: `
            shadow-[0_0_80px_rgba(251,146,60,0.18)]
          `,

        clinicalDiagnosis:
          "Moderate elevation in blood pressure load \nobservedsuggesting partial increase in \ncardiovascular strain.",

        riskLabel: "Monitor",
      };

    // ============================================
    // HIGH LOAD
    // ============================================

    default:
      return {
        result: "High Load",

        icon: TriangleAlert,

        background: `
            
bg-gradient-to-br
  from-rose-500/25
  via-red-500/15
  to-red-600/10

          `,

        border: `
            border-rose-400/20
          `,

        text: `
            text-rose-300
          `,

        glow: `
            shadow-[0_0_80px_rgba(244,63,94,0.18)]
          `,

        clinicalDiagnosis:
          "Elevated blood pressure load detected\nindicating increased cardiovascular burden \nand potential risk.",

        riskLabel: "High Risk",
      };
  }
}
