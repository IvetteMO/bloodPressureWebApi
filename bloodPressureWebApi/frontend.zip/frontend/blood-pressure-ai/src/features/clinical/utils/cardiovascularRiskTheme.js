export function getCardiovascularRiskTheme(
  risk
) {

  if (risk < 10) {

    return {

      category:
        "Low Cardiovascular Risk",

      gradient:
        `
          from-cyan-500/20
          via-emerald-500/5
        `,

      border:
        `
          border-cyan-400/20
        `,

      text:
        `
          text-cyan-300
        `,

      glow:
        `
          bg-cyan-500/20
        `
    };
  }

  if (risk < 25) {

    return {

      category:
        "Moderate Cardiovascular Risk",

      gradient:
        `
          from-blue-500/20
          via-indigo-500/5
        `,

      border:
        `
          border-blue-400/20
        `,

      text:
        `
          text-blue-300
        `,

      glow:
        `
          bg-blue-500/20
        `
    };
  }

  return {

    category:
      "Elevated Cardiovascular Risk",

    gradient:
      `
        from-rose-500/20
        via-red-500/5
      `,

    border:
      `
        border-rose-400/20
      `,

    text:
      `
        text-rose-300
      `,

    glow:
      `
        bg-rose-500/20
      `
  };
}