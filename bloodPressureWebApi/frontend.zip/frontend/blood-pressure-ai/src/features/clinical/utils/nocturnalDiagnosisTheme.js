import { Moon, MoonStar, Sunset, AlertTriangle } from "lucide-react";

export function getNocturnalThemeByLabel(label) {
  switch (label) {
    case "Dipper":
      return {
        result: "Dipper",

        icon: Moon,

        background: `
            bg-gradient-to-br
            from-emerald-500/20
            via-cyan-500/10
            to-transparent
          `,

        border: `
            border-emerald-400/20
          `,

        text: `
            text-emerald-300
          `,

        clinicalDiagnosis:
          "Normal nocturnal blood pressure dipping \npattern observed indicating healthy circadian \nrhythm and cardiovascular regulation.",

        riskLabel: "Optimal",
      };

    case "Non Dipper":
      return {
        result: "Non Dipper",

        icon: MoonStar,

        background: `
            bg-gradient-to-br
            from-amber-500/20
            via-orange-500/10
            to-transparent
          `,

        border: `
            border-orange-400/20
          `,

        text: `
            text-orange-300
          `,

        clinicalDiagnosis:
          "Reduced nocturnal blood pressure decline \ndetected suggesting impaired circadian \nregulation and increased cardiovascular risk.",

        riskLabel: "Monitor",
      };

    case "Extreme Dipper":
      return {
        result: "Extreme Dipper",

        icon: Sunset,

        background: `
            bg-gradient-to-br
            from-cyan-500/20
            via-sky-500/10
            to-transparent
          `,

        border: `
            border-cyan-400/20
          `,

        text: `
            text-cyan-300
          `,

        clinicalDiagnosis:
          "Excessive nighttime blood pressure reduction \nobserved which may be associated with \nrisk of hypoperfusion.",

        riskLabel: "Caution",
      };

    default:
      return {
        result: "Riser",

        icon: AlertTriangle,

        background: `
            bg-gradient-to-br
            from-rose-500/20
            via-red-500/10
            to-transparent
          `,

        border: `
            border-rose-400/20
          `,

        text: `
            text-rose-300
          `,

        clinicalDiagnosis:
          "Blood pressure increase detected associated \nwith elevated cardiovascular risk and \nabnormal circadian pattern.",

        riskLabel: "High Risk",
      };
  }
}
