import { useEffect, useState } from "react";
import useClinicalStore from "../../../../store/useClinicalStore";
import { getFullStudy } from "../../../../api/studyApi";

// ============================================
// GLOBAL UI
// ============================================

import ExcelAside from "@/ui/components/Aside";
import { Page, Hero, Loader, EmptyState } from "@/ui";

// ============================================
// CLINICAL UI
// ============================================

import AIInsightCard from "@/ui/components/Clinical/Diagnosis/DiagnosisPanel/AIInsightCard";
import predictionPalette from "@/ui/components/Clinical/Diagnosis/palette/predictionPalette";
import { getCardiovascularInterpretation } from "@/ui/components/Clinical/Diagnosis/interpretation";
import CardiovascularResultSection from "../sections/CardiovascularResultSection";

// ============================================
// SHARED SECTIONS
// ============================================

import PhysiologicalFeaturesSection from "../../components/sections/PhysiologicalFeaturesSection";
import ClinicalRiskFactorsSection from "../../components/sections/ClinicalRiskFactorsSection";

// ============================================
// COMPONENT
// ============================================

function CardiovascularRiskPage() {
  const { currentStudy } = useClinicalStore();

  const [features, setFeatures] = useState(null);

  const [diagnosis, setDiagnosis] = useState(null);

  const [riskFactors, setRiskFactors] = useState([]);

  const [loading, setLoading] = useState(false);

  // ============================================
  // LOAD DATA
  // ============================================

  useEffect(() => {
    async function loadData() {
      if (!currentStudy) return;

      try {
        setLoading(true);

        const data = await getFullStudy(currentStudy.studyId);

        setFeatures(data.features);

        setDiagnosis(data.diagnosis);

        setRiskFactors(data.riskFactors || []);
      } catch (error) {
        console.error(error);
      } finally {
        setLoading(false);
      }
    }

    loadData();
  }, [currentStudy]);

  // ============================================
  // EMPTY
  // ============================================

  if (!currentStudy) {
    return (
      <Page>
        <EmptyState
          title="No Cardiovascular Study"
          subtitle="Select a cardiovascular study to begin cardiovascular analysis."
          buttonText="Select Study"
          navigateTo="/patients"
        />
      </Page>
    );
  }

  if (loading) {
    return <Loader variant="clinical" />;
  }

  // ============================================
  // PATIENT
  // ============================================

  const patientName = `
    ${currentStudy?.patient?.firstName ?? ""}
    ${currentStudy?.patient?.lastName ?? ""}
  `.trim();

  // ============================================
  // INTERPRETATION
  // ============================================

  const risk = diagnosis?.cardiovascularRisk ?? 0;

  const interpretation = getCardiovascularInterpretation(risk);

  const palette = predictionPalette.cardiovascular;

  // ============================================
  // UI
  // ============================================

  return (
    <Page>
      {/* HERO */}

      <Hero
        variant="compact"
        eyebrow="Cardiovascular Intelligence"
        title={patientName}
        subtitle="AI-assisted cardiovascular stratification generated from ambulatory blood pressure, vascular load and clinical risk factors."
        aside={<ExcelAside currentStudy={currentStudy} />}
      />

      {/* PHYSIOLOGICAL */}

      <PhysiologicalFeaturesSection
        model="cardiovascular"
        features={features}
      />

      {/* CLINICAL */}

      <ClinicalRiskFactorsSection
        model="cardiovascular"
        riskFactors={riskFactors}
        patient={currentStudy?.patient}
      />

      {/* AI */}

      <AIInsightCard palette={palette} interpretation={interpretation} />

      {/* RESULT */}

      <CardiovascularResultSection diagnosis={diagnosis} />
    </Page>
  );
}

export default CardiovascularRiskPage;
