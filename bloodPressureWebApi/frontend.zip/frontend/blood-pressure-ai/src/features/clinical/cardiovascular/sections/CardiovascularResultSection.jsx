import PredictionCard from "@/ui/components/Clinical/Diagnosis/DiagnosisPanel/PredictionCard";

import getCardiovascularRiskCategory from "@/ui/components/Clinical/Diagnosis/themes/cardiovascularTheme";

export default function CardiovascularResultSection({ diagnosis }) {
  const risk = diagnosis?.cardiovascularRisk ?? 0;

  const heartAge = diagnosis?.heartAge ?? "--";

  const theme = getCardiovascularRiskCategory(risk);

  return (
    <PredictionCard
      palette={theme}
      title="Final Cardiovascular Diagnosis"
      value={risk.toFixed(1)}
      suffix="%"
      category={theme.label}
      description="Estimated global cardiovascular risk generated from ambulatory blood pressure, circadian profile, pulse behavior and clinical cardiovascular risk factors."
      rightTitle="Heart Age"
      rightValue={heartAge}
      rightSuffix="yrs"
    />
  );
}
