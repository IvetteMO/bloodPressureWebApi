import { useEffect, useState } from "react";
import useClinicalStore from "../../../../store/useClinicalStore";
import { getFeaturesByStudy } from "../../../../api/featureApi";
import { getDiagnosis } from "../../../../api/diagnosisApi";
import { getReadingsByStudy } from "../../../../api/readingApi";

// ============================================================
// UI KIT
// ============================================================

import { Page, Hero, Section, Loader, EmptyState } from "@/ui";

import {
  DiagnosisCard,
  getBPDiagnosisTheme,
} from "@/ui/components/Clinical/Diagnosis";
import ExcelAside from "@/ui/components/Aside";

// ============================================================
// CLINICAL
// ============================================================

import BloodPressureSection from "../sections/BloodPressureSection";
import HeartRateSection from "../sections/HeartRateSection";
import TrendMetricsSection from "../../components/sections/TrendMetricsSection";

function BPAnalysisPage() {
  const { currentStudy } = useClinicalStore();

  const [readings, setReadings] = useState([]);
  const [features, setFeatures] = useState(null);
  const [diagnosis, setDiagnosis] = useState(null);
  const [loading, setLoading] = useState(false);

  const patientName = `
    ${currentStudy?.patient?.firstName || ""}
    ${currentStudy?.patient?.lastName || ""}
  `.trim();

  useEffect(() => {
    async function loadData() {
      if (!currentStudy) return;

      try {
        setLoading(true);

        const [readingsData, featuresData, diagnosisData] = await Promise.all([
          getReadingsByStudy(currentStudy.studyId),
          getFeaturesByStudy(currentStudy.studyId),
          getDiagnosis(currentStudy.studyId),
        ]);

        setReadings(readingsData || []);
        setFeatures(featuresData);
        setDiagnosis(diagnosisData);
      } catch (error) {
        console.error(error);
      } finally {
        setLoading(false);
      }
    }

    loadData();
  }, [currentStudy]);

  if (!currentStudy) {
    return (
      <Page>
        <EmptyState
          title="No Active Study"
          subtitle="Select a cardiovascular study to begin advanced blood pressure analysis."
          buttonText="Select Study"
          navigateTo="/patients"
        />
      </Page>
    );
  }

  if (loading) {
    return (
      <Page>
        <Loader variant="clinical" />
      </Page>
    );
  }

  const diagnosisTheme = getBPDiagnosisTheme(diagnosis?.finalRiskLevel);

  return (
    <Page>
      <Hero
        variant="compact"
        eyebrow="Blood Pressure Analysis"
        title={patientName}
        subtitle="Advanced cardiovascular interpretation and circadian prssure analysis."
        aside={<ExcelAside currentStudy={currentStudy} />}
      />
      <Section>
        <div className="grid grid-cols-12 gap-6">
          <div className="col-span-12 xl:col-span-6">
            <BloodPressureSection readings={readings} />
          </div>

          <div className="col-span-12 xl:col-span-6">
            <HeartRateSection readings={readings} />
          </div>
        </div>
      </Section>
      <Section>
        <TrendMetricsSection features={features} />
      </Section>
      <Section>
        <DiagnosisCard theme={diagnosisTheme} />
      </Section>
    </Page>
  );
}

export default BPAnalysisPage;
