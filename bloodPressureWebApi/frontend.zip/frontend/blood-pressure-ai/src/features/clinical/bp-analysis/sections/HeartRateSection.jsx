import { Activity } from "lucide-react";

import ChartCard from "@/ui/components/DataVisualization/ChartCard/ChartCard";

import HeartRateChart from "@/ui/components/DataVisualization/LineTrendChart/HeartRateChart";

export default function HeartRateSection({ readings }) {
  const pulseData = readings.map((r) => ({
    pulse: r.pulse,
    time: r.time,
  }));

  return (
    <ChartCard icon={Activity} eyebrow="Pulse Variability" title="Heart Rate">
      <HeartRateChart data={pulseData} />
    </ChartCard>
  );
}
