import { HeartPulse } from "lucide-react";

import ChartCard from "@/ui/components/DataVisualization/ChartCard/ChartCard";

import BPTrendChart from "@/ui/components/DataVisualization/LineTrendChart/BPTrendChart";

export default function BloodPressureSection({ readings }) {
  return (
    <ChartCard
      icon={HeartPulse}
      eyebrow="Circadian Analysis"
      title="24h Blood Pressure Trends"
    >
      <BPTrendChart
        data={readings}
        systolicLabel="Systolic"
        diastolicLabel="Diastolic"
      />
    </ChartCard>
  );
}
