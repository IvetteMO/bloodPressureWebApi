import ClinicalFeatureSection from "@/ui/components/DataDisplay/ClinicalFeatureSection";

import buildClinicalRiskFactors from "../builders/buildClinicalRiskFactors";

export default function ClinicalRiskFactorsSection({
  model = "hypertension",

  riskFactors,

  patient,
}) {
  const items = buildClinicalRiskFactors(model, riskFactors, patient);

  const columns = model === "cardiovascular" ? 3 : 2;

  return (
    <ClinicalFeatureSection
      title="Clinical Risk Factors"
      items={items}
      columns={columns}
    />
  );
}
