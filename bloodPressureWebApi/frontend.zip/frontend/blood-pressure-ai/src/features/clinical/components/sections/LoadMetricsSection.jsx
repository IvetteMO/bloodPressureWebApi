import { Gauge, Sun, Moon } from "lucide-react";

import { ClinicalMetricCard } from "@/ui/components/DataDisplay/MetricCard";

export default function LoadMetricSection({ features }) {
  const metrics = [
    {
      title: "Day Load",
      value: Math.round(features?.dayPressureLoad ?? 0),
      showSubtitle: false,
      icon: Sun,
      accent: "text-green-400",
      valueColor: "text-green-400",
    },

    {
      title: "Night Load",
      value: Math.round(features?.nightPressureLoad ?? 0),
      showSubtitle: false,
      icon: Moon,
      accent: "text-fuchsia-400",
      valueColor: "text-fuchsia-400",
    },

    {
      title: "Total Load",
      value: Math.round(features?.totalPressureLoad ?? 0),
      showSubtitle: false,
      icon: Gauge,
      accent: "text-cyan-400",
      valueColor: "text-cyan-400",
    },
  ];

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
      {metrics.map((metric) => (
        <ClinicalMetricCard key={metric.title} {...metric} />
      ))}
    </div>
  );
}
