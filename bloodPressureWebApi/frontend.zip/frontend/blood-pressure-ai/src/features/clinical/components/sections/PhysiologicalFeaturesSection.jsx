import ClinicalFeatureSection from "@/ui/components/DataDisplay/ClinicalFeatureSection";

import buildPhysiologicalFeatures from "../builders/buildPhysiologicalFeatures";

export default function PhysiologicalFeaturesSection({
  model = "hypertension",

  features,
}) {
  const items = buildPhysiologicalFeatures(model, features);

  return (
    <ClinicalFeatureSection
      title="Physiological Features"
      items={items}
      columns={2}
    />
  );
}
