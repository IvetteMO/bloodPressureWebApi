import { HeartPulse, Heart, Activity, SquareActivity } from "lucide-react";

export default function buildPhysiologicalFeatures(model, features) {
  switch (model) {
    // ============================================
    // HYPERTENSION
    // ============================================

    case "hypertension":
      return [
        {
          title: "Systolic Trend",
          value: features?.systolicTrend,
          icon: HeartPulse,
          theme: "rose",
        },

        {
          title: "Diastolic Trend",
          value: features?.diastolicTrend,
          icon: Heart,
          theme: "cyan",
        },

        {
          title: "Heart Rate",
          value: features?.pulseTrend,
          icon: Activity,
          theme: "emerald",
        },

        {
          title: "Dipping Percent",
          value: `${features?.dippingPercent?.toFixed(1)}%`,
          icon: SquareActivity,
          theme: "orange",
        },
      ];

    // ============================================
    // CARDIOVASCULAR
    // ============================================

    case "cardiovascular":
      return [
        {
          title: "Systolic Trend",
          value: features?.systolicTrend,
          icon: HeartPulse,
          theme: "rose",
        },

        {
          title: "Diastolic Trend",
          value: features?.diastolicTrend,
          icon: Heart,
          theme: "cyan",
        },
      ];

    case "fullDiagnosis":
      return [
        {
          title: "Systolic Trend",
          value: features?.systolicTrend,
          icon: HeartPulse,
          theme: "rose",
        },

        {
          title: "Diastolic Trend",
          value: features?.diastolicTrend,
          icon: Heart,
          theme: "cyan",
        },

        {
          title: "Heart Rate",
          value: features?.pulseTrend,
          icon: Activity,
          theme: "emerald",
        },
      ];

    default:
      return [];
  }
}
