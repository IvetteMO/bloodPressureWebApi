import { HeartPulse, HeartMinus, Activity } from "lucide-react";

import { ClinicalMetricCard } from "@/ui/components/DataDisplay/MetricCard";

export default function ClinicalMetricsSection({ features }) {
  const metrics = [
    {
      title: "Systolic Trend",
      value: features?.systolicTrend ?? "--",
      showSubtitle: false,
      icon: HeartPulse,
      accent: "text-red-300",
      valueColor: "text-red-300",
    },

    {
      title: "Diastolic Trend",
      value: features?.diastolicTrend ?? "--",
      showSubtitle: false,
      icon: HeartMinus,
      accent: "text-cyan-300",
      valueColor: "text-cyan-300",
    },

    {
      title: "Heart Rate Trend",
      value: features?.pulseTrend ?? "--",
      showSubtitle: false,
      icon: Activity,
      accent: "text-green-300",
      valueColor: "text-green-300",
    },
  ];

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
      {metrics.map((metric) => (
        <ClinicalMetricCard key={metric.title} {...metric} />
      ))}
    </div>
  );
}
