import { Heart, Activity, HeartPulse } from "lucide-react";

import { ClinicalMetricCard } from "@/ui/components/DataDisplay/MetricCard";

export default function TrendMetricsSection({ features }) {
  const metrics = [
    {
      title: "Systolic Trend",
      value: features?.systolicTrend ?? "--",
      subtitle: "Circadian systolic behavior",
      icon: Heart,
      accent: "#22D3EE",
    },

    {
      title: "Diastolic Trend",
      value: features?.diastolicTrend ?? "--",
      subtitle: "Circadian diastolic behavior",
      icon: Activity,
      accent: "#FB7185",
    },

    {
      title: "Heart Rate Trend",
      value: features?.pulseTrend ?? "--",
      subtitle: "Heart rate variability",
      icon: HeartPulse,
      accent: "#A855F7",
    },
  ];

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
      {metrics.map((metric) => (
        <ClinicalMetricCard key={metric.title} {...metric} />
      ))}
    </div>
  );
}
