import {
  Scale,
  Cigarette,
  Users,
  Venus,
  Mars,
  Syringe,
  Pill,
} from "lucide-react";

export default function buildClinicalRiskFactors(model, riskFactors, patient) {
  const factors = riskFactors?.[0] ?? {};

  switch (model) {
    // ============================================
    // HYPERTENSION
    // ============================================

    case "hypertension":
      return [
        {
          title: "BMI",
          value: `${factors?.bmi} kg/m²`,
          icon: Scale,
          theme: "orange",
        },

        {
          title: "Smoking",
          value: factors?.smoking
            ? "Active Smoking Exposure"
            : "No Smoking Exposure",
          icon: Cigarette,
          theme: "rose",
        },

        {
          title: "Family History",
          value: factors?.parentalHypertension ?? "--",
          icon: Users,
          theme: "cyan",
        },

        {
          title: "Biological Sex",
          value: patient?.sex ?? "--",
          icon: patient?.sex === "Male" ? Mars : Venus,
          theme: "fuchsia",
        },
      ];

    // ============================================
    // CARDIOVASCULAR
    // ============================================

    case "cardiovascular":
      return [
        {
          title: "BMI",
          value: `${factors?.bmi} kg/m²`,
          icon: Scale,
          theme: "orange",
        },

        {
          title: "Smoking",
          value: factors?.smoking ? "Smoking Exposure" : "No Smoking Exposure",
          icon: Cigarette,
          theme: "rose",
        },

        {
          title: "Diabetes",
          value: factors?.diabetes ? "Diabetes" : "No Diabetes",
          icon: Syringe,
          theme: "fuchsia",
        },

        {
          title: "Family History",
          value: factors?.parentalHypertension ?? "--",
          icon: Users,
          theme: "cyan",
        },

        {
          title: "Treatment",
          value: factors?.hypertensionTreatment ? "Treatment" : "No Treatment",
          icon: Pill,
          theme: "emerald",
        },

        {
          title: "Biological Sex",
          value: patient?.sex ?? "--",
          icon: patient?.sex === "Male" ? Mars : Venus,
          theme: "violet",
        },
      ];

    default:
      return [];
  }
}
