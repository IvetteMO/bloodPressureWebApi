import { SunIcon, Moon, Gauge } from "lucide-react";

import { ClinicalMetricCard } from "@/ui/components/DataDisplay/MetricCard";

export default function PressureMetricsSection({ features }) {
  const metrics = [
    {
      title: "Daytime BP",
      subtitle: "Systolic and Diastolic Average",

      value: `${Math.round(features?.systolicDayMean ?? 0)}
              / 
              ${Math.round(features?.diastolicDayMean ?? 0)}`,

      icon: SunIcon,

      accent: "text-emerald-300",

      valueColor: "text-emerald-300",
    },

    {
      title: "Nighttime BP",

      subtitle: "Systolic and Diastolic Average",

      value: `${Math.round(features?.systolicNightMean ?? 0)}
              /
              ${Math.round(features?.diastolicNightMean ?? 0)}`,

      icon: Moon,

      accent: "text-fuchsia-300",

      valueColor: "text-fuchsia-300",
    },

    {
      title: "Load BP",

      subtitle: "Day and Night Load Percent",

      value: `${features?.dayPressureLoad?.toFixed(1) ?? "--"}%
              -
              ${features?.nightPressureLoad?.toFixed(1) ?? "--"}%`,

      icon: Gauge,

      accent: "text-cyan-300",

      valueColor: "text-cyan-300",
    },
  ];

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
      {metrics.map((metric) => (
        <ClinicalMetricCard key={metric.title} {...metric} />
      ))}
    </div>
  );
}
