import PredictionCard from "@/ui/components/Clinical/Diagnosis/DiagnosisPanel/PredictionCard";

import { getBPDiagnosisTheme } from "@/ui/components/Clinical/Diagnosis/themes/bpDiagnosisTheme";

export default function FullDiagnosisResultSection({ diagnosis }) {
  const theme = getBPDiagnosisTheme(diagnosis?.finalRiskLevel);

  return (
    <PredictionCard
      palette={theme}
      title="Hybrid AI Diagnosis"
      value={theme.diagnosis}
      description={theme.clinicalDiagnosis}
      rightTitle="AI Status"
      rightValue={theme.riskLabel}
    />
  );
}
