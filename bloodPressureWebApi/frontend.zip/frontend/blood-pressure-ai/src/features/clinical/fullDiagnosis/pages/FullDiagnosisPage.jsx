import { useEffect, useState } from "react";
import useClinicalStore from "../../../../store/useClinicalStore";
import { getFullStudy } from "../../../../api/studyApi";

// ============================================
// GLOBAL COMPONENTS
// ============================================
import Hero from "@/ui/components/Hero";
import { Loader, EmptyState, Page } from "@/ui";
import ExcelAside from "@/ui/components/Aside";

// ============================================
// CLINICAL UI
// ============================================
import AIInsightCard from "@/ui/components/Clinical/Diagnosis/DiagnosisPanel/AIInsightCard";
import predictionPalette from "@/ui/components/Clinical/Diagnosis/palette/predictionPalette";
import getFullDiagnosisInterpretation from "@/ui/components/Clinical/Diagnosis/interpretation/fullDiagnosisInterpretation";
import buildClinicalHighlights from "@/ui/components/Clinical/builders/buildClinicalHighlights";
import { ClinicalHighlightSection } from "@/ui/components/Clinical/Diagnosis/ClinicalHighlightCard";
// ============================================
// LOCAL SECTIONS
// ============================================
import FullDiagnosisMetricsSection from "../sections/FullDiagnosisMetricSection";
import FullDiagnosisResultSection from "../sections/FullDiagnosisResultSection";

// ============================================
// COMPONENT
// ============================================

function FullDiagnosisPage() {
  const { currentStudy } = useClinicalStore();

  const [features, setFeatures] = useState(null);

  const [diagnosis, setDiagnosis] = useState(null);

  const [loading, setLoading] = useState(false);

  // ============================================
  // LOAD
  // ============================================

  useEffect(() => {
    async function loadData() {
      if (!currentStudy) return;

      try {
        setLoading(true);

        const fullStudy = await getFullStudy(currentStudy.studyId);

        setFeatures(fullStudy.features);

        setDiagnosis(fullStudy.diagnosis);
      } catch (error) {
        console.error(error);
      } finally {
        setLoading(false);
      }
    }

    loadData();
  }, [currentStudy]);

  // ============================================
  // EMPTY
  // ============================================

  if (!currentStudy) {
    return (
      <Page>
        <EmptyState
          title="No Full Diagnosis Study"
          subtitle="Select a cardiovascular study to begin advanced hybrid interpretation."
          buttonText="Select Study"
          navigateTo="/patients"
        />
      </Page>
    );
  }

  if (loading) {
    return <Loader variant="clinical" />;
  }

  // ============================================
  // DATA
  // ============================================

  const patientName = `
    ${currentStudy?.patient?.firstName ?? ""}
    ${currentStudy?.patient?.lastName ?? ""}
  `.trim();

  const palette = predictionPalette.fullDiagnosis;

  const interpretation = getFullDiagnosisInterpretation(diagnosis);

  const highlights = buildClinicalHighlights(diagnosis);
  console.log(highlights);

  // ============================================
  // UI
  // ============================================

  return (
    <Page>
      <Hero
        variant="compact"
        eyebrow="Full Diagnosis"
        title={patientName}
        subtitle="Hybrid intelligent cardiovascular analysis and AI-assisted clinical interpretation."
        aside={<ExcelAside currentStudy={currentStudy} />}
      />

      {/* ====================================== */}
      {/* CLINICAL DIAGNOSIS */}
      {/* ====================================== */}

      <ClinicalHighlightSection items={highlights} />

      {/* ====================================== */}
      {/* METRICS */}
      {/* ====================================== */}

      <FullDiagnosisMetricsSection features={features} diagnosis={diagnosis} />

      {/* ====================================== */}
      {/* FINAL BP DIAGNOSS */}
      {/* ====================================== */}

      <FullDiagnosisResultSection diagnosis={diagnosis} />

      {/* ====================================== */}
      {/* AI INTERPRETATION */}
      {/* ====================================== */}

      <AIInsightCard palette={palette} interpretation={interpretation} />
    </Page>
  );
}

export default FullDiagnosisPage;
