import Panel from "@/ui/components/Panel";
import MetricSection from "@/ui/components/DataDisplay/MetricCard/MetricSection";

import buildClinicalMetrics from "@/ui/components/Clinical/builders/buildClinicalMetrics";

export default function FullDiagnosisMetricsSection({ features, diagnosis }) {
  const metrics = buildClinicalMetrics(features, diagnosis);

  return (
    <>
      {/* PRESSURE */}

      <MetricSection
        title="Pressure Analysis"
        items={metrics.pressureAnalysis}
        columns={3}
      />

      {/* RISK */}

      <Panel background="surfaceElevated2">
        <MetricSection title="Risk Overview" items={metrics.risk} columns={3} />
      </Panel>
    </>
  );
}
