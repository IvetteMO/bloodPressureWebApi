import { useEffect, useState } from "react";
import useClinicalStore from "../../../../store/useClinicalStore";
import { getFullStudy } from "../../../../api/studyApi";

// ============================================
// GLOBAL COMPONENTS
// ============================================
import { Page, Hero, Section, Loader, EmptyState } from "@/ui";

import LoadMetricsSection from "../../components/sections/LoadMetricsSection";
import ExcelAside from "@/ui/components/Aside";
// ============================================
// LOCAL COMPONENTS
// ============================================

import BPLoadSection from "../sections/BPLoadSection";

import {
  DiagnosisCard,
  getBPLoadTheme,
} from "@/ui/components/Clinical/Diagnosis";

function BPLoadPage() {
  // ============================================
  // STORE
  // ============================================

  const { currentStudy } = useClinicalStore();

  // ============================================
  // STATES
  // ============================================

  const [readings, setReadings] = useState([]);

  const [features, setFeatures] = useState(null);

  const [diagnosis, setDiagnosis] = useState(null);

  const [loading, setLoading] = useState(false);

  // ============================================
  // PATIENT NAME
  // ============================================

  const patientName = `
    ${currentStudy?.patient?.firstName || ""}
    ${currentStudy?.patient?.lastName || ""}
  `.trim();

  // ============================================
  // LOAD DATA
  // ============================================

  useEffect(() => {
    async function loadData() {
      if (!currentStudy) return;

      try {
        setLoading(true);

        const fullStudy = await getFullStudy(currentStudy.studyId);

        // ============================================
        // FEATURES
        // ============================================

        setFeatures(fullStudy.features);

        // ============================================
        // DIAGNOSIS
        // ============================================

        setDiagnosis(fullStudy.diagnosis);

        // ============================================
        // READINGS
        // ============================================

        const formatted = (fullStudy.readings || []).map((r) => {
          const date = new Date(r.readingDateTime);

          return {
            systolic: r.systolic,

            diastolic: r.diastolic,

            time: date.toLocaleTimeString([], {
              hour: "2-digit",
              minute: "2-digit",
            }),
          };
        });

        console.log(formatted);

        setReadings(formatted);
      } catch (error) {
        console.error(error);
      } finally {
        setLoading(false);
      }
    }

    loadData();
  }, [currentStudy]);

  // ============================================
  // EMPTY STATE
  // ============================================

  if (!currentStudy) {
    return (
      <Page>
        <EmptyState
          title="No Blood Pressure Study"
          subtitle="Select a cardiovascular study to begin pressure load interpretation."
          buttonText="Select Study"
          navigateTo="/patients"
        />
      </Page>
    );
  }

  if (loading) {
    return <Loader variant="clinical" />;
  }

  // ============================================
  // DIAGNOSIS THEME
  // ============================================
  console.log("loadDiagnosis recibido:", diagnosis?.loadDiagnosis);

  const diagnosisTheme = getBPLoadTheme(diagnosis?.loadDiagnosis);

  // ============================================
  // RENDER
  // ============================================

  return (
    <Page>
      <Hero
        variant="compact"
        eyebrow="Blood Pressure Load"
        title={patientName}
        subtitle="Circadian pressure load and cardiovascular overload analysis."
        aside={<ExcelAside currentStudy={currentStudy} />}
      />

      <Section>
        <BPLoadSection readings={readings} />
      </Section>

      <Section>
        <LoadMetricsSection features={features} />
      </Section>

      <Section>
        <DiagnosisCard theme={diagnosisTheme} />
      </Section>
    </Page>
  );
}

export default BPLoadPage;
