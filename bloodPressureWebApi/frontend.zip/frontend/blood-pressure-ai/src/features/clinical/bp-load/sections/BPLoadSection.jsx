import { Activity } from "lucide-react";

import ChartCard from "@/ui/components/DataVisualization/ChartCard";

import BPTrendChart from "@/ui/components/DataVisualization/LineTrendChart/BPTrendChart";

export default function BloodPressureLoadSection({ readings }) {
  return (
    <ChartCard
      icon={Activity}
      eyebrow="Circadian Pressure Dynamics"
      title="Blood Pressure Load"
    >
      <BPTrendChart
        data={readings}
        systolicLabel="Systolic"
        diastolicLabel="Diastolic"
      />
    </ChartCard>
  );
}
