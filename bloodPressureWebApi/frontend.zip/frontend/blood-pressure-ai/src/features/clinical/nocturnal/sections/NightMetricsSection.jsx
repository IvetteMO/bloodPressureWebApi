import { Moon } from "lucide-react";
import { ClinicalMetricCard } from "@/ui/components/DataDisplay/MetricCard";

export default function NightMetricsSection({ features }) {
  const metrics = [
    {
      title: "Night Systolic Mean",
      value: Math.round(features?.systolicNightMean ?? 0),
      showSubtitle: false,
      icon: Moon,
      accent: "text-violet-300",
      valueColor: "text-violet-300",
    },

    {
      title: "Night Diastolic Mean",
      value: Math.round(features?.diastolicNightMean ?? 0),
      showSubtitle: false,
      icon: Moon,
      accent: "text-fuchsia-300",
      valueColor: "text-fuchsia-300",
    },
  ];

  return (
    <div className="flex h-full flex-col gap-6">
      {metrics.map((metric) => (
        <ClinicalMetricCard key={metric.title} {...metric} />
      ))}
    </div>
  );
}
