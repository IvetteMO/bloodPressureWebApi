import { Sun } from "lucide-react";

import ChartCard from "@/ui/components/DataVisualization/ChartCard/ChartCard";
import BPTrendChart from "@/ui/components/DataVisualization/LineTrendChart/BPTrendChart";

function DaytimeChartSection({ readings }) {
  return (
    <ChartCard
      icon={Sun}
      eyebrow="
        Circadian Analysis
      "
      title="
        Daytime BP
      "
    >
      <BPTrendChart
        data={readings}
        systolicColor="#77E9B3"
        diastolicColor="#FAA1AE"
        systolicLabel="Systolic"
        diastolicLabel="Diastolic"
      />
    </ChartCard>
  );
}

export default DaytimeChartSection;
