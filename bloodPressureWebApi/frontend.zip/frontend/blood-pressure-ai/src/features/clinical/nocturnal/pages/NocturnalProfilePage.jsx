import { useEffect, useState } from "react";
import useClinicalStore from "../../../../store/useClinicalStore";
import { getFullStudy } from "../../../../api/studyApi";

import { Page, Hero, Section, Loader, EmptyState } from "@/ui";

import { spacing } from "@/ui/foundations/spacing";
import ExcelAside from "@/ui/components/Aside";
import DaytimeChartSection from "../sections/DaytimeChartSection";

import NighttimeChartSection from "../sections/NighttimeChartSection";
import DayMetricsSection from "../sections/DayMetricsSection";
import NightMetricsSection from "../sections/NightMetricsSection";

import {
  DiagnosisCard,
  getNocturnalTheme,
} from "@/ui/components/Clinical/Diagnosis";

function NocturnalProfilePage() {
  const { currentStudy } = useClinicalStore();

  const [readings, setReadings] = useState([]);

  const [features, setFeatures] = useState(null);

  const [diagnosis, setDiagnosis] = useState(null);

  const [loading, setLoading] = useState(false);

  // ============================================
  // LOAD DATA
  // ============================================

  useEffect(() => {
    async function loadData() {
      if (!currentStudy) return;

      try {
        setLoading(true);

        const fullStudy = await getFullStudy(currentStudy.studyId);

        setReadings(fullStudy.readings || []);

        setFeatures(fullStudy.features);

        setDiagnosis(fullStudy.diagnosis);
      } catch (error) {
        console.error(error);
      } finally {
        setLoading(false);
      }
    }

    loadData();
  }, [currentStudy]);

  // ============================================
  // NO STUDY
  // ============================================

  if (!currentStudy) {
    return (
      <Page>
        <EmptyState
          title="No Nocturnal Profile Study"
          subtitle="Select a cardiovascular study to begin nocturnal blood pressure
          profile interpretation."
          buttonText="Select Study"
          navigateTo="/patients"
        />
      </Page>
    );
  }

  if (loading) {
    return <Loader variant="clinical" />;
  }

  // ============================================
  // HOURS
  // ============================================

  // FORMAT
  // ============================================

  const formattedReadings = readings.map((r) => {
    const date = new Date(r.readingDateTime);

    return {
      systolic: r.systolic,

      diastolic: r.diastolic,

      pulse: r.pulse,

      period: r.period,

      time: date.toLocaleTimeString([], {
        hour: "2-digit",
        minute: "2-digit",
      }),
    };
  });

  // ============================================
  // DAYTIME
  // ============================================

  const daytimeReadings = formattedReadings.filter((r) => r.period === "DAY");

  const nighttimeReadings = formattedReadings.filter(
    (r) => r.period === "NIGHT",
  );

  // ============================================
  // PATIENT NAME
  // ============================================

  const patientName = `
    ${currentStudy?.patient?.firstName || ""}
    ${currentStudy?.patient?.lastName || ""}
  `.trim();

  // ============================================
  // THEME
  // ============================================

  const diagnosisTheme = getNocturnalTheme(diagnosis?.nocturnalProfile);

  return (
    <Page>
      <Hero
        variant="compact"
        eyebrow="Nocturnal Profile"
        title={patientName}
        subtitle="Circadian blood pressure and nocturnal dipping analysis."
        aside={<ExcelAside currentStudy={currentStudy} />}
      />

      {/* DAYTIME */}

      <div className="grid grid-cols-12 items-center gap-6">
        {/* CHART */}

        <div className="col-span-12 xl:col-span-9">
          <DaytimeChartSection readings={daytimeReadings} />
        </div>

        {/* METRICS */}

        <div className={`col-span-12 xl:col-span-3 ${spacing.block} `}>
          <DayMetricsSection features={features} />
        </div>
      </div>

      {/* NIGHTTIME */}

      <div className="grid grid-cols-12 items-center gap-6">
        {/* CHART */}

        <div className="col-span-12 xl:col-span-9">
          <NighttimeChartSection readings={nighttimeReadings} />
        </div>

        {/* METRICS */}

        <div className={`col-span-12 xl:col-span-3`}>
          <NightMetricsSection features={features} />
        </div>
      </div>

      {/* DIAGNOSIS */}

      <Section>
        <DiagnosisCard theme={diagnosisTheme} />
      </Section>
    </Page>
  );
}

export default NocturnalProfilePage;
