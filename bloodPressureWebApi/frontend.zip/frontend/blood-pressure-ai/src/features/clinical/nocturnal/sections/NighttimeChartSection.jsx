import { Moon } from "lucide-react";

import ChartCard from "@/ui/components/DataVisualization/ChartCard/ChartCard";

import BPTrendChart from "@/ui/components/DataVisualization/LineTrendChart/BPTrendChart";

function NighttimeChartSection({ readings }) {
  return (
    <ChartCard
      icon={Moon}
      eyebrow="
        Nocturnal Circadian
      "
      title="
        Night-Time BP
      "
    >
      <BPTrendChart
        data={readings}
        systolicColor="#C4B4FF"
        diastolicColor="#EEA9FF"
        systolicLabel="Systolic"
        diastolicLabel="Diastolic"
      />
    </ChartCard>
  );
}

export default NighttimeChartSection;
