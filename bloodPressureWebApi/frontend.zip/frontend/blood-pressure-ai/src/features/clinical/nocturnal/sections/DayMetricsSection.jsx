import { Sun } from "lucide-react";
import { ClinicalMetricCard } from "@/ui/components/DataDisplay/MetricCard";

export default function DayMetricsSection({ features }) {
  const metrics = [
    {
      title: "Day Systolic Mean",
      value: Math.round(features?.systolicDayMean ?? 0),
      showSubtitle: false,
      icon: Sun,
      accent: "text-emerald-300",
      valueColor: "text-emerald-300",
    },

    {
      title: "Day Diastolic Mean",
      value: Math.round(features?.diastolicDayMean ?? 0),
      showSubtitle: false,
      icon: Sun,
      accent: "text-rose-300",
      valueColor: "text-rose-300",
    },
  ];

  return (
    <div className="flex h-full flex-col gap-6">
      {metrics.map((metric) => (
        <ClinicalMetricCard key={metric.title} {...metric} />
      ))}
    </div>
  );
}
