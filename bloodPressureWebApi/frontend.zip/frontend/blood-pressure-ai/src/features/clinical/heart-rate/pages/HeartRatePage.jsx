import { useEffect, useState } from "react";
import useClinicalStore from "../../../../store/useClinicalStore";
import { getFullStudy } from "../../../../api/studyApi";

// ============================================
// GLOBAL COMPONENTS
// ============================================
import { Page, Hero, Section, Loader, EmptyState } from "@/ui";
import ExcelAside from "@/ui/components/Aside";

// ============================================
// LOCAL
// ============================================
import HeartRateChartSection from "../sections/HeartRateChartSection";
import HeartRateReadingsSection from "../sections/HeartRateReadingsSection";
import HeartRateMetricsSection from "../sections/HeartRateMetricsSection";

// ============================================
// UTILS
// ============================================
import {
  DiagnosisCard,
  getHeartRateTheme,
} from "@/ui/components/Clinical/Diagnosis";

function HeartRatePage() {
  // ============================================
  // STORE
  // ============================================

  const { currentStudy } = useClinicalStore();

  // ============================================
  // STATES
  // ============================================

  const [readings, setReadings] = useState([]);

  const [features, setFeatures] = useState(null);

  const [diagnosis, setDiagnosis] = useState(null);

  const [loading, setLoading] = useState(false);

  // ============================================
  // LOAD
  // ============================================

  useEffect(() => {
    async function loadData() {
      if (!currentStudy) return;

      try {
        setLoading(true);

        const fullStudy = await getFullStudy(currentStudy.studyId);

        setFeatures(fullStudy.features);

        setDiagnosis(fullStudy.diagnosis);

        const formatted = (fullStudy.readings || []).map((r) => {
          const date = new Date(r.readingDateTime);

          return {
            pulse: r.pulse,

            time: date.toLocaleTimeString([], {
              hour: "2-digit",
              minute: "2-digit",
            }),
          };
        });

        setReadings(formatted);
      } catch (error) {
        console.error(error);
      } finally {
        setLoading(false);
      }
    }

    loadData();
  }, [currentStudy]);

  // ============================================
  // EMPTY
  // ============================================

  if (!currentStudy) {
    return (
      <Page>
        <EmptyState
          title="No Heart Rate Study"
          subtitle="Select a cardiovascular study to begin heart
          rate interpretation."
          buttonText="Select Study"
          navigateTo="/patients"
        />
      </Page>
    );
  }

  if (loading) {
    return <Loader variant="clinical" />;
  }

  // ============================================
  // DIAGNOSIS THEME
  // ============================================

  const diagnosisTheme = getHeartRateTheme(diagnosis?.heartRateDiagnosis);

  // ============================================
  // PATIENT NAME
  // ============================================

  const patientName = `
    ${currentStudy?.patient?.firstName || ""}
    ${currentStudy?.patient?.lastName || ""}
  `.trim();

  // ============================================
  // UI
  // ============================================

  return (
    <Page>
      <Hero
        variant="compact"
        eyebrow="Heart Rate"
        title={patientName}
        subtitle="Pulse variability and cardiovascular rhythm analysis."
        aside={<ExcelAside currentStudy={currentStudy} />}
      />

      <div className="grid grid-cols-12 items-stretch gap-6">
        {/* READINGS */}

        <div className="order-1 col-span-12 lg:order-2 lg:col-span-4">
          <HeartRateReadingsSection readings={readings} />
        </div>

        {/* CHART */}

        <div className="col-span-12 lg:col-span-8">
          <HeartRateChartSection readings={readings} />
        </div>
      </div>

      {/* BOTTOM */}

      <div className="grid grid-cols-12 items-stretch gap-6">
        {/* METRIC */}

        <div className="col-span-12 lg:col-span-4">
          <div className="mt-15">
            <HeartRateMetricsSection features={features} />
          </div>
        </div>
        {/* DIAGNOSIS */}

        <div className="col-span-12 lg:col-span-8">
          <Section>
            <DiagnosisCard theme={diagnosisTheme} />
          </Section>
        </div>
      </div>
    </Page>
  );
}

export default HeartRatePage;
