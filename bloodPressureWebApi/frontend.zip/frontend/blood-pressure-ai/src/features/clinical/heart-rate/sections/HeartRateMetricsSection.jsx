import { TrendingUp } from "lucide-react";

import { ClinicalMetricCard } from "@/ui/components/DataDisplay/MetricCard";

export default function HeartRateMetricSection({ features }) {
  const metrics = [
    {
      title: " Heart Rate Trend",
      value: features?.pulseTrend ?? "--",
      showSubtitle: false,
      icon: TrendingUp,
      accent: "text-emerald-300",
      valueColor: "text-emerald-300",
    },
  ];

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-1">
      {metrics.map((metric) => (
        <ClinicalMetricCard key={metric.title} {...metric} />
      ))}
    </div>
  );
}
