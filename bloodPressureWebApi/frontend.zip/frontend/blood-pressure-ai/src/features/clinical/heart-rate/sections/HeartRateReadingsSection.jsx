import { HeartPulse } from "lucide-react";

import Panel from "@/ui/components/Panel";
import IconBadge from "@/ui/components/IconBadge";

import Stack from "@/ui/primitives/Stack";

import { typography } from "@/ui/foundations";

export default function HeartRateReadingsSection({ readings }) {
  return (
    <Panel variant="chart" className="h-full">
      <Stack className="h-full">
        {/* HEADER */}

        <Stack direction="row" gap="lg" align="center">
          <IconBadge
            icon={HeartPulse}
            variant="xl"
            appearance="bg-emerald-500/10"
            lineColor="#6EE7B7"
          />

          <Stack gap="xs">
            <p className={typography.metricLabel}>Clinical Readings</p>

            <h2 className={typography.chartTitle}>Heart Rate</h2>
          </Stack>
        </Stack>

        {/* TABLE */}

        <div className="mt-8 h-[330px] overflow-y-auto pr-2">
          <table className="w-full">
            <thead>
              <tr>
                <th className="pb-5 text-center text-sm font-medium tracking-[0.25em] text-white/45 uppercase">
                  Pulse
                </th>
              </tr>
            </thead>

            <tbody>
              {readings.map((reading, index) => (
                <tr key={index} className="border-t border-white/5">
                  <td className="py-6 text-center text-4xl font-black text-emerald-300">
                    {reading.pulse}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Stack>
    </Panel>
  );
}
