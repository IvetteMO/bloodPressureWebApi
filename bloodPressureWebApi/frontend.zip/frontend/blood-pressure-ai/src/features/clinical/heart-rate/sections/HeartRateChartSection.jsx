import { Activity } from "lucide-react";

import ChartCard from "@/ui/components/DataVisualization/ChartCard/ChartCard";

import HeartRateChart from "@/ui/components/DataVisualization/LineTrendChart/HeartRateChart";

function HeartRateChartSection({ readings }) {
  return (
    <ChartCard
      icon={Activity}
      eyebrow="
        Pulse Variability
      "
      title="
        Heart Rate
      "
    >
      <div className="mt-10 h-full w-full">
        <HeartRateChart data={readings} />
      </div>
    </ChartCard>
  );
}

export default HeartRateChartSection;
