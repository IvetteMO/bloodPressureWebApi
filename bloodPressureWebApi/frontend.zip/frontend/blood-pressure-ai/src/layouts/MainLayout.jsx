import { useState } from "react";

import { Outlet } from "react-router-dom";

import { AnimatePresence, motion } from "framer-motion";

import Sidebar from "@/ui/components/Navigation/Sidebar";
import Topbar from "@/ui/components/Navigation/Topbar";

import { surfaces } from "@/ui/foundations";

function MainLayout() {
  const [collapsed, setCollapsed] = useState(false);

  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className={`relative flex min-h-screen ${surfaces.pageBackground} `}>
      {/* ===================================== */}
      {/* MOBILE OVERLAY */}
      {/* ===================================== */}

      <AnimatePresence>
        {sidebarOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setSidebarOpen(false)}
            className="fixed inset-0 z-40 bg-black/70 backdrop-blur-md xl:hidden"
          />
        )}
      </AnimatePresence>

      {/* ===================================== */}
      {/* MOBILE SIDEBAR */}
      {/* ===================================== */}

      <AnimatePresence>
        {sidebarOpen && (
          <motion.div
            initial={{ x: -420 }}
            animate={{ x: 0 }}
            exit={{ x: -420 }}
            transition={{
              duration: 0.35,
              ease: "easeOut",
            }}
            className="fixed top-0 left-0 z-50 h-full xl:hidden"
          >
            <Sidebar mobile collapsed={false} setSidebarOpen={setSidebarOpen} />
          </motion.div>
        )}
      </AnimatePresence>

      {/* ===================================== */}
      {/* DESKTOP SIDEBAR */}
      {/* ===================================== */}

      <div className="hidden xl:block">
        <Sidebar collapsed={collapsed} setCollapsed={setCollapsed} />
      </div>

      {/* ===================================== */}
      {/* MAIN */}
      {/* ===================================== */}

      <main className="flex min-w-0 flex-1 flex-col">
        <Topbar sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen} />

        <div className="flex-1">
          <Outlet />
        </div>
      </main>
    </div>
  );
}

export default MainLayout;
