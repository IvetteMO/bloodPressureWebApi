import api from "./axios";

// ========================================
// GET ALL PATIENTS
// ========================================

export const getPatients =
  async () => {

    try {

      const res =
        await api.get(
          "/Patients"
        );

      return res.data;

    }
    catch (error) {

      console.error(
        "GET PATIENTS ERROR:",
        error.response?.data || error
      );

      throw error;
    }
};

// ========================================
// GET PATIENT BY ID
// ========================================

export const getPatientById =
  async (patientId) => {

    try {

      const res =
        await api.get(
          `/Patients/${patientId}`
        );

      return res.data;

    }
    catch (error) {

      console.error(
        "GET PATIENT ERROR:",
        error.response?.data || error
      );

      throw error;
    }
};

// ========================================
// CREATE PATIENT
// ========================================

export const createPatient =
  async (data) => {

    try {

      console.log(
         "CREATE PATIENT DATA JSON:",
  JSON.stringify(
    data,
    null,
    2
  )
      );

      const res =
        await api.post(
          "/Patients",
          data
        );

      return res.data;

    }
    catch (error) {

      console.error(
         "CREATE PATIENT ERROR JSON:",
  JSON.stringify(
    error.response?.data,
    null,
    2
  )
      );

      throw error;
    }
};

// ========================================
// UPDATE PATIENT
// ========================================

export const updatePatient =
  async (id, data) => {

    try {

      const res =
        await api.put(
          `/Patients/${id}`,
          data
        );

      return res.data;

    }
    catch (error) {

      console.error(
        "UPDATE PATIENT ERROR:",
        error.response?.data || error
      );

      throw error;
    }
};

// ========================================
// DELETE PATIENT
// ========================================

export const deletePatient =
  async (patientId) => {

    try {

      const res =
        await api.delete(
          `/Patients/${patientId}`
        );

      return res.data;

    }
    catch (error) {

      console.error(
        "DELETE PATIENT ERROR:",
        error.response?.data || error
      );

      throw error;
    }
};