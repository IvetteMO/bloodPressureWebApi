import api from "./axios";

export const getDiagnosis =
  async (studyId) => {

    const response =
      await api.get(
        `/Diagnosis/study/${studyId}`
      );

    return response.data;
};