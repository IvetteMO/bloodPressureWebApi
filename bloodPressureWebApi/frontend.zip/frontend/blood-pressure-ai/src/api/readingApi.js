import api from "./axios";

// ========================================
// GET READINGS BY STUDY
// ========================================

export const getReadingsByStudy =
  async (studyId) => {

    const response =
      await api.get(
        `/Readings/study/${studyId}`
      );

    return response.data;
};