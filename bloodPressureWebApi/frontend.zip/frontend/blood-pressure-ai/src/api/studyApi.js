import api from "./axios";

// ========================================
// GET STUDIES BY PATIENT
// ========================================

export const getStudiesByPatient =
  async (patientId) =>
{
  try
  {
    const res =
      await api.get(
        `/Studies/patient/${patientId}`
      );

    return res.data;
  }
  catch (error)
  {
    console.error(
      "GET STUDIES ERROR:",
      error
    );

    throw error;
  }
};

// ========================================
// CREATE STUDY
// ========================================

export const createStudy =
  async (data) =>
{
  try
  {
    const res =
      await api.post(
        "/Studies",
        data
      );

    return res.data;
  }
  catch (error) {

  console.error("FULL BACKEND ERROR:", error.response?.data);

  throw error;
}
};

// ========================================
// PREVIEW IMPORT
// ========================================

export const previewImport =
  async (
    patientId,
    file
  ) =>
{
  try
  {
    const form =
      new FormData();

    form.append(
      "file",
      file
    );

    const res =
      await api.post(
        `/Import/preview/${patientId}`,
        form,
        {
          headers:
          {
            "Content-Type":
              "multipart/form-data"
          }
        }
      );

    return res.data;
  }
  catch (error)
  {
    console.error(
      "PREVIEW IMPORT ERROR:",
      error
    );

    if (
      error.response &&
      error.response.data
    )
    {
      throw new Error(
        error.response.data.error
        ||
        error.response.data.message
        ||
        "Preview import failed",
        { cause: error }
      );
    }

    throw new Error(
      "Connection error",
      { cause: error }
    );
  }
};

// ========================================
// UPLOAD EXCEL FILE
// ========================================

export const uploadStudyFile =
  async (
    studyId,
    file
  ) =>
{
  try
  {
    const form =
      new FormData();

    form.append(
      "file",
      file
    );

    const res =
      await api.post(
        `/Studies/upload/${studyId}`,
        form,
      );

    return res.data;
  }
  catch (error)
  {
    console.error(
      "UPLOAD ERROR:",
      error
    );

    // ====================================
    // BACKEND ERROR
    // ====================================

    if (
      error.response &&
      error.response.data
    )
    {
      throw new Error(
        error.response.data.error
        ||
        error.response.data.message
        ||
        "Upload failed",
        { cause: error }
      );
    }

    // ====================================
    // NETWORK ERROR
    // ====================================

    throw new Error(
      "Server connection failed",
      { cause: error }
    );
  }
};

// ========================================
// DELETE STUDY
// ========================================

export const deleteStudy =
  async (studyId) =>
{
  try
  {
    const res =
      await api.delete(
        `/Studies/${studyId}`
      );

    return res.data;
  }
  catch (error)
  {
    console.error(
      "DELETE STUDY ERROR:",
      error
    );

    throw error;
  }
};

// ========================================
// GET STUDY READINGS
// ========================================

export const getStudyReadings =
  async (studyId) =>
{
  try
  {
    const response =
      await api.get(
        `/Studies/${studyId}/readings`
      );

    return response.data;
  }
  catch (error)
  {
    console.error(
      "READINGS ERROR:",
      error
    );

    throw error;
  }
};



// ========================================
// GET FULL STUDY
// ========================================

export const getFullStudy =
  async (studyId) =>
{
  try
  {
    const response =
      await api.get(
        `/Studies/full/${studyId}`
      );

    return response.data;
  }
  catch (error)
  {
    console.error(
      "FULL STUDY ERROR:",
      error
    );

    throw error;
  }
};