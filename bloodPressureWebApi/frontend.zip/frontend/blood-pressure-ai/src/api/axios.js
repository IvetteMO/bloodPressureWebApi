import axios from "axios";

const api = axios.create({

  baseURL:
    import.meta.env.VITE_API_URL,

  timeout: 60000
});

// ========================================
// RESPONSE INTERCEPTOR
// ========================================

api.interceptors.response.use(

  (response) => response,

  (error) => {

    console.error(
      "API ERROR:",
      error.response?.data
    );

    return Promise.reject(error);
  }
);

export default api;