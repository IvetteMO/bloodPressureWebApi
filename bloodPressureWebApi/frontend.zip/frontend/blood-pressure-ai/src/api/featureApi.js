import api from "./axios";

// ========================================
// GET FEATURES BY STUDY
// ========================================

export const getFeaturesByStudy =
  async (studyId) => {

    const response =
      await api.get(
        `/Features/study/${studyId}`
      );

    return response.data;
};