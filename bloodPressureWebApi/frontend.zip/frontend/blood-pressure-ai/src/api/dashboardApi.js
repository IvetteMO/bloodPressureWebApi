// ============================================
// dashboardApi.js
// ============================================

import api from "./axios";

// ============================================
// OVERVIEW
// ============================================

export async function getDashboardOverview() {

  const response =
    await api.get(
      "/Dashboard/overview"
    );

  return response.data;
}

// ============================================
// ALERTS
// ============================================

export async function getDashboardAlerts() {

  const response =
    await api.get(
      "/Dashboard/alerts"
    );

  return response.data;
}

// ============================================
// INSIGHTS
// ============================================

export async function getDashboardInsights(
  studyId
) {

  const response =
    await api.get(
      `/Dashboard/insights/${studyId}`
    );

  return response.data;
}


// ============================================
// TRENDS
// ============================================

export async function getDashboardTrends(
  studyId
) {

  const response =
    await api.get(
      `/Dashboard/trends/${studyId}`
    );

  return response.data;
}

// ============================================
// SNAPSHOT
// ============================================

export async function getDashboardSnapshot() {

  const response =
    await api.get(
      "/Dashboard/snapshot"
    );

  return response.data;
}