import axios from "./axios";

// =====================================
// CREATE
// =====================================

export const createRiskFactors =
  async (data) =>
{
  const res =
    await axios.post(
      "/RiskFactors",
      data
    );

  return res.data;
};

// =====================================
// UPDATE
// =====================================

export const updateRiskFactors =
  async (

    id,

    data

  ) =>
{
  const res =
    await axios.put(

      `/RiskFactors/${id}`,

      data
    );

  return res.data;
};