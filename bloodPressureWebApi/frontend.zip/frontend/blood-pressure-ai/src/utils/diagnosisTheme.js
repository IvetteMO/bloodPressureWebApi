export function getDiagnosisTheme(
  diagnosis
) {

  switch(diagnosis) {

    case "Optimal":

      return {
        bg: "from-emerald-500/20 to-emerald-700/10",
        border: "border-emerald-500/20",
        text: "text-emerald-300"
      };

    case "High Normal":

      return {
        bg: "from-orange-500/20 to-orange-700/10",
        border: "border-orange-500/20",
        text: "text-orange-300"
      };

    case "Grade 1 Hypertension":

      return {
        bg: "from-rose-500/20 to-red-700/10",
        border: "border-rose-500/20",
        text: "text-rose-300"
      };

    default:

      return {
        bg: "from-violet-500/20 to-fuchsia-700/10",
        border: "border-violet-500/20",
        text: "text-white"
      };
  }
}