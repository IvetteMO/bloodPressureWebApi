// lógica clínica
export function getClinicalState(value) {
  if (value >= 70) return "critical";
  if (value >= 40) return "warning";
  return "normal";
}

// estilos visuales
export const clinicalStyles = {
  normal: {
    glow: "",
    text: "text-white",
  },
  warning: {
    glow: "shadow-[0_0_20px_rgba(251,191,36,0.15)]",
    text: "text-amber-300",
  },
  critical: {
    glow: "shadow-[0_0_25px_rgba(239,68,68,0.25)]",
    text: "text-rose-400",
  },
};
